package com.otproject.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.otproject.dto.TeamStructure;

public interface TeamStructureRepository extends JpaRepository<TeamStructure, Integer> {

	TeamStructure findByStructId(Integer id);

	TeamStructure findByStaffId(String empId);

	@Query("select s from TeamStructure s where (s.position != 'Project Manager' and s.position != 'Division Head' and s.position != 'Dept Head' and s.position not like '%HR%') and s.checkDelete=0 order by s.position asc")
	Page<TeamStructure> findAllWithCheck(Pageable pageable);

	@Query("select s from TeamStructure s where (s.name LIKE CONCAT('%',:name,'%') or s.staffId LIKE CONCAT('%',:name,'%') or s.team LIKE CONCAT('%',:name,'%') or s.position LIKE CONCAT('%',:name,'%') or s.project LIKE CONCAT('%',:name,'%')) and s.checkDelete=0 order by s.position asc")
	Page<TeamStructure> findByName(@Param("name") String name, Pageable pageable);

	@Query("select s from TeamStructure s where (s.position = 'Project Manager' or s.position = 'Division Head' or s.position = 'Dept Head' or s.position like '%HR%') and s.checkDelete=0 order by s.position asc")
	Page<TeamStructure> findAllWithCheckManage(Pageable pageable);

	// Query for login
	@Query("select s from TeamStructure s where s.staffId=?1 and s.checkDelete=0 group by staff_id")
	TeamStructure findStaffIdByStaffId(String staffId);

//	Query for project list
//	for group ot form
	@Query("select s.project from TeamStructure s where s.staffId=?1 and s.checkDelete=0 group by project")
	List<String> findProjectByStaffId(String staffId);

//	Query for staff id list with teamStructure type 
//	for group ot form
	@Query("select s from TeamStructure s where s.project=?1 and s.checkDelete=0")
	List<TeamStructure> findAllStaffByProject(String projectId);

//	retrieve teamstructure by staff name
	@Query("select s from TeamStructure s where name=?1 and project=?2 and s.checkDelete=0")
	List<TeamStructure> findByStaffName(String name, String projectId);

	@Query("select s from TeamStructure s where s.staffId = :name and s.checkDelete=0 group by staffId")
	List<TeamStructure> findByStaffIdOt(@Param("name") String name);

	@Query(nativeQuery = true, value = "select distinct * from team_structure where project_id in(?1,'') and staff_Id!=?2 and check_delete=0 and position in ('Project Manager','Division Head','Dept Head','HR Team member')")
	List<TeamStructure> findBySentToName(String project, String staffId);

	@Query("select s from TeamStructure s where s.staffId = :name and s.checkDelete=0")
	List<TeamStructure> findByStaffIdSignature(@Param("name") String name);

//	for signature upload
	@Query("select s.structId from TeamStructure s where s.staffId=?1 and s.checkDelete=0 group by staffId")
	Integer findStructId(String staffId);

	@Query(nativeQuery = true, value = "select * from  ot_form f, ot_form_ot_team t,team_structure team where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and sent_to =:staffId")
	List<TeamStructure> findAllTeamStructureData(@Param("staffId") String staffId);

	@Query(nativeQuery = true, value = "SELECT salary  from  position where position_name=:position")
	Double findSalaryByStaffId(@Param("position") String position);

	@Query(nativeQuery = true, value = "select distinct s.position from team_structure s where s.staff_id=:sentTo")
	String findPosition(@Param("sentTo") String sentTo);

	// jasper
	@Query("select s from TeamStructure s where s.staffId = :staffId and s.project in(:project,'') and s.checkDelete=0")
	TeamStructure findByJasper(@Param("project") String project,@Param("staffId") String staffId);

	@Query("select s from TeamStructure s where s.staffId = :staffId and s.team='HR' and s.checkDelete=0")
	TeamStructure findByJasperHR(@Param("staffId") String staffId);
	
	// for Inbox Response
	  @Query(nativeQuery = true, value = "select s.name from ot_form ot,ot_form_ot_team t,team_structure s where ot.ot_id = t.ot_team_ot_id and t.ot_team_struct_id = s.struct_id and form_id=:formId")
	  List<String> forInboxResponseName(@Param("formId") String formId);

}
