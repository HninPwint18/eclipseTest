package com.otproject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.otproject.dto.StatusDTO;

public interface StatusRepository extends JpaRepository<StatusDTO,Integer>{


	//for inbox response
	@Query(nativeQuery = true, value = "select * from status where ot_form_id = :formId and status = 'Approved' ")
	List<StatusDTO> fetchApprover(@Param("formId") String formId);
	
	@Query(nativeQuery = true, value = "select * from status where approve_by = :response and ot_form_id = :formId ")
	StatusDTO fetchMyOtList(@Param("response") String response,@Param("formId") String formId);
	
	//for details in myOTList
	@Query(nativeQuery = true, value = "select * from status where ot_form_id = :formId")
	List<StatusDTO> fetchDetailsMyOTForm(@Param("formId") String formId);
	
}
