package com.otproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.otproject.dto.OTFees;

public interface OTFeesRepository extends JpaRepository<OTFees, Integer>{
	
	

}
