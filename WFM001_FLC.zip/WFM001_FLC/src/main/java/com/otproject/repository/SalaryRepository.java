package com.otproject.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.otproject.dto.Position;


public interface SalaryRepository extends CrudRepository<Position, Integer>{

	List<Position> findByPositionName(String name);
	
}
