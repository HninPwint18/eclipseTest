package com.otproject.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.otproject.dto.OtFormDTO;

public interface OtFormRepository extends JpaRepository<OtFormDTO, Integer> {

	@Query(nativeQuery = true, value = "SELECT * FROM ot_form ORDER BY ot_id DESC LIMIT 1")
	OtFormDTO selectLastId();

//retrieve save file list for draft file
	@Query(nativeQuery = true, value = "select * from ot_form f join ot_form_ot_team t on t.ot_team_ot_id = f.ot_id where ot_team_struct_id = ?1 and filename!=''")
	List<OtFormDTO> findBySavedFile(Integer structId);

	@Query(nativeQuery = true, value = "select * from ot_form where filename=?1")
	OtFormDTO findBySaveFileName(String filename);
	
//	for project ot
	@Query(nativeQuery = true, value = "select * from ot_form where filename=?1")
	List<OtFormDTO> findBySaveFileNameOT(String filename);

	// get All Projects
	@Query(value = "select distinct(project_id) from team_structure where project_id !=\"\" ", nativeQuery = true)
	public String[] getProjectforCount();

	// get all approved count of project
	@Query(nativeQuery = true, value = "select count(otf.ot_id) from ot_form otf inner join ot_form_ot_team ott on otf.ot_id=ott.ot_team_ot_id inner join team_structure ts on ott.ot_team_struct_id = ts.struct_id  where ts.project_id = :pj and  otf.inbox_status=\"Approved\"")
	int getCountOfProject(@Param("pj") String pj);

	// get all count of project between dates
	@Query(nativeQuery = true, value = "select count( otf.ot_id) from ot_form otf inner join ot_form_ot_team ott on otf.ot_id=ott.ot_team_ot_id inner join team_structure ts on ott.ot_team_struct_id = ts.struct_id  where created_time between :sd and :ed and ts.project_id = :pj and  otf.inbox_status=\"Approved\"")
	int getCountOfProjectWithDate(@Param("pj") String pj, @Param("sd") String sd, @Param("ed") String ed);

	// get ot cost by project
	@Query(nativeQuery = true, value = "select otf.salary from ot_form otf inner join ot_form_ot_team ott on ott.ot_team_ot_id = otf.ot_id inner join team_structure ts on ott.ot_team_struct_id = ts.struct_id where otf.inbox_status=\"Approved\" and ts.project_id=:pj")
	double[] getCostOfProject(@Param("pj") String pj);

	// get ot cost by project with date
	@Query(nativeQuery = true, value = "select otf.salary from ot_form otf inner join ot_form_ot_team ott on ott.ot_team_ot_id = otf.ot_id inner join team_structure ts on ott.ot_team_struct_id = ts.struct_id where otf.inbox_status=\"Approved\" and ts.project_id=:pj and created_time between  :sd and :ed")
	double[] getCostOfProjectWithDate(@Param("pj") String pj, @Param("sd") String sd, @Param("ed") String ed);

	// get approved ot forms by user
	@Query(value = "select * from ot_form otf inner join ot_form_ot_team ott on ott.ot_team_ot_id=otf.ot_id inner join team_structure ts on ott.ot_team_struct_id=ts.struct_id where ts.staff_id= :staffid and otf.inbox_status=\"approved\"", nativeQuery = true)
	List<Object> getApprovedFormsForUserHistory(@Param("staffid") String staffId);

	@Query(nativeQuery = true, value = "select *  from ot_form,ot_form_ot_team,team_structure where ot_id = ot_team_ot_id and ot_team_struct_id = struct_id and sent_to = :staffId  and inbox_status='Approved'")
	  List<Object> HRfindApprovedForHistory(@Param("staffId") String staffId);

	  @Query(nativeQuery = true, value = "select *  from ot_form,ot_form_ot_team,team_structure where ot_id = ot_team_ot_id and ot_team_struct_id = struct_id and sent_to = :staffId  and inbox_status='Rejected'")
	  List<Object> HRfindRejectedForHistory(@Param("staffId") String staffId);

	  // jasper
	  @Query(nativeQuery = true, value = "select day,finish_hour,finish_act_hour,form_id,ot_date,ot_act_date,reason,salary,start_hour,start_act_hour,total_hour,name,s.position,project_id,signature,staff_id,status,s.approve_by,s.updated_time,team.struct_id from  ot_form f, ot_form_ot_team t,team_structure team,status s where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and form_id =:formId and check_delete=0")
	  List<Object> findDataForJasper(@Param("formId") String formId);
	  // and s.ot_id=f.ot_id

	  // revised
	  @Query(nativeQuery = true, value = "select * from ot_form where form_id=?1")
	  OtFormDTO findByReviseFile(String formId);

	  // for Inbox Response
	  @Query(nativeQuery = true, value = "select project_id,form_id,ot_date,start_hour,finish_hour,ot_act_date,start_act_hour,finish_act_hour,reason,total_hour from ot_form,ot_form_ot_team,team_structure where ot_id = ot_team_ot_id and ot_team_struct_id = struct_id and form_id=:formId group by inbox_status")
	  List<Object> forInboxResponse(@Param("formId") String formId);

	  // for All Signature
	  @Query(nativeQuery = true, value = "select s.position,s.status,s.updated_time from  ot_form f, ot_form_ot_team t,team_structure team,status s where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and s.ot_id=f.ot_id and form_id =:formId")
	  List<Object> forAllApproved1(@Param("formId") String formId);

	  // for details in myOTList
	  @Query(nativeQuery = true, value = "select inbox_status from ot_form ot,ot_form_ot_team o,team_structure t where ot.ot_id = o.ot_team_ot_id and o.ot_team_struct_id = t.struct_id and (ot.inbox_status='Revised' or ot.inbox_status = 'Requested') and ot.form_id =:formId")
	  OtFormDTO fetchDetailsMyOTForm(@Param("formId") String formId);

	  // for All Signature
	  @Query(nativeQuery = true, value = "select ts.name,ts.signature,st.status,ts.position,st.updated_time from status st inner join ot_form otf on st.ot_id = otf.ot_id inner join team_structure ts on st.approve_by=ts.staff_id where  otf.form_id=:formId group by name")
	  List<Object> forAllSignatureApproved(@Param("formId") String formId);

	  // for Request People Signature
	  @Query(nativeQuery = true, value = "select team.name,s.position,f.created_time,team.signature,s.status from ot_form f, ot_form_ot_team t,team_structure team,status s where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and s.ot_id=f.ot_id and s.approve_by = team.staff_id and s.ot_form_id = :formId and check_delete = 0 and s.status = 'Requested'")
	  List<Object> forRequest(@Param("formId") String formId);
	  
	// query for Inbox
	  @Query(nativeQuery = true, value = "select team.project_id,team.name,f.ot_date,f.form_id,f.inbox_status,f.sent_to from  ot_form f, ot_form_ot_team t,team_structure team where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and  f.sent_to = :staffId and (f.inbox_status = 'Requested' or f.inbox_status = 'Revised') and check_delete = 0 order by updated_time desc")
	  List<Object> findAllOtFormData(@Param("staffId") String staffId);

	  // for search inbox
	  @Query(nativeQuery = true, value = "select * from team_structure s,ot_form ot, ot_form_ot_team where ot_id = ot_team_ot_id and ot_team_struct_id = struct_id and sent_to = :staffId and (inbox_status = 'Requested' or inbox_status = 'Revised') and (s.name LIKE CONCAT('%',:name,'%') or s.staff_id LIKE CONCAT('%',:name,'%') or s.team_name LIKE CONCAT('%',:name,'%') or s.position LIKE CONCAT('%',:name,'%') or s.project_id LIKE CONCAT('%',:name,'%')) and s.check_delete=0 order by s.position asc")
	  List<Object> findByNameInbox(@Param("name") String name, @Param("staffId") String staffId, Pageable pageable);

	  // for search otlist
	  @Query(nativeQuery = true, value = "select * from team_structure s,ot_form ot, ot_form_ot_team where ot_id = ot_team_ot_id and ot_team_struct_id = struct_id and staff_id = :staffId and (inbox_status = 'Requested' or inbox_status = 'Revised') and (s.name LIKE CONCAT('%',:name,'%') or s.staff_id LIKE CONCAT('%',:name,'%') or s.team_name LIKE CONCAT('%',:name,'%') or s.position LIKE CONCAT('%',:name,'%') or s.project_id LIKE CONCAT('%',:name,'%')) and s.check_delete=0 order by s.position asc")
	  List<Object> findByNameMyOTList(@Param("name") String name, @Param("staffId") String staffId, Pageable pageable);

	  // for all Preview
	  @Query(nativeQuery = true, value = "select * from  ot_form f, ot_form_ot_team t,team_structure team where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and form_id = :formId and check_delete = 0")
	  List<Object> findAllData(@Param("formId") String formId);

	  // for my otlist
	  @Query(nativeQuery = true, value = "select * from  ot_form f, ot_form_ot_team t,team_structure team where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and staff_id = :staffId and (inbox_status = 'Requested' or inbox_status = 'Revised') and check_delete = 0")
	  List<Object> findAllDataApplier(@Param("staffId") String staffId);

	  @Query(nativeQuery = true, value = "select * from ot_form where ot_id = ?1")
	  OtFormDTO findByOtId(Integer id);

	  // for Approved in history
	  @Query(nativeQuery = true, value = "select * from  ot_form f, ot_form_ot_team t,team_structure team where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and staff_id = :staffId and inbox_status = 'Approved' and check_delete = 0")
	  List<Object> findMyOTFormApprovedHistory(@Param("staffId") String staffId);

	  // for rejected in history
	  @Query(nativeQuery = true, value = "select * from  ot_form f, ot_form_ot_team t,team_structure team where t.ot_team_ot_id = f.ot_id and t.ot_team_struct_id = team.struct_id and staff_id = :staffId and inbox_status = 'Rejected' and check_delete = 0")
	  List<Object> findMyOTFormRejectedHistory(@Param("staffId") String staffId);

	  // for details approved
	  @Query(nativeQuery = true, value = "select *  from ot_form,ot_form_ot_team,team_structure where ot_id = ot_team_ot_id and ot_team_struct_id = struct_id and staff_id = :staffId  and inbox_status='Approved'")
	  List<Object> findApprovedForHistory(@Param("staffId") String staffId);

	  // for details rejected
	  @Query(nativeQuery = true, value = "select *  from ot_form,ot_form_ot_team,team_structure where ot_id = ot_team_ot_id and ot_team_struct_id = struct_id and staff_id = :staffId  and inbox_status='Rejected'")
	  List<Object> findRejectedForHistory(@Param("staffId") String staffId);
	  
	  

}
