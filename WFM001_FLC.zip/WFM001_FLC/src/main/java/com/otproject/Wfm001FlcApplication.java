package com.otproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Wfm001FlcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Wfm001FlcApplication.class, args);
	}

}
