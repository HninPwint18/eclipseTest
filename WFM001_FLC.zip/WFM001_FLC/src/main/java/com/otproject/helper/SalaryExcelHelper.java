package com.otproject.helper;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.otproject.dto.Position;

public class SalaryExcelHelper {
	public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	  static String[] HEADERs = { "No", "Name", "StaffID", "Position","Basic Pay" };
	  static String SHEET = "Sheet1";
	  public static boolean hasExcelFormat(MultipartFile file) {
	    if (!TYPE.equals(file.getContentType())) {
	      return false;
	    }
	    return true;
	  }
	  public static List<Position> excelToSalary(InputStream is) {
	    try {
	      Workbook workbook = new XSSFWorkbook(is);
	      Sheet sheet = workbook.getSheet(SHEET);
	      Iterator<Row> rows = sheet.iterator();
	      List<Position> positionList = new ArrayList<Position>();
	      int rowNumber = 0;
	      List<String> storeList = new ArrayList<String>();
	      int positionId=0;
	      while (rows.hasNext()) {
	    	 String positionName=null;
	        Row currentRow = rows.next();
	        // skip header
	        if (rowNumber == 0) {
	          rowNumber++;
	          continue;
	        }
	        Iterator<Cell> cellsInRow = currentRow.iterator();
	        Position position = new Position();
	        int cellIdx = 0;
	        while (cellsInRow.hasNext()) {
	        	int count =0;
		          Cell currentCell = cellsInRow.next();
		          switch (cellIdx) {
		          case 3:
		        	  storeList.add(currentCell.getStringCellValue());
		        	  for(String store:storeList) {
		        		  if(store.equals(currentCell.getStringCellValue())) {
		        			  count++;
		        		  }
		        	  }
		        	  
		        	  if(count==1) {
		        		  position.setPositionName(currentCell.getStringCellValue());
		        		  positionName=currentCell.getStringCellValue();
		        		  positionId++;
		        		  position.setPositionId(positionId);
		        		  count=0;
		        		 
		        	  }
		            break;
		          case 4:
		        	  for(String store:storeList) {
		        		  if(store.equals(positionName)){
		        			  count++;
		        		  }
		        	  }
		        	  
		        	  if(count==1) {
		        		  position.setSalary(currentCell.getNumericCellValue());
		        		  count=0;
		        	  }
		            break;
		          default:
		            break;
		          }
		          cellIdx++;
	        }
	        positionList.add(position);
	      }
	      workbook.close();
	      return positionList;
	    } catch (IOException e) {
	      throw new RuntimeException("fail to parse Salary Excel file: " + e.getMessage());
	    }
	  }
}
