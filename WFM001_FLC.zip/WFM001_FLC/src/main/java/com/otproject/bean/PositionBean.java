package com.otproject.bean;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

public class PositionBean {
	
	@Min(1)
	private Integer positionId;
	@NotEmpty
	private String positionName;
	@NotEmpty
	private double salary;
	
	public Integer getPositionId() {
		return positionId;
	}
	public void setPositionId(Integer positionId) {
		this.positionId = positionId;
	}
	public String getPositionName() {
		return positionName;
	}
	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
