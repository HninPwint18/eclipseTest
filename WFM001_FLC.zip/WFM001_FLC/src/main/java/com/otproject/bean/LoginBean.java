package com.otproject.bean;

import javax.validation.constraints.NotEmpty;

public class LoginBean {
	
	@NotEmpty
	private String staffId;
	@NotEmpty
	private String password;
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
