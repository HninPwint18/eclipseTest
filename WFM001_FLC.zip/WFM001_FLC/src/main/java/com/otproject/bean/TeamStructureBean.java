package com.otproject.bean;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

public class TeamStructureBean {
	@Min(1)
	private Integer structId;
	@NotEmpty
	private String name;
	@NotEmpty
	private String staffId;
	@NotEmpty
	private String team;
	@NotEmpty
	private String position;
	@NotEmpty
	private String project;

	private String signature;
	
	private Integer checkDelete;
	
	public Integer getCheckDelete() {
		return checkDelete;
	}
	public void setCheckDelete(Integer checkDelete) {
		this.checkDelete = checkDelete;
	}
	public Integer getStructId() {
		return structId;
	}
	public void setStructId(Integer d) {
		this.structId = d;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
}
