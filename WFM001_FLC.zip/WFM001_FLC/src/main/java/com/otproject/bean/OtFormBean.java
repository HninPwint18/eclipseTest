package com.otproject.bean;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Set;

import javax.validation.constraints.Min;

import com.otproject.dto.TeamStructure;

public class OtFormBean {
	@Min(1)
	private Integer id;
	private String formId;
	
	private Date otDate;
	
	private Date otDateActual;

	private String startHour;
	
	private String startHourActual;

	private String finishHour;
	
	private String finishHourActual;

	private String totalHour;

	private String day;
	
	private String reason;
	
	private BigDecimal salary;
	
	private String inboxStatus;
	
	private String filename;
	
	private LocalDateTime createdTime;
	
	private LocalDateTime updatedTime;
	
	private Set<TeamStructure> otTeam;
	
	private String signature;


	private String sentTo;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public Date getOtDate() {
		return otDate;
	}

	public void setOtDate(Date otDate) {
		this.otDate = otDate;
	}

	public String getStartHour() {
		return startHour;
	}

	public void setStartHour(String startHour) {
		this.startHour = startHour;
	}

	public String getFinishHour() {
		return finishHour;
	}

	public void setFinishHour(String finishHour) {
		this.finishHour = finishHour;
	}

	public String getTotalHour() {
		return totalHour;
	}

	public void setTotalHour(String totalHour) {
		this.totalHour = totalHour;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public String getInboxStatus() {
		return inboxStatus;
	}

	public void setInboxStatus(String inboxStatus) {
		this.inboxStatus = inboxStatus;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public LocalDateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}

	public LocalDateTime getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(LocalDateTime updatedTime) {
		this.updatedTime = updatedTime;
	}

	public Set<TeamStructure> getOtTeam() {
		return otTeam;
	}

	public void setOtTeam(Set<TeamStructure> otTeam) {
		this.otTeam = otTeam;
	}

	public String getSentTo() {
		return sentTo;
	}

	public void setSentTo(String sentTo) {
		this.sentTo = sentTo;
	}

	
	public Date getOtDateActual() {
		return otDateActual;
	}

	public void setOtDateActual(Date otDateActual) {
		this.otDateActual = otDateActual;
	}

	public String getStartHourActual() {
		return startHourActual;
	}

	public void setStartHourActual(String startHourActual) {
		this.startHourActual = startHourActual;
	}

	public String getFinishHourActual() {
		return finishHourActual;
	}

	public void setFinishHourActual(String finishHourActual) {
		this.finishHourActual = finishHourActual;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	
}
