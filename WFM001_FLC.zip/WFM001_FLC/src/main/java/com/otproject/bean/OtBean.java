package com.otproject.bean;

import java.sql.Date;

import javax.validation.constraints.NotEmpty;

public class OtBean {
	@NotEmpty(message = "idk testing")
	private String id;

	private double fees;
	private String project;
	private Date start_date;
	private Date end_date;

	public String getId() {
		return id;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

}
