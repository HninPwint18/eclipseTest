package com.otproject.dto;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Transient;


public class JoinDTO {
	
	@Transient
	  public String getPhotosImagePath() {
	    if (signature == null || structId == null)
	      return null;

	    return "/staff-signature/" + structId + "/" + signature;
	  }
	
	
	private String allId;
	
	private Integer otId;
	
	private String formId;
	
	private Date otDate;
	
	private Date otDateActual;

	private String startHour;

	private String startHourActual;

	private String finishHour;

	private String finishHourActual;

	private String totalHour;

	private String day;

	private String reason;
	
	@Column(name="salary",precision = 10,scale = 2)
	private BigDecimal salary;

	private String inboxStatus;

	private String filename;

	private String createdTime;

	private String updatedTime;
	
	private BigDecimal fees;

	public BigDecimal getFees() {
		return fees;
	}

	public void setFees(BigDecimal fees) {
		this.fees = fees;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public String getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}


	private String sentTo;
	
	private Integer structId;
	
	private String name;

	private String staffId;
	
	private String team;

	private String position;

	private String project;

	private String signature;
	
	private Integer statusId;
	
	private String remark;
	
	private String status;
	
	private String response;
	
	private String stsformId;
	
	private String stsposition;
	
    
    public String getStsformId() {
		return stsformId;
	}

	public void setStsformId(String stsformId) {
		this.stsformId = stsformId;
	}

	public String getStsposition() {
		return stsposition;
	}

	public void setStsposition(String stsposition) {
		this.stsposition = stsposition;
	}


	private Set<TeamStructure> otTeam;
    
	
	public Set<TeamStructure> getOtTeam() {
		return otTeam;
	}

	public void setOtTeam(Set<TeamStructure> otTeam) {
		this.otTeam = otTeam;
	}


	@Column(name="check_delete",columnDefinition = "integer default 0")
	private Integer checkDelete;

	public JoinDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}


	public String getAllId() {
		return allId;
	}


	public void setAllId(String allId) {
		this.allId = allId;
	}


	public Integer getOtId() {
		return otId;
	}


	public void setOtId(Integer otId) {
		this.otId = otId;
	}


	public String getFormId() {
		return formId;
	}


	public void setFormId(String formId) {
		this.formId = formId;
	}


	public Date getOtDate() {
		return otDate;
	}


	public void setOtDate(Date otDate) {
		this.otDate = otDate;
	}


	public Date getOtDateActual() {
		return otDateActual;
	}


	public void setOtDateActual(Date otDateActual) {
		this.otDateActual = otDateActual;
	}


	public String getStartHour() {
		return startHour;
	}


	public void setStartHour(String startHour) {
		this.startHour = startHour;
	}


	public String getStartHourActual() {
		return startHourActual;
	}


	public void setStartHourActual(String startHourActual) {
		this.startHourActual = startHourActual;
	}


	public String getFinishHour() {
		return finishHour;
	}


	public void setFinishHour(String finishHour) {
		this.finishHour = finishHour;
	}


	public String getFinishHourActual() {
		return finishHourActual;
	}


	public void setFinishHourActual(String finishHourActual) {
		this.finishHourActual = finishHourActual;
	}


	public String getTotalHour() {
		return totalHour;
	}


	public void setTotalHour(String totalHour) {
		this.totalHour = totalHour;
	}


	public String getDay() {
		return day;
	}


	public void setDay(String day) {
		this.day = day;
	}


	public String getReason() {
		return reason;
	}


	public void setReason(String reason) {
		this.reason = reason;
	}


	public BigDecimal getSalary() {
		return salary;
	}


	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}


	public String getInboxStatus() {
		return inboxStatus;
	}


	public void setInboxStatus(String inboxStatus) {
		this.inboxStatus = inboxStatus;
	}


	public String getFilename() {
		return filename;
	}


	public void setFilename(String filename) {
		this.filename = filename;
	}


//	public String getCreatedTime() {
//		return createdTime;
//	}
//
//
//	public void setCreatedTime(String createdTime) {
//		this.createdTime = createdTime;
//	}
//
//
//	public String getUpdatedTime() {
//		return updatedTime;
//	}
//
//
//	public void setUpdatedTime(String updatedTime) {
//		this.updatedTime = updatedTime;
//	}


	public String getSentTo() {
		return sentTo;
	}


	public void setSentTo(String sentTo) {
		this.sentTo = sentTo;
	}


	public Integer getStructId() {
		return structId;
	}


	public void setStructId(Integer structId) {
		this.structId = structId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getStaffId() {
		return staffId;
	}


	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}


	public String getTeam() {
		return team;
	}


	public void setTeam(String team) {
		this.team = team;
	}


	public String getPosition() {
		return position;
	}


	public void setPosition(String position) {
		this.position = position;
	}


	public String getProject() {
		return project;
	}


	public void setProject(String project) {
		this.project = project;
	}


	public String getSignature() {
		return signature;
	}


	public void setSignature(String signature) {
		this.signature = signature;
	}


	public Integer getCheckDelete() {
		return checkDelete;
	}


	public void setCheckDelete(Integer checkDelete) {
		this.checkDelete = checkDelete;
	}

	

	
}
