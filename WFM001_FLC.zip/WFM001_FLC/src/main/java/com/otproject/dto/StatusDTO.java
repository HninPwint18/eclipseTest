package com.otproject.dto;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="status")
public class StatusDTO {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="approve_id")
	private Integer id;
	
	@Column(name="updated_time")
	private LocalDateTime updateTime;
	
	@Column(name="remark")
	private String remark;
	
	@Column(name="status",columnDefinition="VARCHAR(10)")
	private String status;
	
	@Column(name = "approve_by")
	private String response;
	
	@Column(name =  "ot_id")
    private Integer otFormId;

	@Column(name = "ot_form_id")
	private String form_id;
	
	@Column(name = "position")
	private String position;
	
	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getForm_id() {
		return form_id;
	}

	public void setForm_id(String form_id) {
		this.form_id = form_id;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(LocalDateTime localDateTime) {
		this.updateTime = localDateTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getOtFormId() {
		return otFormId;
	}

	public void setOtFormId(Integer otFormId) {
		this.otFormId = otFormId;
	}

	


	
}
