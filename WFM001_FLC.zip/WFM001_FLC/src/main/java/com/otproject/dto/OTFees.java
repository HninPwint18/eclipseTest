package com.otproject.dto;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ot_fees")
public class OTFees {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="fees_id")
	private Integer feesId;
	
	@Column(name="form_id")
	private String feesformId;
	
	@Column(name="ot_id")
	private Integer otId;
	
	@Column(name="position")
	private String position;
	
	@Column(name="fees")
	private BigDecimal fees;

	public Integer getFeesId() {
		return feesId;
	}

	public void setFeesId(Integer feesId) {
		this.feesId = feesId;
	}

	public String getFeesformId() {
		return feesformId;
	}

	public void setFeesformId(String feesformId) {
		this.feesformId = feesformId;
	}

	public Integer getOtId() {
		return otId;
	}

	public void setOtId(Integer otId) {
		this.otId = otId;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public BigDecimal getFees() {
		return fees;
	}

	public void setFees(BigDecimal fees) {
		this.fees = fees;
	}



}
