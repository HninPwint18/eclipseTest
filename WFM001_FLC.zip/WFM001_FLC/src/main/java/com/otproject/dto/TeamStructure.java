package com.otproject.dto;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="team_structure")
public class TeamStructure {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="struct_id")
	private Integer structId;
	
	@Column(name="name")
	private String name;
	  
	@Column(name="staff_id")
	private String staffId;
	
	@Column(name="team_name")
	private String team;
	
	@Column(name="position")
	private String position;
	
	@Column(name="project_id")
	private String project;
	
	@Column(name="signature")
	private String signature;
	
	@Column(name="check_delete",columnDefinition = "integer default 0")
	private Integer checkDelete;

	@ManyToMany(mappedBy = "otTeam")
	private Set<OtFormDTO> otTeam;
	
    public TeamStructure() {
    	
    }
	
	public Integer getCheckDelete() {
		return checkDelete;
	}
	public void setCheckDelete(Integer checkDelete) {
		this.checkDelete = checkDelete;
	}
	public Integer getStructId() {
		return structId;
	}
	public void setStructId(Integer d) {
		this.structId = d;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getTeam() {
		return team;
	}
	public void setTeam(String team) {
		this.team = team;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}

	public Set<OtFormDTO> getOtTeam() {
		return otTeam;
	}

	public void setOtTeam(Set<OtFormDTO> otTeam) {
		this.otTeam = otTeam;
	}
	
	@Transient
    public String getPhotosImagePath() {
        if (signature == null || structId == null) return null;
         
        return "/staff-signature/" + structId + "/" + signature;
    }

	
}
