package com.otproject.dto;


import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="ot_form")
public class OtFormDTO {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ot_id")
	private Integer id;
	
	@Column(name="form_id")
	private String formId;
	
	@Column(name="ot_date")
	private Date otDate;
	
	@Column(name="ot_act_date")
	private Date otDateActual;
	
	@Column(name="start_hour")
	private String startHour;
	
	@Column(name="start_act_hour")
	private String startHourActual;
	
	@Column(name="finish_hour")
	private String finishHour;
	
	@Column(name="finish_act_hour")
	private String finishHourActual;
	
	@Column(name="total_hour")
	private String totalHour;
	
	@Column(name="day")
	private String day;
	
	@Column(name="reason")
	private String reason;
	
	@Column(name="salary",precision = 10,scale = 2)
	private BigDecimal salary;
	
	@Column(name="inbox_status")
	private String inboxStatus;
	
	@Column(name="filename")
	private String filename;
	
	@Column(name="created_time")
	private LocalDateTime createdTime;
	
	@Column(name="updated_time")
	private LocalDateTime updatedTime;
	
	@Column(name="sent_to")
	private String sentTo;

	@ManyToMany(cascade = CascadeType.PERSIST)
	private Set<TeamStructure> otTeam;
    
	public OtFormDTO() {
    	
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public Date getOtDate() {
		return otDate;
	}

	public void setOtDate(Date otDate) {
		this.otDate = otDate;
	}

	public String getStartHour() {
		return startHour;
	}

	public void setStartHour(String startHour) {
		this.startHour = startHour;
	}

	public String getFinishHour() {
		return finishHour;
	}

	public void setFinishHour(String finishHour) {
		this.finishHour = finishHour;
	}

	public String getTotalHour() {
		return totalHour;
	}

	public void setTotalHour(String totalHour) {
		this.totalHour = totalHour;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public String getInboxStatus() {
		return inboxStatus;
	}

	public void setInboxStatus(String inboxStatus) {
		this.inboxStatus = inboxStatus;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public LocalDateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}

	public LocalDateTime getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(LocalDateTime updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getSentTo() {
		return sentTo;
	}

	public void setSentTo(String sentTo) {
		this.sentTo = sentTo;
	}

	public Set<TeamStructure> getOtTeam() {
		return otTeam;
	}

	public void setOtTeam(Set<TeamStructure> otTeam) {
		this.otTeam = otTeam;
	}

	public Date getOtDateActual() {
		return otDateActual;
	}

	public void setOtDateActual(Date otDateActual) {
		this.otDateActual = otDateActual;
	}

	public String getStartHourActual() {
		return startHourActual;
	}

	public void setStartHourActual(String startHourActual) {
		this.startHourActual = startHourActual;
	}

	public String getFinishHourActual() {
		return finishHourActual;
	}

	public void setFinishHourActual(String finishHourActual) {
		this.finishHourActual = finishHourActual;
	}
	
}
