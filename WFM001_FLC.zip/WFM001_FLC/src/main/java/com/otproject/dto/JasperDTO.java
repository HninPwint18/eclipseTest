package com.otproject.dto;

import java.math.BigDecimal;
import java.sql.Date;

public class JasperDTO {
	
	private String formId;
	
	private Date otDate;
	
	private Date otDateActual;
	
	private String startHour;
	
	private String startHourActual;
	
	private String finishHour;
	
	private String finishHourActual;
	
	private String totalHour;
	
	private String day;
	
	private String reason;
	
	private BigDecimal salary;
	
	private String approvedBy;
	
	private String status;
	
	private String name;
	  
	private String staffId;
	
	private String project;
	
	private String signature;
	
	private String position;
	
	private String updatedTime;

	public String getFormId() {
		return formId;
	}

	public void setFormId(String formId) {
		this.formId = formId;
	}

	public Date getOtDate() {
		return otDate;
	}

	public void setOtDate(Date otDate) {
		this.otDate = otDate;
	}

	public Date getOtDateActual() {
		return otDateActual;
	}

	public void setOtDateActual(Date otDateActual) {
		this.otDateActual = otDateActual;
	}

	public String getStartHour() {
		return startHour;
	}

	public void setStartHour(String startHour) {
		this.startHour = startHour;
	}

	public String getStartHourActual() {
		return startHourActual;
	}

	public void setStartHourActual(String startHourActual) {
		this.startHourActual = startHourActual;
	}

	public String getFinishHour() {
		return finishHour;
	}

	public void setFinishHour(String finishHour) {
		this.finishHour = finishHour;
	}

	public String getFinishHourActual() {
		return finishHourActual;
	}

	public void setFinishHourActual(String finishHourActual) {
		this.finishHourActual = finishHourActual;
	}

	public String getTotalHour() {
		return totalHour;
	}

	public void setTotalHour(String totalHour) {
		this.totalHour = totalHour;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	
	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}

	
	
	

}
