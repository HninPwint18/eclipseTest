package com.otproject.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.bean.TeamStructureBean;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.TeamStructureRepository;
import com.otproject.service.SalaryExcelService;
import com.otproject.service.TeamExcelService;

@Controller
public class STF001Controller {

	@Autowired
	LGN001Controller loginController;

	@Autowired
	private TeamStructureRepository teamRepo;

	@Autowired
	TeamExcelService teamExcelService;

	@Autowired
	SalaryExcelService salaryExcelService;

	@ModelAttribute("projectList")
	public Map<String, String> projectList() {
		Map<String, String> projectList = new HashMap<String, String>();
		projectList = teamExcelService.selectAllProjectId();
		return projectList;
	}

	@ModelAttribute("teamListDropDown")
	public Map<String, String> teamListDropDown() {
		Map<String, String> teamListDropDown = new HashMap<String, String>();
		teamListDropDown = teamExcelService.selectAllTeam();
		return teamListDropDown;
	}

	@ModelAttribute("positionList")
	public Map<String, String> positionList() {
		Map<String, String> positionList = new HashMap<String, String>();
		positionList = salaryExcelService.selectAllPosition();
		return positionList;
	}

	@GetMapping("/teamStructure")
	public ModelAndView teamStructurePage(Model model, HttpSession session, RedirectAttributes reatt,
			@RequestParam(defaultValue = "0") int page) {

		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}
		Pageable pageable = PageRequest.of(page, 10);

		model.addAttribute("teamList", teamRepo.findAllWithCheck(pageable));
		model.addAttribute("currentPage", page);

		return new ModelAndView("STF001", "teamBean", new TeamStructureBean());
	}

	@PostMapping("/delete")
	public String deleteTeam(@ModelAttribute("teamBean") TeamStructureBean bean, HttpSession session, ModelMap model,
			RedirectAttributes redirectAtt) {
		if (session.getAttribute("sessionUser") == null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}

		TeamStructure dto = new TeamStructure();
		dto.setStructId(bean.getStructId());
		dto.setName(bean.getName());
		dto.setStaffId(bean.getStaffId());
		dto.setProject(bean.getProject());
		dto.setTeam(bean.getTeam());
		dto.setPosition(bean.getPosition());
		dto.setCheckDelete(bean.getCheckDelete());

		teamExcelService.updateTeam(dto, bean.getStructId());
		redirectAtt.addFlashAttribute("message", "Deleted Successfully.");
		return "redirect:/teamStructure";
	}

	@GetMapping("/findOne")
	@ResponseBody
	public TeamStructure findOne(Integer id) {

		return teamRepo.findByStructId(id);
	}

	@PostMapping("/update")
	public String update(@ModelAttribute("teamBean") @Validated TeamStructureBean bean, BindingResult result,
			HttpSession session, RedirectAttributes redirectAtt) {
		if (session.getAttribute("sessionUser") == null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		if (result.hasErrors()) {
			redirectAtt.addFlashAttribute("message", "Warning ! ,Please fill all fields for update. Try Again.");
			return "redirect:/teamStructure";
		}

		TeamStructure dto = new TeamStructure();
		dto.setStructId(bean.getStructId());
		dto.setName(bean.getName());
		dto.setStaffId(bean.getStaffId());
		dto.setProject(bean.getProject());
		dto.setTeam(bean.getTeam());
		dto.setPosition(bean.getPosition());
		dto.setCheckDelete(0);

		teamExcelService.updateTeam(dto, bean.getStructId());
		redirectAtt.addFlashAttribute("message", "Updated Successfully.");
		return "redirect:/teamStructure";
	}

	@PostMapping("/search")
	public String search(@ModelAttribute("teamBean") @Validated TeamStructureBean bean, BindingResult result,HttpSession session,
			RedirectAttributes redirectAtt, ModelMap model, @RequestParam(defaultValue = "0") int page) {
		if (session.getAttribute("sessionUser") == null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		if (bean.getName().equals("")) {
			return "redirect:/teamStructure";
		}

		Pageable pageable = PageRequest.of(page, 9999);
		Page<TeamStructure> teamList = teamRepo.findByName(bean.getName(), pageable);
		if (teamList.isEmpty()) {
			model.addAttribute("message", "Search name ' " + bean.getName() + " ' not Found.");
			model.addAttribute("teamList", teamList);
			return "STF001";
		} else {
			model.addAttribute("teamList", teamList);
			model.addAttribute("message", "You search by ' " + bean.getName() + " '.");
			return "STF001";
		}

	}

}
