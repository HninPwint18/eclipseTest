package com.otproject.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.dateBean;
import com.otproject.dto.TeamStructure;
import com.otproject.service.OtFormService;
import com.otproject.service.TeamExcelService;

@Controller
public class DSHController {

	@Autowired
	private OtFormService otService;

	@Autowired
	LGN001Controller lgnc;

	@Autowired
	TeamExcelService tes;

	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String testing(ModelMap model,HttpSession session, RedirectAttributes reatt) {
		
		if(session.getAttribute("sessionUser") ==null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		
//		for user profile
		TeamStructure staffData = tes.selectStaffId(lgnc.getStaffId().getStaffId());
		List<String> project = tes.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		
		dateBean bean = new dateBean();

		List<String> projects = tes.selectAllProject(lgnc.getStaffId().getStaffId());
		int[] count = new int[projects.size()];
		for (int i = 0; i < projects.size(); i++) {
			count[i] = otService.getCountOfProject(projects.get(i));
			System.out.println(projects.get(i) + " << << << << ");
		}
		model.addAttribute("projects", projects);
		model.addAttribute("count", count);
		model.addAttribute("bean", bean);
		System.out.println("<<<<< rm runned >>>>>");



		return "DSH001";

	}

	@PostMapping("/dsh001/date")
	public String DSH001withDate(@ModelAttribute("bean") @Validated dateBean bean, HttpSession session, RedirectAttributes reatt, BindingResult result, ModelMap model)
			throws IOException {
		
		if(session.getAttribute("sessionUser") ==null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		bean.getStart_date();
		String sd = bean.getStart_date() + " 00:00:00";
		String ed = bean.getEnd_date() + " 00:00:00";

		List<String> projects = tes.selectAllProject(lgnc.getStaffId().getStaffId());

		int[] count = new int[projects.size()];
		for (int i = 0; i < projects.size(); i++) {
			count[i] = otService.getCountOfProjectWithDate(projects.get(i), sd, ed);
		}
		model.addAttribute("bean", bean);
		model.addAttribute("count", count);
		model.addAttribute("projects", projects);
		return "DSH001";
	}

	@RequestMapping(value = "/hrdashboard", method = RequestMethod.GET)
	public String DSH003(ModelMap model, HttpSession session, RedirectAttributes reatt) {
		if(session.getAttribute("sessionUser") ==null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		
//		for user profile
		TeamStructure staffData = tes.selectStaffId(lgnc.getStaffId().getStaffId());
		List<String> project = tes.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		
		System.out.println("RM RUNNED");
		dateBean bean = new dateBean();
		String[] projects = otService.getProjectsForCount();

		int[] count = new int[projects.length];
		double[] cost = new double[projects.length];

		for (int i = 0; i < projects.length; i++) {
			count[i] = otService.getCountOfProject(projects[i]);
			if (count[i] == 0) {
				System.out.println(" Project :" + projects[i] + " is " + count[i] + " so not gonna find it's sum");
				cost[i] = 0;
			}
			if (count[i] > 0) {
				double rs[] = otService.getCostOfProject(projects[i]);
				double sum = 0;
				for (int x = 0; x < rs.length; x++) {
					sum = sum + rs[x];
				}

				cost[i] = sum;
			}
		}
//		System.out.println("Projects >>> ");
//		for (int i = 0; i < projects.length; i++) {
//			System.out.println(projects[i]+" <<< ");
//		}
//		System.out.println("counts >>> ");
//		for (int i = 0; i < projects.length; i++) {
//			System.out.println(count[i]+" <<< ");
//		}
//		System.out.println("cost >>> ");
//		for (int i = 0; i < projects.length; i++) {
//			System.out.println(cost[i]+" <<< ");
//		}

		model.addAttribute("projects", projects);
		model.addAttribute("count", count);
		model.addAttribute("cost", cost);
		model.addAttribute("bean", bean);

		return "DSH003";
	}

	@PostMapping("/dsh003/date")
	public String DSH003withDate(@ModelAttribute("bean") @Validated dateBean bean,HttpSession session, RedirectAttributes reatt, BindingResult result, ModelMap model)
			throws IOException {
		
		if(session.getAttribute("sessionUser") ==null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		
		bean.getStart_date();
		String sd = bean.getStart_date() + " 00:00:00";
		String ed = bean.getEnd_date() + " 23:59:59";

		String[] projects = otService.getProjectsForCount();

		int[] count = new int[projects.length];
		double[] cost = new double[projects.length];

		for (int i = 0; i < projects.length; i++) {
			count[i] = otService.getCountOfProjectWithDate(projects[i], sd, ed);

			double rs[] = otService.getCostOfProjectWithDate(projects[i], sd, ed);
			double sum = 0;
			for (int x = 0; x < rs.length; x++) {
				sum = sum + rs[x];
			}
			cost[i] = sum;
		}

		System.out.println("Projects >>> ");
		for (int i = 0; i < projects.length; i++) {
			System.out.println(projects[i] + " <<< ");
		}
		System.out.println("counts >>> ");
		for (int i = 0; i < projects.length; i++) {
			System.out.println(count[i] + " <<< ");
		}
		System.out.println("cost >>> ");
		for (int i = 0; i < projects.length; i++) {
			System.out.println(cost[i] + " <<< ");
		}
		model.addAttribute("bean", bean);
		model.addAttribute("count", count);
		model.addAttribute("cost", cost);
		model.addAttribute("projects", projects);

		return "DSH003";
	}

	@RequestMapping(value = "/adminDashboard", method = RequestMethod.GET)
	public String DSH004(ModelMap model,HttpSession session,RedirectAttributes reatt) {
		
		if(session.getAttribute("sessionUser") ==null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}

		dateBean bean = new dateBean();
		String[] projects = otService.getProjectsForCount();

		int[] count = new int[projects.length];
		double[] cost = new double[projects.length];

		for (int i = 0; i < projects.length; i++) {
			count[i] = otService.getCountOfProject(projects[i]);
			System.out.println(" count of this project "+projects[i]+ " << "+count[i]);
			if (count[i] == 0) {
				System.out.println(" Project :" + projects[i] + " is " + count[i] + " so not gonna find it's sum");
				cost[i] = 0;
			}
			if (count[i] > 0) {
				System.out.println("Finding cost now coz approved count is not zero");
				double rs[] = otService.getCostOfProject(projects[i]);
				double sum = 0;
				for (int x = 0; x < rs.length; x++) {
					sum = sum + rs[x];
				}

				cost[i] = sum;
			}
		}

		model.addAttribute("projects", projects);
		model.addAttribute("count", count);
		model.addAttribute("cost", cost);
		model.addAttribute("bean", bean);

		return "DSH004";
	}

	@PostMapping("/dsh004/date")
	public String DSH004withDate(@ModelAttribute("bean") @Validated dateBean bean, BindingResult result,HttpSession session, RedirectAttributes reatt, ModelMap model)
			throws IOException {
		
		if(session.getAttribute("sessionUser") ==null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		bean.getStart_date();
		String sd = bean.getStart_date() + " 00:00:00";
		String ed = bean.getEnd_date() + " 23:59:59";

		String[] projects = otService.getProjectsForCount();

		int[] count = new int[projects.length];
		double[] cost = new double[projects.length];

		for (int i = 0; i < projects.length; i++) {
			count[i] = otService.getCountOfProjectWithDate(projects[i], sd, ed);
			if (count[i] == 0) {
				System.out.println(" Project :" + projects[i] + " is " + count[i] + " so not gonna find it's sum");
				cost[i] = 0;
			}
			if (count[i] > 0) {
				System.out.println("Finding cost now coz approved count is not zero");
				double rs[] = otService.getCostOfProjectWithDate(projects[i], sd, ed);
				double sum = 0;
				for (int x = 0; x < rs.length; x++) {
					sum = sum + rs[x];
				}

				cost[i] = sum;
			}
		}

		System.out.println("Projects >>> ");
		for (int i = 0; i < projects.length; i++) {
			System.out.println(projects[i] + " <<< ");
		}
		System.out.println("counts >>> ");
		for (int i = 0; i < projects.length; i++) {
			System.out.println(count[i] + " <<< ");
		}
		System.out.println("cost >>> ");
		for (int i = 0; i < projects.length; i++) {
			System.out.println(cost[i] + " <<< ");
		}
		model.addAttribute("bean", bean);
		model.addAttribute("count", count);
		model.addAttribute("cost", cost);
		model.addAttribute("projects", projects);

		return "DSH004";
	}

}
