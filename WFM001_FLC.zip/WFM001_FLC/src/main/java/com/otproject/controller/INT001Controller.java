package com.otproject.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.bean.TeamStructureBean;
import com.otproject.dto.TeamStructure;
import com.otproject.service.SalaryExcelService;
import com.otproject.service.TeamExcelService;

@Controller
public class INT001Controller {

	@Autowired
	LGN001Controller loginController;

	@Autowired
	TeamExcelService teamExcelService;

	@Autowired
	SalaryExcelService salaryExcelService;

	@ModelAttribute("projectList")
	public Map<String, String> projectList() {
		Map<String, String> projectList = new HashMap<String, String>();
		projectList = teamExcelService.selectAllProjectId();
		return projectList;
	}

	@ModelAttribute("teamListDropDown")
	public Map<String, String> teamListDropDown() {
		Map<String, String> teamListDropDown = new HashMap<String, String>();
		teamListDropDown = teamExcelService.selectAllTeam();
		return teamListDropDown;
	}

	@ModelAttribute("positionList")
	public Map<String, String> positionList() {
		Map<String, String> positionList = new HashMap<String, String>();
		positionList = salaryExcelService.selectAllPosition();
		return positionList;
	}

	@GetMapping("/insertData")
	public ModelAndView insertData(ModelMap model, HttpSession session, RedirectAttributes reatt) {

		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}
//		for user profile
//		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
//		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());
//
//		model.addAttribute("project", project);
//		model.addAttribute("staff", staffData);

		return new ModelAndView("INT001", "teamBean", new TeamStructureBean());
	}

	@PostMapping("/saveInsert")
	public String saveInsert(@ModelAttribute ("teamBean") @Validated TeamStructureBean teamBean,
			BindingResult result,ModelMap model,RedirectAttributes redirectAtt,HttpSession session) throws IOException {
		
		if(session.getAttribute("sessionUser") ==null) {
					redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return "redirect:/login";
				}
		
		if(result.hasErrors()) {
			model.addAttribute("message", "Need to fill all fields for insert data.");
			return "INT001";
		}
		try {
			TeamStructure checkStaffId = teamExcelService.selectEmpId(teamBean.getStaffId());
			if(checkStaffId.getStaffId()!=null) {
				model.addAttribute("message","Staff Id has been already existing.");
				return "INT001";
			}
		}catch (Exception e) {
			TeamStructure dto = new TeamStructure();
			
			dto.setName(teamBean.getName());
			dto.setPosition(teamBean.getPosition());
			dto.setProject(teamBean.getProject());
			dto.setTeam(teamBean.getTeam());
			dto.setStaffId(teamBean.getStaffId());
			dto.setCheckDelete(0);
			
			teamExcelService.saveEmployeeData(dto);
			redirectAtt.addFlashAttribute("message", "Employee Data Insert Successful.");
		}
		
		return "redirect:/insertData";
}
}
