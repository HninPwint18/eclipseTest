package com.otproject.controller;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.dto.JoinDTO;
import com.otproject.repository.OtFormRepository;
import com.otproject.repository.TeamStructureRepository;
import com.otproject.service.OtFormService;
import com.otproject.service.TeamExcelService;

@Controller
public class HIS004Controller {

	@Autowired
	LGN001Controller loginController;

	@Autowired
	private OtFormRepository otRepo;

	@Autowired
	OtFormService otFormService;

	@Autowired
	TeamExcelService teamExcelService;
	
	TeamStructureRepository teamRepo;

	@GetMapping(value = "/hrhistoryapprovepreview")
	public ModelAndView HRHistoryApprovePreview(@RequestParam("id") String formId, HttpSession session,
			RedirectAttributes reatt, ModelMap model) {

		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}
		
		List<Object> sign = otRepo.forAllSignatureApproved(formId);
		System.out.println(sign.size());
		// List<JoinDTO> alldata1 = new ArrayList<>();

		List<JoinDTO> pm = new ArrayList<>();
		List<JoinDTO> dep = new ArrayList<>();
		List<JoinDTO> div = new ArrayList<>();
		List<JoinDTO> hr = new ArrayList<>();

		for (Object ot : sign) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();

			for (int i = 0; i < x.length; i++) {
				System.out.println(i + "   $$$$$$$$   " + x[i]);
			}

			if (x[3].toString().equals("Project Manager")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				pm.add(joindata);
			} else if (x[3].toString().equals("Dept Head")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				dep.add(joindata);
			} else if (x[3].toString().equals("Division Head")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				div.add(joindata);
			} else {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				hr.add(joindata);
			}

		}

		model.addAttribute("PM", pm);
		model.addAttribute("Dep", dep);
		model.addAttribute("Div", div);
		model.addAttribute("HR", hr);

		List<Object> list = otRepo.HRfindApprovedForHistory(loginController.getStaffId().getStaffId());

		List<JoinDTO> alldata = new ArrayList<>();
		System.out.println(list.size());

		for (Object ot : list) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();

			joindata.setOtId((int) x[0]);
			// joindata.setCreatedTime((String) x[1]);
			joindata.setDay((String) x[2]);
			joindata.setFilename((String) x[3]);
			joindata.setFinishHour((String) x[4]);
			joindata.setFinishHourActual((String) x[5]);
			joindata.setFormId((String) x[6]);
			joindata.setInboxStatus((String) x[7]);
			joindata.setOtDate((Date) x[8]);
			joindata.setOtDateActual((Date) x[9]);
			joindata.setReason((String) x[10]);
			joindata.setSalary((BigDecimal) x[11]);
			joindata.setSentTo((String) x[12]);
			joindata.setStartHour((String) x[13]);
			joindata.setStartHourActual((String) x[14]);
			joindata.setTotalHour((String) x[15]);
			// joindata.setUpdatedTime((String) x[16]);
			joindata.setStructId((Integer) x[17]);
			joindata.setCheckDelete((Integer) x[18]);
			joindata.setName((String) x[21]);
			joindata.setPosition((String) x[22]);
			joindata.setProject((String) x[23]);
			joindata.setSignature((String) x[24]);
			joindata.setStaffId((String) x[25]);
			joindata.setTeam((String) x[26]);
			System.out.println(joindata);
			
			Double basicsalary = teamRepo.findSalaryByStaffId((String) x[22]);
			System.out.println(" Salary &&&&&&&&&&&&&&&&&&&&&" + basicsalary);

			Double totalhour = (double) Integer.parseInt((String) x[15]);
			System.out.println("&&&&&&&&&&&&&&&&&&&&&" + totalhour);

			Double salary = (((basicsalary * 12) / 52 / 48) * 2) * totalhour;

			BigDecimal otsalary = BigDecimal.valueOf(salary);
			System.out.println("&&&&&&&&&&&&&&&&&&&&&" + otsalary);


			alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());

			System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
					+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + ">>>  " + x[10]
					+ ">>>  " + x[11] + "<br>" + x[12] + ">>>  " + x[13] + ">>>  " + x[14] + ">>>  " + x[15] + ">>>  "
					+ x[16] + ">>>  " + x[17] + "<br>" + x[18] + ">>>  " + x[19] + ">>>  " + x[20] + ">>>  " + x[21]
					+ ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24]);
		}
		model.addAttribute("AllData", alldata);
//model.addAttribute("currentPage", page);

		System.out.println(alldata);
		return new ModelAndView("HIS004", "AllDataBean", new JoinDTO());
	}

	@GetMapping(value = "/hrhistoryrejectpreview")
	public ModelAndView HRHistoryRejectPreview(@RequestParam("id") String staffId, ModelMap model) {

		List<Object> list = otRepo.HRfindApprovedForHistory(loginController.getStaffId().getStaffId());

		List<JoinDTO> alldata = new ArrayList<>();
		System.out.println(list.size());

		for (Object ot : list) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();

			joindata.setOtId((int) x[0]);
			// joindata.setCreatedTime((String) x[1]);
			joindata.setDay((String) x[2]);
			joindata.setFilename((String) x[3]);
			joindata.setFinishHour((String) x[4]);
			joindata.setFinishHourActual((String) x[5]);
			joindata.setFormId((String) x[6]);
			joindata.setInboxStatus((String) x[7]);
			joindata.setOtDate((Date) x[8]);
			joindata.setOtDateActual((Date) x[9]);
			joindata.setReason((String) x[10]);
			joindata.setSalary((BigDecimal) x[11]);
			joindata.setSentTo((String) x[12]);
			joindata.setStartHour((String) x[13]);
			joindata.setStartHourActual((String) x[14]);
			joindata.setTotalHour((String) x[15]);
			// joindata.setUpdatedTime((String) x[16]);
			joindata.setStructId((Integer) x[17]);
			joindata.setCheckDelete((Integer) x[18]);
			joindata.setName((String) x[21]);
			joindata.setPosition((String) x[22]);
			joindata.setProject((String) x[23]);
			joindata.setSignature((String) x[24]);
			joindata.setStaffId((String) x[25]);
			joindata.setTeam((String) x[26]);
			System.out.println(joindata);

			alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());

			System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
					+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + ">>>  " + x[10]
					+ ">>>  " + x[11] + "<br>" + x[12] + ">>>  " + x[13] + ">>>  " + x[14] + ">>>  " + x[15] + ">>>  "
					+ x[16] + ">>>  " + x[17] + "<br>" + x[18] + ">>>  " + x[19] + ">>>  " + x[20] + ">>>  " + x[21]
					+ ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24]);
		}
		model.addAttribute("AllData", alldata);
//model.addAttribute("currentPage", page);

		System.out.println(alldata);
		return new ModelAndView("HIS004", "AllDataBean", new JoinDTO());
	}

}
