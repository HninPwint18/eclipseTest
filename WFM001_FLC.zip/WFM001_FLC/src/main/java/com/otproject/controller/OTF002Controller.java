package com.otproject.controller;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.bean.OtFormBean;
import com.otproject.dto.OtFormDTO;
import com.otproject.dto.StatusDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.service.OtFormService;
import com.otproject.service.StatusService;
import com.otproject.service.TeamExcelService;

@Controller
public class OTF002Controller {

	@Autowired
	TeamExcelService teamExcelService;

	@Autowired
	StatusService statusService;
	
	@Autowired
	LGN001Controller loginController;

	@Autowired
	OtFormService otFormService;

//	Project List for project ot
	@ModelAttribute("projectList")
	public List<String> projectList() {
		List<String> plist = teamExcelService.selectAllProject(loginController.getStaffId().getStaffId());
		return plist;
	}

//	team structure type
//	Staff Id list for project ot form
	@ModelAttribute("staffData")
	public List<Map<String, String>> allStaffList() {

		List<Map<String, String>> myList = new ArrayList<Map<String, String>>();
		List<String> plist = teamExcelService.selectAllProject(loginController.getStaffId().getStaffId());
		String loginposition = loginController.getStaffId().getPosition();
		for (String p : plist) {
			for (TeamStructure si : teamExcelService.retrieveAllStaffId(p)) {
				String position = si.getPosition();

				if (loginposition.equals("Project Manager")) {

					if ((!position.equals("Division Head")) && (!position.equals("Dept Head"))) {
						Map<String, String> map = new HashMap<String, String>();
						map.put(si.getProject(), si.getName());
						myList.add(map);
					}
				} else if (loginposition.equals("Dept Head")) {
					if ((!position.equals("Division Head"))) {
						Map<String, String> map = new HashMap<String, String>();
						map.put(si.getProject(), si.getName());
						myList.add(map);
					}
				} else if (loginposition.equals("Division Head")) {
					
						Map<String, String> map = new HashMap<String, String>();
						map.put(si.getProject(), si.getName());
						myList.add(map);
					
				}

			}
		}

		return myList;
	}

	@ModelAttribute("finalNameList")
	public List<TeamStructure> finalNameList() {

		List<TeamStructure> sentToList = teamExcelService
				.selectForSentToProjectId(loginController.getStaffId().getStaffId());
		List<TeamStructure> nameList = new ArrayList<TeamStructure>();
		int count = 0;
		for (TeamStructure sl : sentToList) {
			List<TeamStructure> name = teamExcelService.selectForSentToCheckName(sl.getProject(), sl.getStaffId());
			for (TeamStructure n : name) {
				nameList.add(n);
			}
		}

		if (sentToList.size() > 1) {
			for (int i = 0; i < nameList.size(); i++) {
				count = 0;
				for (int j = 0; j < nameList.size(); j++) {

					if (nameList.get(i).getName().equals(nameList.get(j).getName())) {

						count++;
						if (count > 1) {
							nameList.remove(j);
						}
					}
				}
			}
		}
		return nameList;
	}

	@ModelAttribute("saveFileList")
	public List<OtFormDTO> saveFileList() {
		List<TeamStructure> sentToList = teamExcelService
				.selectForSentToProjectId(loginController.getStaffId().getStaffId());
		List<OtFormDTO> saveFileList = new ArrayList<OtFormDTO>();
		for (TeamStructure sl : sentToList) {
			List<OtFormDTO> saveFile = otFormService.saveFiles(sl.getStructId());
			for (OtFormDTO s : saveFile) {
				saveFileList.add(s);
			}
		}
		return saveFileList;
	}

	@GetMapping("/projectot")
	public ModelAndView ProjectOtFormPage(ModelMap model,HttpSession session, RedirectAttributes reatt) {
	
		if(session.getAttribute("sessionUser") ==null) {
					reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return new ModelAndView("LGN001", "loginBean", new LoginBean());
				}
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);

		return new ModelAndView("OTF002", "otFormBean", new OtFormBean());
	}

	@PostMapping("/projectotupload")
	public String projectotupload(
			HttpSession session, @ModelAttribute("otFormBean") OtFormBean otBean, BindingResult result, ModelMap model, @RequestParam("button") String button,
			RedirectAttributes redirectAtt, @RequestParam("file") MultipartFile multipartFile,@RequestParam("staffName") String[] name, @RequestParam("project") String projectId) throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
					redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return "redirect:/login";
				}
		
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		
		System.out.println(projectId+"*********************");

		if(result.hasErrors()) {
			redirectAtt.addFlashAttribute("message", "Please choose project ID");
			return "LGN002";
		}
		System.out.println(name);
		HashSet<TeamStructure> valuesSet = new HashSet<>();

		for (String n : name) {

			List<TeamStructure> list = teamExcelService.findByStaffName(n, projectId);
			for (TeamStructure ts : list) {

				Collections.addAll(valuesSet, ts);
			}

		}
		otBean.setOtTeam(valuesSet);
		String sentToName = otBean.getSentTo();
//		
		String filename=otBean.getFilename();
//		
//		if(!sentToName.equals("null") && filename.equals("")) {
//			filename="";
//		}else if(sentToName.equals("null") && !filename.equals("")) {
//			sentToName="null";
//		}else {
//			OtFormDTO checkFormId = otFormService.checkFormId();
//			int idForm = checkFormId.getId()+1;
//			filename="File"+idForm;
//		}

		if (!otBean.getStartHour().equals(otBean.getStartHourActual())
				|| !otBean.getFinishHour().equals(otBean.getFinishHourActual())
				|| !otBean.getOtDate().equals(otBean.getOtDateActual())) {
			model.addAttribute("message", "Must be same Plan Hour and Actual Hour");
			List<TeamStructure> signatureList = teamExcelService
					.selectForSentToProjectId(loginController.getStaffId().getStaffId());
			model.addAttribute("signatureList", signatureList);
			return "OTF002";
		}

		OtFormDTO checkFormId = otFormService.checkFormId();
		String formId = "DAT_000001";
		Integer tablePkId;
		try {
			tablePkId = checkFormId.getId();
		} catch (Exception e) {
			tablePkId = 0;
		}
		if (tablePkId >= 99999) {
			formId = "DAT_" + (tablePkId + 1);
		} else if (tablePkId >= 9999) {
			formId = "DAT_0" + (tablePkId + 1);
		} else if (tablePkId >= 999) {
			formId = "DAT_00" + (tablePkId + 1);
		} else if (tablePkId >= 99) {
			formId = "DAT_000" + (tablePkId + 1);
		} else if (tablePkId >= 9) {
			formId = "DAT_0000" + (tablePkId + 1);
		} else {
			formId = "DAT_00000" + (tablePkId + 1);
		}

		System.out.println(name);

		System.out.println("project - " + otBean.getOtTeam());
		System.out.println(otBean.getReason());
		System.out.println(otBean.getOtDate());
		System.out.println(otBean.getStartHour());
		System.out.println(otBean.getFinishHour());
		System.out.println(otBean.getDay());
		System.out.println(otBean.getTotalHour());
//			System.out.println(sentToName);
		System.out.println(filename);
		System.out.println(otBean.getOtDateActual());
		System.out.println(otBean.getStartHourActual());
		System.out.println(otBean.getFinishHourActual());

		LocalDateTime localDateTime = LocalDateTime.now();
		OtFormDTO dto = new OtFormDTO();
		dto.setFormId(formId);
		dto.setOtDate(otBean.getOtDate());
		dto.setStartHour(otBean.getStartHour());
		dto.setFinishHour(otBean.getFinishHour());
		dto.setTotalHour(otBean.getTotalHour());
		dto.setDay(otBean.getDay());
		dto.setReason(otBean.getReason());
//		dto.setInboxStatus("Requested");
		dto.setCreatedTime(localDateTime);
		dto.setUpdatedTime(localDateTime);
//			dto.setOtTeam(valuesSet);
		dto.setOtTeam(otBean.getOtTeam());

		dto.setSentTo(sentToName);
//		dto.setFilename(filename);
		dto.setOtDateActual(otBean.getOtDateActual());
		dto.setStartHourActual(otBean.getStartHourActual());
		dto.setFinishHourActual(otBean.getFinishHourActual());
		
		
		if(button.equals("save")) {
			if(filename.equals("")) {
				int idForm = checkFormId.getId() + 1;
				filename = "File" + idForm;
			}
			
			dto.setFilename(filename);
			dto.setInboxStatus("");
			redirectAtt.addFlashAttribute("message", "OT Form is saved.");
			
		}else if(button.equals("apply")) {
			if(sentToName.equals("none")) {
				int idForm = checkFormId.getId() + 1;
				filename = "File" + idForm;
				dto.setFilename(filename);
				dto.setInboxStatus("");
				redirectAtt.addFlashAttribute("message", "OT Form is saved.");
			}else {
				dto.setFilename("");
				dto.setInboxStatus("Requested");
				redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");

				StatusDTO sdto = new StatusDTO();
				sdto.setStatus("Requested");
				sdto.setUpdateTime(localDateTime);
				
				sdto.setResponse(loginController.getStaffId().getStaffId());
				sdto.setForm_id(formId);
				sdto.setPosition(loginController.getStaffId().getPosition());
				
				statusService.approveApplier(sdto);
			}
			
			
		}

		otFormService.saveOtForm(dto);

//		if (!filename.equals("")) {
//			redirectAtt.addFlashAttribute("message", "OT Form is saved.");
//		} else {
//			redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
//		}

		
		// signature upload updated
				if(!multipartFile.isEmpty()) {
					// signature upload
					String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
					List<TeamStructure> sign = new ArrayList<TeamStructure>();
					sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
					for(TeamStructure s:sign) {
						s.setSignature(signatureName);
						
						TeamStructure saveSignature = teamExcelService.saveSignature(s,s.getStructId());
						
						String uploadDir = "./staff-signature/"+saveSignature.getStructId();
						Path uploadPath = Paths.get(uploadDir);
						
						if(!Files.exists(uploadPath)) {
							Files.createDirectories(uploadPath);
						}
						
						try (InputStream inputStream = multipartFile.getInputStream()) {
				            Path filePath = uploadPath.resolve(signatureName);
				            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
				        } catch (IOException ioe) {        
				            throw new IOException("Could not save signature file: " + signatureName, ioe);
				        } 
					}
					
					   
				}
		
		return "redirect:/projectot";
	}
	
	
	@PostMapping("/saveOtFileSetup")
	public ModelAndView saveFile(@ModelAttribute ("otFormBean") OtFormBean bean,
			HttpSession session,RedirectAttributes reatt,ModelMap model)throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
					reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return new ModelAndView("LGN001", "loginBean", new LoginBean());
				}
			if(bean.getFilename().equals("None")) {
				return new ModelAndView("OTF002","otFormBean",new OtFormBean());
			}
			
			//for user profile
			TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
			List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

			model.addAttribute("project", project);
			model.addAttribute("staff", staffData);
			
			List<TeamStructure> signatureList=teamExcelService.selectForSentToProjectId(loginController.getStaffId().getStaffId());
			model.addAttribute("signatureList", signatureList);
			List<OtFormDTO> file = otFormService.selectFileForOT(bean.getFilename());
			return new ModelAndView("OTF006","otFormBeanDto",file);
	}
	
	@PostMapping("/updateOtSaveFile")
	public String updateSaveFile(HttpSession session, @ModelAttribute("otFormBeanDto") OtFormBean otBean, BindingResult result, ModelMap model,@RequestParam("button") String button,
			RedirectAttributes redirectAtt, @RequestParam("file") MultipartFile multipartFile,@RequestParam("staffName") String[] name, @RequestParam("project") String projectId) throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
					redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return "redirect:/login";
				}
		
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		System.out.println(projectId+"*********************");

		if(result.hasErrors()) {
			redirectAtt.addFlashAttribute("message", "Please choose project ID");
			return "OTF006";
		}
		System.out.println(name);
		HashSet<TeamStructure> valuesSet = new HashSet<>();

		for (String n : name) {

			List<TeamStructure> list = teamExcelService.findByStaffName(n, projectId);
			for (TeamStructure ts : list) {

				Collections.addAll(valuesSet, ts);
			}

		}
		otBean.setOtTeam(valuesSet);
		String sentToName = otBean.getSentTo();
//		
		String filename=otBean.getFilename();
//		
//		if(!sentToName.equals("null") && filename.equals("")) {
//			filename="";
//		}else if(sentToName.equals("null") && !filename.equals("")) {
//			sentToName="null";
//		}else {
//			OtFormDTO checkFormId = otFormService.checkFormId();
//			int idForm = checkFormId.getId()+1;
//			filename="File"+idForm;
//		}

		if (!otBean.getStartHour().equals(otBean.getStartHourActual())
				|| !otBean.getFinishHour().equals(otBean.getFinishHourActual())
				|| !otBean.getOtDate().equals(otBean.getOtDateActual())) {
			model.addAttribute("message", "Must be same Plan Hour and Actual Hour");
			List<TeamStructure> signatureList = teamExcelService
					.selectForSentToProjectId(loginController.getStaffId().getStaffId());
			model.addAttribute("signatureList", signatureList);
			return "OTF006";
		}

		

		System.out.println("project - " + otBean.getOtTeam());
		System.out.println(otBean.getReason());
		System.out.println(otBean.getOtDate());
		System.out.println(otBean.getStartHour());
		System.out.println(otBean.getFinishHour());
		System.out.println(otBean.getDay());
		System.out.println(otBean.getTotalHour());
//			System.out.println(sentToName);
		System.out.println(filename);
		System.out.println(otBean.getOtDateActual());
		System.out.println(otBean.getStartHourActual());
		System.out.println(otBean.getFinishHourActual());

		LocalDateTime localDateTime = LocalDateTime.now();
		OtFormDTO dto = new OtFormDTO();
		dto.setFormId(otBean.getFormId());
		dto.setOtDate(otBean.getOtDate());
		dto.setStartHour(otBean.getStartHour());
		dto.setFinishHour(otBean.getFinishHour());
		dto.setTotalHour(otBean.getTotalHour());
		dto.setDay(otBean.getDay());
		dto.setReason(otBean.getReason());
//		dto.setInboxStatus("Requested");
		dto.setCreatedTime(localDateTime);
		dto.setUpdatedTime(localDateTime);
//			dto.setOtTeam(valuesSet);
		dto.setOtTeam(otBean.getOtTeam());

		dto.setSentTo(sentToName);
//		dto.setFilename(filename);
		dto.setOtDateActual(otBean.getOtDateActual());
		dto.setStartHourActual(otBean.getStartHourActual());
		dto.setFinishHourActual(otBean.getFinishHourActual());
		
		OtFormDTO checkFormId = otFormService.checkFormId();
		if(button.equals("save")) {
			if(filename.equals("")) {
				int idForm = checkFormId.getId() + 1;
				filename = "File" + idForm;
			}
			
			dto.setFilename(filename);
			dto.setInboxStatus("");
			redirectAtt.addFlashAttribute("message", "OT Form is saved.");
			
		}else if(button.equals("apply")) {
			if(sentToName.equals("none")) {
				int idForm = checkFormId.getId() + 1;
				filename = "File" + idForm;
				dto.setFilename(filename);
				dto.setInboxStatus("");
				redirectAtt.addFlashAttribute("message", "OT Form is saved.");
			}else {
				dto.setFilename("");
				dto.setInboxStatus("Requested");
				redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
			}
			
			
		}

		otFormService.saveOtForm(dto);

//		if (!filename.equals("")) {
//			redirectAtt.addFlashAttribute("message", "OT Form is saved.");
//		} else {
//			redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
//		}

		// signature upload updated
				if(!multipartFile.isEmpty()) {
					// signature upload
					String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
					List<TeamStructure> sign = new ArrayList<TeamStructure>();
					sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
					for(TeamStructure s:sign) {
						s.setSignature(signatureName);
						
						TeamStructure saveSignature = teamExcelService.saveSignature(s,s.getStructId());
						
						String uploadDir = "./staff-signature/"+saveSignature.getStructId();
						Path uploadPath = Paths.get(uploadDir);
						
						if(!Files.exists(uploadPath)) {
							Files.createDirectories(uploadPath);
						}
						
						try (InputStream inputStream = multipartFile.getInputStream()) {
				            Path filePath = uploadPath.resolve(signatureName);
				            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
				        } catch (IOException ioe) {        
				            throw new IOException("Could not save signature file: " + signatureName, ioe);
				        } 
					}
					
					   
				}
		
		return "redirect:/projectot";
	}
	
	@GetMapping("/revisedOtFileSetup")
	public ModelAndView reviseFile(@ModelAttribute ("otFormBean") OtFormBean bean,
			HttpSession session,RedirectAttributes reatt,ModelMap model,@RequestParam("project") String project)throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
					reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return new ModelAndView("LGN001", "loginBean", new LoginBean());
				}
			if(bean.getFilename().equals("None")) {
				return new ModelAndView("OTF002","otFormBean",new OtFormBean());
			}
			
			//for user profile
			TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
			List<String> projectlist = teamExcelService.selectAllProject(staffData.getStaffId());

			model.addAttribute("project", projectlist);
			model.addAttribute("staff", staffData);
			
			OtFormDTO revisedForm = otFormService.revisedForm(project);
			
			List<TeamStructure> signatureList=teamExcelService.selectForSentToProjectId(loginController.getStaffId().getStaffId());
			model.addAttribute("signatureList", signatureList);
			
			return new ModelAndView("OTF008","otFormBean",revisedForm);
	}
	
	@PostMapping("/updateOtReviseFile")
	public String updateReviseFile(HttpSession session, @ModelAttribute("otFormBean") OtFormBean otBean, BindingResult result, ModelMap model, @RequestParam("button") String button,
			RedirectAttributes redirectAtt, @RequestParam("file") MultipartFile multipartFile,@RequestParam("staffName") String[] name, @RequestParam("project") String projectId) throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
					redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return "redirect:/login";
				}
		
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		System.out.println(projectId+"*********************");

		if(result.hasErrors()) {
			redirectAtt.addFlashAttribute("message", "Please choose project ID");
			return "OTF006";
		}
		System.out.println(name);
		HashSet<TeamStructure> valuesSet = new HashSet<>();

		for (String n : name) {

			List<TeamStructure> list = teamExcelService.findByStaffName(n, projectId);
			for (TeamStructure ts : list) {

				Collections.addAll(valuesSet, ts);
			}

		}
		otBean.setOtTeam(valuesSet);
		String sentToName = otBean.getSentTo();
//		
		String filename=otBean.getFilename();
//		
//		if(!sentToName.equals("null") && filename.equals("")) {
//			filename="";
//		}else if(sentToName.equals("null") && !filename.equals("")) {
//			sentToName="null";
//		}else {
//			OtFormDTO checkFormId = otFormService.checkFormId();
//			int idForm = checkFormId.getId()+1;
//			filename="File"+idForm;
//		}

		if (!otBean.getStartHour().equals(otBean.getStartHourActual())
				|| !otBean.getFinishHour().equals(otBean.getFinishHourActual())
				|| !otBean.getOtDate().equals(otBean.getOtDateActual())) {
			model.addAttribute("message", "Must be same Plan Hour and Actual Hour");
			List<TeamStructure> signatureList = teamExcelService
					.selectForSentToProjectId(loginController.getStaffId().getStaffId());
			model.addAttribute("signatureList", signatureList);
			return "OTF008";
		}

		

		System.out.println("project - " + otBean.getOtTeam());
		System.out.println(otBean.getReason());
		System.out.println(otBean.getOtDate());
		System.out.println(otBean.getStartHour());
		System.out.println(otBean.getFinishHour());
		System.out.println(otBean.getDay());
		System.out.println(otBean.getTotalHour());
//			System.out.println(sentToName);
		System.out.println(filename);
		System.out.println(otBean.getOtDateActual());
		System.out.println(otBean.getStartHourActual());
		System.out.println(otBean.getFinishHourActual());

		LocalDateTime localDateTime = LocalDateTime.now();
		OtFormDTO dto = new OtFormDTO();
		dto.setFormId(otBean.getFormId());
		dto.setOtDate(otBean.getOtDate());
		dto.setStartHour(otBean.getStartHour());
		dto.setFinishHour(otBean.getFinishHour());
		dto.setTotalHour(otBean.getTotalHour());
		dto.setDay(otBean.getDay());
		dto.setReason(otBean.getReason());
//		dto.setInboxStatus("Requested");
		dto.setCreatedTime(localDateTime);
		dto.setUpdatedTime(localDateTime);
//			dto.setOtTeam(valuesSet);
		dto.setOtTeam(otBean.getOtTeam());

		dto.setSentTo(sentToName);
//		dto.setFilename(filename);
		dto.setOtDateActual(otBean.getOtDateActual());
		dto.setStartHourActual(otBean.getStartHourActual());
		dto.setFinishHourActual(otBean.getFinishHourActual());
		
		OtFormDTO checkFormId = otFormService.checkFormId();
		if(button.equals("save")) {
			if(filename.equals("")) {
				int idForm = checkFormId.getId() + 1;
				filename = "File" + idForm;
			}
			
			dto.setFilename(filename);
			dto.setInboxStatus("");
			redirectAtt.addFlashAttribute("message", "OT Form is saved.");
			
		}else if(button.equals("apply")) {
			if(sentToName.equals("none")) {
				int idForm = checkFormId.getId() + 1;
				filename = "File" + idForm;
				dto.setFilename(filename);
				dto.setInboxStatus("");
				redirectAtt.addFlashAttribute("message", "OT Form is saved.");
			}else {
				dto.setFilename("");
				dto.setInboxStatus("Requested");
				redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
			}
			
			
		}

		otFormService.saveOtForm(dto);

//		if (!filename.equals("")) {
//			redirectAtt.addFlashAttribute("message", "OT Form is saved.");
//		} else {
//			redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
//		}

		// signature upload updated
				if(!multipartFile.isEmpty()) {
					// signature upload
					String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
					List<TeamStructure> sign = new ArrayList<TeamStructure>();
					sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
					for(TeamStructure s:sign) {
						s.setSignature(signatureName);
						
						TeamStructure saveSignature = teamExcelService.saveSignature(s,s.getStructId());
						
						String uploadDir = "./staff-signature/"+saveSignature.getStructId();
						Path uploadPath = Paths.get(uploadDir);
						
						if(!Files.exists(uploadPath)) {
							Files.createDirectories(uploadPath);
						}
						
						try (InputStream inputStream = multipartFile.getInputStream()) {
				            Path filePath = uploadPath.resolve(signatureName);
				            Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
				        } catch (IOException ioe) {        
				            throw new IOException("Could not save signature file: " + signatureName, ioe);
				        } 
					}
					
					   
				}
		
		return "redirect:/projectot";
	}

}
