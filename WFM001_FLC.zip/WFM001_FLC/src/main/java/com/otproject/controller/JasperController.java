package com.otproject.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.otproject.dto.JasperDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.OtFormRepository;
import com.otproject.service.OtFormService;
import com.otproject.service.ReportService;
import com.otproject.service.TeamExcelService;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRPdfExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

@Controller
public class JasperController {

	@Autowired
	private OtFormRepository otFormRepo;
	
	@Autowired
	TeamExcelService teamService;
	
	@Autowired
	OtFormService otService;
	
	@Autowired
	ReportService reportService;
	
	@GetMapping("/jasperDownload")
	public String jasperDownload() {
		return "IBX002";
	}
	
	@GetMapping("/toPreview")
	public String jasperDataTransfer() {
		List<Object> jasper = otFormRepo.findDataForJasper("DAT_000001");
		System.out.println("jasper list size " +jasper.size());
		
		for(Object jdata:jasper) {
//			JasperDTO dto = new JasperDTO();
			Object[] name=(Object[]) jdata;
			System.out.println("Object Length " +name.length);
			System.out.println(name[0]+"      "+ name[1] +"       "+name[2]+"      "+name[3]+"       "+name[4]+"      "+name[5]+"       "+name[6]+"      "+name[7]+"       "+name[8]+"      "+name[9]
					+"       "+name[10]+"      "+name[11]+"       "+name[12]+"      "+name[13]+"       "+name[14]+"       "+name[15]+"      "+name[16]+"       "+name[17]+"      "+name[18]+"        "+name[19]+"      "+name[20]);
		
		}
		
		return "OTF001";
	}
	
	@GetMapping("/topreview/otFormpdf")
	public ResponseEntity<byte[]> generateOtFormPdf(@RequestParam("id") String id) throws FileNotFoundException, JRException {
		return reportService.generateOtFormPdf(id);
	}
	
	 @GetMapping("/jasper")
		public String jasper(HttpServletResponse response, HttpServletRequest request) throws IOException {
			
			// jasper
		 	List<Object> jasper = otFormRepo.findDataForJasper("DAT_000001"); 
		 	
		 	// Parameters for report
		 	// Adding the additional parameters to the pdf.
		 	Map parameters = new HashMap();
			parameters.put("ReportTitle", "TeamStructure List");
			parameters.put("formId", "DAT_000001");
		 	
		 	List<JasperDTO> jasperDtoList = new ArrayList<JasperDTO>();
		 	
		 	for(Object jdata:jasper) {
				JasperDTO dto = new JasperDTO();
				Object[] name=(Object[]) jdata;
				dto.setDay((String) name[0]);
				dto.setFinishHour((String) name[1]);
				dto.setFinishHourActual((String) name[2]);
				dto.setFormId((String) name[3]);
				dto.setOtDate((Date) name[4]);
				dto.setOtDateActual((Date) name[5]);
				dto.setReason((String) name[6]);
				dto.setSalary((BigDecimal) name[20]);
				dto.setStartHour((String) name[8]);
				dto.setStartHourActual((String) name[9]);
				dto.setTotalHour((String) name[10]);
				dto.setName((String) name[11]);
				dto.setPosition((String) name[12]);
				dto.setProject((String) name[13]);
				dto.setSignature((String) name[14]);
				dto.setStaffId((String) name[15]);
				dto.setApprovedBy((String) name[17]);
				
				String jrName = (String) name[11];
				if(jrName==null) jrName="...............";
				parameters.put("name", jrName);
				String jrDate = (String) name[5];
				if(jrDate==null) jrDate="...............";
				parameters.put("date", jrDate);
				String jrSignature = (String) name[14];
//				if(jrSignature==null) jrSignature="...............";
				parameters.put("signature", "staff-signature/"+name[19].toString()+"/"+jrSignature);
				parameters.put("status", "Requested");
				
				System.out.println("project Id"+(String)name[13]);
				TeamStructure team =teamService.jasperParameter((String)name[13], (String)name[17]);
				
				String jname = team.getName();
//				String jname= "Kyaw";
				if(jname==null) jname="...............";
				parameters.put(team.getPosition()+" name", jname);
				String jsignature = team.getSignature();
//				if(jsignature==null) jsignature="...............";
				parameters.put(team.getPosition()+" signature","staff-signature/"+team.getStructId().toString()+"/"+ jsignature);
				
				String jdate = name[18].toString();
				if(jdate==null) jdate="...............";
				parameters.put(team.getPosition()+" date", jdate);
				String jstatus = (String) name[16];
				if(jstatus==null) jstatus="...............";
				parameters.put(team.getPosition()+" status",jstatus);
				
				TeamStructure hr = teamService.jasperParameterHR((String)name[17]);
				
				if(hr!=null) {
					String hrdate = name[18].toString();
					if(hrdate==null) hrdate="...............";
					parameters.put(hr.getTeam()+" date", hrdate);
					System.out.println("hr team"+hr.getTeam());
					System.out.println("hr date"+hrdate);
					String hrstatus = (String) name[16];
					if(hrstatus==null) hrstatus="...............";
					parameters.put(hr.getTeam()+" status",hrstatus);
					
					System.out.println("hr status"+hrstatus);
				}else {
					parameters.put("HR date", "...............");
		        	parameters.put("HR status", "...............");
				}
				
				
				parameters.put("projectId",name[13]);
				
				jasperDtoList.add(dto);
			}
			
			//ServletContext context = request.getServletContext();
			//String path = context.getRealPath("\\src\\main\\resources\\static\\jasper\\Second_Jasper.jrxml");
			
			// Fetching the .jrxml file from the resources folder.
			
			InputStream path = this.getClass().getResourceAsStream("/static/jasper/Test2.jrxml");
			JRBeanCollectionDataSource source = null;
			JasperReport jasperReport;
			JasperPrint print;
			
			Iterator<Map.Entry<String, String>> itr = parameters.entrySet().iterator();
	        int pm =0;
	        int dept=0;
	        int div=0;
	        int hrcount=0;
	        while(itr.hasNext())
	        {
	             Map.Entry<String, String> entry = itr.next();
	             System.out.println("Key = " + entry.getKey() + 
	                                 ", Value = " + entry.getValue());
	             if(entry.getKey().equals("Project Manager name")) {
	            	 pm++;
	             }else if(entry.getKey().equals("Division Head name")) {
	            	 div++;
	             }else if(entry.getKey().equals("Dept Head name")) {
	            	 dept++;
	             }else if(entry.getKey().equals("HR date")) {
	            	 hrcount++;
	             }
	        }
	        
	        
	        if(pm==0) {
				parameters.put("Project Manager name", "...............");
//				parameters.put("Project Manager signature", "...............");
				parameters.put("Project Manager date", "...............");
				parameters.put("Project Manager status","...............");
	        }else if(dept==0) {
	        	parameters.put("Dept Head name", "...............");
//				parameters.put("Dept Head signature", "...............");
				parameters.put("Dept Head date", "...............");
				parameters.put("Dept Head status","...............");
	        }else if(div==0) {
	        	parameters.put("Division Head name", "...............");
//				parameters.put("Division Head signature", "...............");
				parameters.put("Division Head date", "...............");
				parameters.put("Division Head status","...............");
	        }
//	       
//			
			try {
			//Fetching the employees from the data source.
			source = new JRBeanCollectionDataSource(jasperDtoList);
			
			// Compile the Jasper report from .jrxml to .japser
			
			jasperReport = JasperCompileManager.compileReport(path);
			
			// Filling the report with the employee data and additional parameters information.
			print = JasperFillManager.fillReport(jasperReport, parameters, source);
			
		
			response.setContentType("application/pdf");
			 // Export the report to a PDF file.
			response.setHeader("Content-Disposition", "attachment; filename=OtFormReport.pdf");
			JRPdfExporter exporterPdf = new JRPdfExporter(); 
			exporterPdf.setParameter(JRPdfExporterParameter.JASPER_PRINT, print); 
			exporterPdf.setParameter(JRPdfExporterParameter.OUTPUT_STREAM, response.getOutputStream());
			exporterPdf.exportReport();
			
			} catch (JRException e) {
			e.printStackTrace();
			}
		
			
			return "redirect:/jasperDownload";
		}
		
		@GetMapping("/jasperexcel")
		public String jasperExcel(HttpServletRequest request,HttpServletResponse response) throws IOException{
			
			// jasper
				List<Object> jasper = otFormRepo.findDataForJasper("DAT_000001");
				
			 	// Parameters fS\or report
			 	// Adding the additional parameters to the pdf.
			 	Map parameters = new HashMap();
				parameters.put("ReportTitle", "TeamStructure List");
				parameters.put("formId", "DAT_000001");
			 	
			 	List<JasperDTO> jasperDtoList = new ArrayList<JasperDTO>();
			 	
			 	for(Object jdata:jasper) {
					JasperDTO dto = new JasperDTO();
					Object[] name=(Object[]) jdata;
					dto.setDay((String) name[0]);
					dto.setFinishHour((String) name[1]);
					dto.setFinishHourActual((String) name[2]);
					dto.setFormId((String) name[3]);
					dto.setOtDate((Date) name[4]);
					dto.setOtDateActual((Date) name[5]);
					dto.setReason((String) name[6]);
					dto.setSalary((BigDecimal) name[7]);
					dto.setStartHour((String) name[8]);
					dto.setStartHourActual((String) name[9]);
					dto.setTotalHour((String) name[10]);
					dto.setName((String) name[11]);
					dto.setPosition((String) name[12]);
					dto.setProject((String) name[13]);
					dto.setSignature((String) name[14]);
					dto.setStaffId((String) name[15]);
					dto.setApprovedBy((String) name[17]);
					
					String jrName = (String) name[11];
					if(jrName==null) jrName="...............";
					parameters.put("name", jrName);
					String jrDate = (String) name[5];
					if(jrDate==null) jrDate="...............";
					parameters.put("date", jrDate);
					String jrSignature = (String) name[14];
//					if(jrSignature==null) jrSignature="...............";
					parameters.put("signature", "staff-signature/"+name[19].toString()+"/"+jrSignature);
					parameters.put("status", "Requested");
					
					TeamStructure team =teamService.jasperParameter((String)name[13], (String)name[17]);
					
					String jname = team.getName();
					if(jname==null) jname="...............";
					parameters.put(team.getPosition()+" name", jname);
					String jsignature = team.getSignature();
//					if(jsignature==null) jsignature="...............";
					parameters.put(team.getPosition()+" signature","staff-signature/"+team.getStructId()+"/"+ jsignature);
					String jdate = name[18].toString();
					if(jdate==null) jdate="...............";
					parameters.put(team.getPosition()+" date", jdate);
					String jstatus = (String) name[16];
					if(jstatus==null) jstatus="...............";
					parameters.put(team.getPosition()+" status",jstatus);
					parameters.put("projectId",name[13]);
					
					TeamStructure hr = teamService.jasperParameterHR((String)name[17]);
					if(hr!=null) {
						String hrdate = name[18].toString();
						if(hrdate==null) hrdate="...............";
						parameters.put(hr.getTeam()+" date", hrdate);
						String hrstatus = (String) name[16];
						if(hrstatus==null) hrstatus="...............";
						parameters.put(hr.getTeam()+" status",hrstatus);
					}else {
						parameters.put("HR date", "...............");
			        	parameters.put("HR status", "...............");
					}
					
					jasperDtoList.add(dto);
				}
				
				//ServletContext context = request.getServletContext();
				//String path = context.getRealPath("\\src\\main\\resources\\static\\jasper\\Second_Jasper.jrxml");
				InputStream path = this.getClass().getResourceAsStream("/static/jasper/Test2.jrxml");
				JRBeanCollectionDataSource source = null;
				JasperReport jasperReport;
				JasperPrint print;
				
				Iterator<Map.Entry<String, String>> itr = parameters.entrySet().iterator();
		        int pm =0;
		        int dept=0;
		        int div=0;
		        int hr=0;
		        while(itr.hasNext())
		        {
		             Map.Entry<String, String> entry = itr.next();
		             System.out.println("Key = " + entry.getKey() + 
		                                 ", Value = " + entry.getValue());
		             if(entry.getKey().equals("Project Manager name")) {
		            	 pm++;
		             }else if(entry.getKey().equals("Division Head name")) {
		            	 div++;
		             }else if(entry.getKey().equals("Dept Head name")) {
		            	 dept++;
		             }else if(entry.getKey().equals("HR date")) {
		            	 hr++;
		             }
		        }
		          
		        
		        if(pm==0) {
					parameters.put("Project Manager name", "...............");
//					parameters.put("Project Manager signature", "...............");
					parameters.put("Project Manager date", "...............");
					parameters.put("Project Manager status","...............");
		        }else if(dept==0) {
		        	parameters.put("Dept Head name", "...............");
//					parameters.put("Dept Head signature", "...............");
					parameters.put("Dept Head date", "...............");
					parameters.put("Dept Head status","...............");
		        }else if(div==0) {
		        	parameters.put("Division Head name", "...............");
//					parameters.put("Division Head signature", "...............");
					parameters.put("Division Head date", "...............");
					parameters.put("Division Head status","...............");
		        }
				
				// Parameters for report
			
				try {
				source = new JRBeanCollectionDataSource(jasperDtoList);
				jasperReport = JasperCompileManager.compileReport(path);
				print = JasperFillManager.fillReport(jasperReport, parameters, source);
				
					
				JRXlsxExporter exporter = new JRXlsxExporter();
		        SimpleXlsxReportConfiguration reportConfigXLS = new SimpleXlsxReportConfiguration();
		        reportConfigXLS.setSheetNames(new String[] { "sheet1" });
		        exporter.setConfiguration(reportConfigXLS);
		        exporter.setExporterInput(new SimpleExporterInput(print));
		        exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(response.getOutputStream()));
		        response.setHeader("Content-Disposition", "attachment;filename=OtFormReport.xlsx");
		        response.setContentType("application/octet-stream");
		        exporter.exportReport();
				
				} catch (JRException e) {
					e.printStackTrace();
				}
				
				return "redirect:/jasperDownload";
		}
}
