package com.otproject.controller;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.dto.JoinDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.OtFormRepository;
import com.otproject.service.TeamExcelService;

@Controller
public class OTL001Controller {
	@Autowired
	LGN001Controller login;

	@Autowired
	private OtFormRepository otRepo;


	@Autowired
	TeamExcelService teamExcelService;

	@GetMapping("/myOtList")
	public ModelAndView MyOtList(ModelMap model, HttpSession session, RedirectAttributes reatt,
			@RequestParam(defaultValue = "0") int page) {
		// System.out.println(login.getStaffId().getStaffId());
		// Pageable pageable = PageRequest.of(page, 10);

		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}

//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(login.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);

		List<JoinDTO> alldata = new ArrayList<>();
		List<Object> list = otRepo.findAllDataApplier(login.getStaffId().getStaffId());
		System.out.println(">>>>>>>>>" + list.size() + ">>>>>>>>>");

		if (list.isEmpty()) {
			model.addAttribute("message", "No have any message in My OT list..");
		} else {

			for (Object ot : list) {
				Object[] x = (Object[]) ot;
				JoinDTO joindata = new JoinDTO();

				joindata.setOtId((int) x[0]);
				// joindata.setCreatedTime((String) x[1]);
				joindata.setDay((String) x[2]);
				joindata.setFilename((String) x[3]);
				joindata.setFinishHour((String) x[4]);
				joindata.setFinishHourActual((String) x[5]);
				joindata.setFormId((String) x[6]);
				joindata.setInboxStatus((String) x[7]);
				joindata.setOtDate((Date) x[8]);
				joindata.setOtDateActual((Date) x[9]);
				joindata.setReason((String) x[10]);
				joindata.setSalary((BigDecimal) x[11]);
				joindata.setSentTo((String) x[12]);
				joindata.setStartHour((String) x[13]);
				joindata.setStartHourActual((String) x[14]);
				joindata.setTotalHour((String) x[15]);
				// joindata.setUpdatedTime((String) x[16]);
				joindata.setStructId((Integer) x[17]);
				joindata.setCheckDelete((Integer) x[18]);
				joindata.setName((String) x[21]);
				joindata.setPosition((String) x[22]);
				joindata.setProject((String) x[23]);
				joindata.setSignature((String) x[24]);
				joindata.setStaffId((String) x[25]);
				joindata.setTeam((String) x[26]);
				System.out.println(joindata);

				System.out.println((String) x[6] + "^^^^^^^^^^^^^^");

				List<JoinDTO> alldata1 = new ArrayList<>();
				List<Object> statusfetch = otRepo.forAllApproved1((String) x[6]);
				model.addAttribute("AllData1", statusfetch);

				for (Object ot1 : statusfetch) {
					Object[] x1 = (Object[]) ot1;
					JoinDTO joindata1 = new JoinDTO();

					for (int i = 0; i < x1.length; i++) {
						System.out.println("$$$  " + i + " $$$    " + x1[i]);
					}

					joindata1.setPosition(x1[0].toString());
					joindata1.setStatus(x1[1].toString());
					joindata1.setUpdatedTime(x1[2].toString());

					alldata1.add(joindata1);

					System.out.println("Hello-----------------" + alldata1);

				}

				model.addAttribute("AllData1", alldata1);

//				

				alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());
			}

			model.addAttribute("AllData", alldata);
			model.addAttribute("currentPage", page);

		}

		return new ModelAndView("OTL001", "AllDataBean", new JoinDTO());

	}

//	@GetMapping("/myotdetails")
//	public ModelAndView MyOTDetails(@RequestParam("id") String formId, ModelMap model) {
//		List<StatusDTO> listall = statusRepo.fetchDetailsMyOTForm(formId);
//		model.addAttribute("AllData", listall);
//
//		return new ModelAndView("OTL001", "AllDataBean", new JoinDTO());
//
//	}

	@GetMapping("/myotlist")
	public ModelAndView MemberMyOtList(ModelMap model, HttpSession session, RedirectAttributes reatt,
			@RequestParam(defaultValue = "0") int page) {
		// System.out.println(login.getStaffId().getStaffId());
		// Pageable pageable = PageRequest.of(page, 10);

		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}

//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(login.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);

		List<JoinDTO> alldata = new ArrayList<>();
		List<Object> list = otRepo.findAllDataApplier(login.getStaffId().getStaffId());
		System.out.println(">>>>>>>>>" + list.size() + ">>>>>>>>>");

		if (list.isEmpty()) {
			model.addAttribute("message", "No have any message in My OT list.");
		} else {

			for (Object ot : list) {
				Object[] x = (Object[]) ot;
				JoinDTO joindata = new JoinDTO();

				joindata.setOtId((int) x[0]);
				// joindata.setCreatedTime((String) x[1]);
				joindata.setDay((String) x[2]);
				joindata.setFilename((String) x[3]);
				joindata.setFinishHour((String) x[4]);
				joindata.setFinishHourActual((String) x[5]);
				joindata.setFormId((String) x[6]);
				joindata.setInboxStatus((String) x[7]);
				joindata.setOtDate((Date) x[8]);
				joindata.setOtDateActual((Date) x[9]);
				joindata.setReason((String) x[10]);
				joindata.setSalary((BigDecimal) x[11]);
				joindata.setSentTo((String) x[12]);
				joindata.setStartHour((String) x[13]);
				joindata.setStartHourActual((String) x[14]);
				joindata.setTotalHour((String) x[15]);
				// joindata.setUpdatedTime((String) x[16]);
				joindata.setStructId((Integer) x[17]);
				joindata.setCheckDelete((Integer) x[18]);
				joindata.setName((String) x[21]);
				joindata.setPosition((String) x[22]);
				joindata.setProject((String) x[23]);
				joindata.setSignature((String) x[24]);
				joindata.setStaffId((String) x[25]);
				joindata.setTeam((String) x[26]);
				System.out.println(joindata);

				System.out.println((String) x[6] + "^^^^^^^^^^^^^^");

				List<JoinDTO> alldata1 = new ArrayList<>();
				List<Object> statusfetch = otRepo.forAllApproved1((String) x[6]);
				model.addAttribute("AllData1", statusfetch);

				for (Object ot1 : statusfetch) {
					Object[] x1 = (Object[]) ot1;
					JoinDTO joindata1 = new JoinDTO();

					for (int i = 0; i < x1.length; i++) {
						System.out.println("$$$  " + i + " $$$    " + x1[i]);
					}

					joindata1.setPosition(x1[0].toString());
					joindata1.setStatus(x1[1].toString());
					joindata1.setUpdatedTime(x1[2].toString());

					alldata1.add(joindata1);

					System.out.println("Hello-----------------" + alldata1);

				}

				model.addAttribute("AllData1", alldata1);

				alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());

				System.out.println(x[0] + "<br/>" + x[1] + ":<br>" + x[2] + ":<br>" + x[3] + ":<br>" + x[4] + ":<br>"
						+ x[5] + "<br>" + x[6] + ":<br>" + x[7] + ":<br>" + x[8] + ":<br>" + x[9] + ":<br>" + x[10]
						+ ":<br>" + x[11] + "<br>" + x[12] + ":<br>" + x[13] + ":<br>" + x[14] + ":<br>" + x[15]
						+ ":<br>" + x[16] + ":<br>" + x[17] + "<br>" + x[18] + ":<br>" + x[19] + ":<br>" + x[20]
						+ ":<br>" + x[21] + ":<br>" + x[22] + ":<br>" + x[23] + "<br>" + x[24]);
			}

			model.addAttribute("AllData", alldata);
			model.addAttribute("currentPage", page);

		}
		return new ModelAndView("OTL004", "AllDataBean", new JoinDTO());

	}

}
