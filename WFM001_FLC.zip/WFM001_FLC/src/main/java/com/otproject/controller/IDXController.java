package com.otproject.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.otproject.dto.TeamStructure;
import com.otproject.service.TeamExcelService;

@Controller
public class IDXController {
	
	@Autowired
	LGN001Controller loginController;

	@Autowired
	TeamExcelService teamExcelService;

	@GetMapping(value = "/")
	public ModelAndView indexPage() {
		return new ModelAndView("IDX001");
	}

	@GetMapping(value = "/home")
	public String homePage(HttpSession session) {
		return "IDX002";
	}

	@GetMapping(value = "/redirectBack")
	public String pageReturn(HttpSession session) {

		System.out.println(loginController.getStaffId().getStaffId()+"<<<<<<<<<<<<<<<<<<<<<<<<<<");
		if (loginController.getStaffId().getStaffId().equals("11-00000")) {
			return "redirect:/adminDashboard";
		} else {
			TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");
			
			if(team.getTeam().equals("HR")) {
				return "redirect:/hrinbox";
			}
			else {
				
//				return "redirect:/signature";
				if(team.getPosition().equals("Division Head")) {
					return "redirect:/inbox";
				}
				else if(team.getPosition().equals("Dept Head")) {
					return "redirect:/inbox";
				}
				else if(team.getPosition().equals("Project Manager")) {
					return "redirect:/inbox";
				}
				else {
					return "redirect:/myotform";
				}
			}
		}

	}
	
	@GetMapping(value = "/profile")
	public String userprofile(HttpSession session, ModelMap model) {
//		TeamStructureBean teamBean = new TeamStructureBean();
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());
//		teamBean.setStaffId(team.getStaffId());
//		teamBean.setName(team.getName());
//		teamBean.setPosition(team.getPosition());
//		teamBean.setTeam(team.getTeam());
		
		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		
		return "USR001";
	}

}
