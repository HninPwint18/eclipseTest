package com.otproject.controller;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.dto.JoinDTO;
import com.otproject.dto.OTFees;
import com.otproject.dto.OtFormDTO;
import com.otproject.dto.StatusDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.OtFormRepository;
import com.otproject.repository.StatusRepository;
import com.otproject.repository.TeamStructureRepository;
import com.otproject.service.OTFeesService;
import com.otproject.service.OtFormService;
import com.otproject.service.SalaryExcelService;
import com.otproject.service.StatusService;
import com.otproject.service.TeamExcelService;

@Controller
public class IBX006Controller {

	@Autowired
	LGN001Controller loginController;

	@Autowired
	private OtFormRepository otRepo;

	@Autowired
	private TeamStructureRepository teamRepo;

	@Autowired
	private StatusRepository statusRepo;

	@Autowired
	OtFormService otFormService;

	@Autowired
	StatusService statusService;

	@Autowired
	TeamExcelService teamExcelService;

	@Autowired
	OTFeesService feesService;
	
	@Autowired
	SalaryExcelService salaryExcelService;
	
	@ModelAttribute("finalNameList")
	public List<TeamStructure> finalNameList() {

		List<TeamStructure> sentToList = teamExcelService
				.selectForSentToProjectId(loginController.getStaffId().getStaffId());
		List<TeamStructure> nameList = new ArrayList<TeamStructure>();
		int count = 0;
		for (TeamStructure sl : sentToList) {
			List<TeamStructure> name = teamExcelService.selectForSentToCheckName(sl.getProject(), sl.getStaffId());
			for (TeamStructure n : name) {
				nameList.add(n);
			}
		}
		if (sentToList.size() > 1) {
			for (int i = 0; i < nameList.size(); i++) {
				count = 0;
				for (int j = 0; j < nameList.size(); j++) {

					if (nameList.get(i).getName().equals(nameList.get(j).getName())) {

						count++;
						if (count > 1) {
							nameList.remove(j);
						}
					}
				}
			}
		}
		return nameList;
	}

	@GetMapping(value = "/hrtoresponse")
	public ModelAndView HRToResponse(@RequestParam("id") String formId, ModelMap model, HttpSession session, RedirectAttributes reatt) {
	

		if(session.getAttribute("sessionUser") ==null) {
					reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return new ModelAndView("LGN001", "loginBean", new LoginBean());
				}
		
		
		TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");
		
		List<Object> data = otRepo.forInboxResponse(formId);
		List<JoinDTO> pjall = new ArrayList<JoinDTO>();

		for (Object ot : data) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();
			
			joindata.setProject((String) x[0]);
			joindata.setFormId((String) x[1]);
			joindata.setOtDate((Date) x[2]);
			joindata.setStartHour((String) x[3]);
			joindata.setFinishHour((String) x[4]);
			joindata.setOtDateActual((Date) x[5]);
			joindata.setStartHourActual((String) x[6]);
			joindata.setFinishHourActual((String) x[7]);
			joindata.setReason((String) x[8]);
			joindata.setTotalHour((String) x[9]);
			
			pjall.add(joindata);
			
			
			for (int i = 0; i < x.length; i++) {
				System.out.println(i + "**********" + x[i]);
			}
		}
		model.addAttribute("All",pjall);
		
		List<String> name = teamRepo.forInboxResponseName(formId);
		model.addAttribute("Name",name);
		

		List<TeamStructure> signatureList = teamExcelService.selectForSentToProjectId(team.getStaffId());
		model.addAttribute("signatureList", signatureList);

		List<StatusDTO> approver = statusRepo.fetchApprover(formId);
		System.out.println("$$$$$$$$$$        " + approver.toString());
		model.addAttribute("Approver", approver);

		List<JoinDTO> alldata = new ArrayList<>();

		List<Object> list = otRepo.findAllData(formId);

		System.out.println(list.size());

		for (Object ot : list) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();

			joindata.setOtId((int) x[0]);
			// joindata.setCreatedTime((String) x[1]);
			joindata.setDay((String) x[2]);
			joindata.setFilename((String) x[3]);
			joindata.setFinishHour((String) x[4]);
			joindata.setFinishHourActual((String) x[5]);
			joindata.setFormId((String) x[6]);
			joindata.setInboxStatus((String) x[7]);
			joindata.setOtDate((Date) x[8]);
			joindata.setOtDateActual((Date) x[9]);
			joindata.setReason((String) x[10]);
			joindata.setSalary((BigDecimal) x[11]);
			joindata.setSentTo((String) x[12]);
			joindata.setStartHour((String) x[13]);
			joindata.setStartHourActual((String) x[14]);
			joindata.setTotalHour((String) x[15]);
			// joindata.setUpdatedTime((String) x[16]);
			joindata.setStructId((Integer) x[17]);
			joindata.setCheckDelete((Integer) x[18]);
			joindata.setName((String) x[21]);
			joindata.setPosition((String) x[22]);
			joindata.setProject((String) x[23]);
			joindata.setSignature((String) x[24]);
			joindata.setStaffId((String) x[25]);
			joindata.setTeam((String) x[26]);
			System.out.println(joindata);
			
			Double basicsalary = teamRepo.findSalaryByStaffId((String) x[22]);
			System.out.println(" Salary &&&&&&&&&&&&&&&&&&&&&" + basicsalary);

			Double totalhour = (double) Integer.parseInt((String) x[15]);
			System.out.println("&&&&&&&&&&&&&&&&&&&&&" + totalhour);

			Double salary = (((basicsalary * 12) / 52 / 48) * 2) * totalhour;

			BigDecimal otsalary = BigDecimal.valueOf(salary);
			System.out.println("&&&&&&&&&&&&&&&&&&&&&" + otsalary);

			
			OTFees dto = new OTFees();
			
			dto.setFeesformId((String) x[6]);
			dto.setOtId((int) x[0]);
			dto.setPosition((String) x[22]);
			dto.setFees(otsalary);
			
			feesService.saveOTFees(dto);
			
			joindata.setFees(otsalary);


			alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());

			System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
					+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + ">>>  " + x[10]
					+ ">>>  " + x[11] + "<br>" + x[12] + ">>>  " + x[13] + ">>>  " + x[14] + ">>>  " + x[15] + ">>>  "
					+ x[16] + ">>>  " + x[17] + "<br>" + x[18] + ">>>  " + x[19] + ">>>  " + x[20] + ">>>  " + x[21]
					+ ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24]);
		}
		model.addAttribute("AllData", alldata);
//	model.addAttribute("currentPage", page);

		System.out.println(alldata);
		return new ModelAndView("IBX006", "AllDataBean", new JoinDTO());
	}

	

	@PostMapping("/hrapprove")
	public String HRapproveApplier(@ModelAttribute("AllDataBean") JoinDTO joindto, HttpSession session, ModelMap model,
			RedirectAttributes redirectAtt, @RequestParam("file") MultipartFile multipartFile) throws IOException {
		
		if(session.getAttribute("sessionUser") ==null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}

		TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");
		
		System.out.println("Position ++++ " +joindto.getPosition());
		
	

		OtFormDTO otdto = otFormService.updateSendTo(joindto.getOtId());

		otdto.setInboxStatus("Approved");

		System.out.println();
		otFormService.updateOtForm(otdto, joindto.getOtId());

		LocalDateTime localDateTime = LocalDateTime.now();
		StatusDTO dto = new StatusDTO();
		System.out.println("*************" + joindto.getOtId() + "*************");
		dto.setRemark(joindto.getRemark());
		dto.setStatus("Approved");
		dto.setUpdateTime(localDateTime);
		dto.setOtFormId(joindto.getOtId());
		dto.setResponse(team.getStaffId());
		dto.setForm_id(joindto.getFormId());
		dto.setForm_id(joindto.getFormId());
		dto.setPosition(team.getPosition());

		statusService.approveApplier(dto);

		// signature upload updated
		if (!multipartFile.isEmpty()) {
			// signature upload
			String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			List<TeamStructure> sign = new ArrayList<TeamStructure>();
			sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
			for (TeamStructure s : sign) {
				s.setSignature(signatureName);

				TeamStructure saveSignature = teamExcelService.saveSignature(s, s.getStructId());

				String uploadDir = "./staff-signature/" + saveSignature.getStructId();
				Path uploadPath = Paths.get(uploadDir);

				if (!Files.exists(uploadPath)) {
					Files.createDirectories(uploadPath);
				}

				try (InputStream inputStream = multipartFile.getInputStream()) {
					Path filePath = uploadPath.resolve(signatureName);
					Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException ioe) {
					throw new IOException("Could not save signature file: " + signatureName, ioe);
				}
			}

		}
		redirectAtt.addFlashAttribute("message", "Approved Successfully.");

		return "redirect:/hrinbox";
	}

	@PostMapping("/hrreject")
	public String HRrejectApplier(@ModelAttribute("AllDataBean") JoinDTO joindto, HttpSession session, ModelMap model,
			RedirectAttributes redirectAtt, @RequestParam("file") MultipartFile multipartFile) throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		
		TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");

		OtFormDTO otdto = otFormService.updateSendTo(joindto.getOtId());
		otdto.setInboxStatus("Rejected");
		otdto.setSentTo(joindto.getSentTo());

		System.out.println();
		otFormService.updateOtForm(otdto, joindto.getOtId());

		LocalDateTime localDateTime = LocalDateTime.now();
		StatusDTO dto = new StatusDTO();
		System.out.println("*************" + joindto.getOtId() + "*************");
		dto.setRemark(joindto.getRemark());
		dto.setStatus("Rejected");
		dto.setUpdateTime(localDateTime);
		dto.setOtFormId(joindto.getOtId());
		dto.setResponse(team.getStaffId());
		dto.setForm_id(joindto.getFormId());
		dto.setPosition(team.getPosition());

		statusService.approveApplier(dto);

//				if(!joindto.getFilename().equals("")) {
//					redirectAtt.addFlashAttribute("message", "OT Form is saved.");
//				}else {
//					redirectAtt.addFlashAttribute("message", "OT Form Approved.");
//				}

		// signature upload updated
		if (!multipartFile.isEmpty()) {
			// signature upload
			String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			List<TeamStructure> sign = new ArrayList<TeamStructure>();
			sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
			for (TeamStructure s : sign) {
				s.setSignature(signatureName);

				TeamStructure saveSignature = teamExcelService.saveSignature(s, s.getStructId());

				String uploadDir = "./staff-signature/" + saveSignature.getStructId();
				Path uploadPath = Paths.get(uploadDir);

				if (!Files.exists(uploadPath)) {
					Files.createDirectories(uploadPath);
				}

				try (InputStream inputStream = multipartFile.getInputStream()) {
					Path filePath = uploadPath.resolve(signatureName);
					Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException ioe) {
					throw new IOException("Could not save signature file: " + signatureName, ioe);
				}
			}

		}
		redirectAtt.addFlashAttribute("message", "You have Rejected.");

		return "redirect:/hrinbox";
	}

	@PostMapping("/hrrevise")
	public String HRreviseApplier(@ModelAttribute("AllDataBean") JoinDTO joindto, HttpSession session, ModelMap model,
			RedirectAttributes redirectAtt, @RequestParam("file") MultipartFile multipartFile) throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		
		TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");
//			String sentToName = joindto.getSentTo();
//			if(!joindto.getFilename().equals("")) {
//				sentToName=null;
//			}

//		OtFormDTO checkFormId = otFormService.checkFormId();
//		String formId = "DAT_000001";
//		Integer tablePkId;
//		try {
//			tablePkId = checkFormId.getId();
//		} catch (Exception e) {
//			tablePkId = 0;
//		}
//		System.out.println(tablePkId);
//		if (tablePkId >= 99999) {
//			formId = "DAT_" + (tablePkId + 1);
//		} else if (tablePkId >= 9999) {
//			formId = "DAT_0" + (tablePkId + 1);
//		} else if (tablePkId >= 999) {
//			formId = "DAT_00" + (tablePkId + 1);
//		} else if (tablePkId >= 99) {
//			formId = "DAT_000" + (tablePkId + 1);
//		} else if (tablePkId >= 9) {
//			formId = "DAT_0000" + (tablePkId + 1);
//		} else {
//			formId = "DAT_00000" + (tablePkId + 1);
//		}

		OtFormDTO otdto = otFormService.updateSendTo(joindto.getOtId());
		otdto.setInboxStatus("Revised");
		otdto.setSentTo(joindto.getSentTo());

		System.out.println();
		otFormService.updateOtForm(otdto, joindto.getOtId());

		LocalDateTime localDateTime = LocalDateTime.now();
		StatusDTO dto = new StatusDTO();
		System.out.println("*************" + joindto.getOtId() + "*************");
		dto.setRemark(joindto.getRemark());
		dto.setStatus("Revised");
		dto.setUpdateTime(localDateTime);
		dto.setOtFormId(joindto.getOtId());
		dto.setResponse(team.getStaffId());
		dto.setForm_id(joindto.getFormId());
		dto.setPosition(team.getPosition());

		statusService.approveApplier(dto);

//				if(!joindto.getFilename().equals("")) {
//					redirectAtt.addFlashAttribute("message", "OT Form is saved.");
//				}else {
//					redirectAtt.addFlashAttribute("message", "OT Form Approved.");
//				}

		// signature upload updated
		if (!multipartFile.isEmpty()) {
			// signature upload
			String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			List<TeamStructure> sign = new ArrayList<TeamStructure>();
			sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
			for (TeamStructure s : sign) {
				s.setSignature(signatureName);

				TeamStructure saveSignature = teamExcelService.saveSignature(s, s.getStructId());

				String uploadDir = "./staff-signature/" + saveSignature.getStructId();
				Path uploadPath = Paths.get(uploadDir);

				if (!Files.exists(uploadPath)) {
					Files.createDirectories(uploadPath);
				}

				try (InputStream inputStream = multipartFile.getInputStream()) {
					Path filePath = uploadPath.resolve(signatureName);
					Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException ioe) {
					throw new IOException("Could not save signature file: " + signatureName, ioe);
				}
			}

		}
		redirectAtt.addFlashAttribute("message", "Revised to Approver.");
		return "redirect:/hrinbox";
	}

}
