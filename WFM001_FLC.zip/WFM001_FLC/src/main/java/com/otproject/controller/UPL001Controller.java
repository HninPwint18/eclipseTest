package com.otproject.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.helper.ExcelHelper;
import com.otproject.helper.SalaryExcelHelper;
import com.otproject.service.SalaryExcelService;
import com.otproject.service.TeamExcelService;

@Controller
public class UPL001Controller {

	@Autowired
	LGN001Controller loginController;

	@Autowired
	TeamExcelService teamExcelService;

	@Autowired
	SalaryExcelService salaryExcelService;

	@GetMapping("/uploadData")
	public String systemAdminUploadData(ModelMap model,HttpSession session, RedirectAttributes reatt) {
	
		if(session.getAttribute("sessionUser") ==null) {
					reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return "redirect:/login";
				}
//		for user profile
//		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
//		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());
//
//		model.addAttribute("project", project);
//		model.addAttribute("staff", staffData);

		return "UPL001";
	}

	@PostMapping("/upload")
	public String uploadFile(@RequestParam("file") MultipartFile file, ModelMap model,HttpSession session, RedirectAttributes redirectAtt) {
		
		if(session.getAttribute("sessionUser") ==null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		
		String message = "";
		if (ExcelHelper.hasExcelFormat(file)) {
			try {
				teamExcelService.save(file);
				message = "Uploaded the Team Structure file successfully: " + file.getOriginalFilename();
				model.addAttribute("message", message);
				return "UPL001";
			} catch (Exception e) {
				message = "Could not upload the Team Structure file: " + file.getOriginalFilename() + "!";
				model.addAttribute("message", message);
				return "UPL001";
			}
		}
		message = "Please upload an excel file!";
		model.addAttribute("message", message);
		return "UPL001";
	}

	@PostMapping("/uploadSalary")
	public String uploadSalaryFile(@RequestParam("fileSalary") MultipartFile file, ModelMap model,HttpSession session,
			RedirectAttributes redirectAtt) {
		if(session.getAttribute("sessionUser") ==null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
		String message = "";
		if (SalaryExcelHelper.hasExcelFormat(file)) {
			try {
				salaryExcelService.save(file);
				message = "Uploaded the salary file successfully: " + file.getOriginalFilename();
				model.addAttribute("message", message);
				return "UPL001";
			} catch (Exception e) {
				message = "Could not upload the salary file: " + file.getOriginalFilename() + "!";
				model.addAttribute("message", message);
				return "UPL001";
			}
		}
		message = "Please upload an excel file!";
		model.addAttribute("message", message);
		return "UPL001";
	}

}
