package com.otproject.controller;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.bean.OtFormBean;
import com.otproject.dto.OtFormDTO;
import com.otproject.dto.StatusDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.service.OtFormService;
import com.otproject.service.StatusService;
import com.otproject.service.TeamExcelService;

@Controller
public class TeamMemberController {

	@Autowired
	LGN001Controller loginController;

	@Autowired
	OtFormService otFormService;

	@Autowired
	TeamExcelService teamExcelService;
	
	@Autowired
	StatusService statusService;

	@ModelAttribute("projectListOt")
	public Map<Integer, String> projectList() {

		Map<Integer, String> projectListOt = new HashMap<Integer, String>();
		projectListOt = teamExcelService.selectAllProjectIdForOt(loginController.getStaffId().getStaffId());
		return projectListOt;
	}

	@ModelAttribute("finalNameList")
	public List<TeamStructure> finalNameList() {

		List<TeamStructure> sentToList = teamExcelService
				.selectForSentToProjectId(loginController.getStaffId().getStaffId());
		List<TeamStructure> nameList = new ArrayList<TeamStructure>();
		int count = 0;
		for (TeamStructure sl : sentToList) {
			List<TeamStructure> name = teamExcelService.selectForSentToCheckName(sl.getProject(), sl.getStaffId());
			for (TeamStructure n : name) {
				nameList.add(n);
			}
		}

		if (sentToList.size() > 1) {
			for (int i = 0; i < nameList.size(); i++) {
				count = 0;
				for (int j = 0; j < nameList.size(); j++) {

					if (nameList.get(i).getName().equals(nameList.get(j).getName())) {

						count++;
						if (count > 1) {
							nameList.remove(j);
						}
					}
				}
			}
		}
		return nameList;
	}

	@ModelAttribute("saveFileList")
	public List<OtFormDTO> saveFileList() {
		List<TeamStructure> sentToList = teamExcelService
				.selectForSentToProjectId(loginController.getStaffId().getStaffId());
		List<OtFormDTO> saveFileList = new ArrayList<OtFormDTO>();
		for (TeamStructure sl : sentToList) {
			List<OtFormDTO> saveFile = otFormService.saveFiles(sl.getStructId());
			for (OtFormDTO s : saveFile) {
				saveFileList.add(s);
			}
		}
		return saveFileList;
	}

	@GetMapping("/myotform")
	public ModelAndView otFormUploadPage(ModelMap model,HttpSession session,RedirectAttributes reatt) {
		
		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}
		List<TeamStructure> signatureList = teamExcelService
				.selectForSentToProjectId(loginController.getStaffId().getStaffId());
		model.addAttribute("signatureList", signatureList);
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);

		return new ModelAndView("OTF004", "otFormBean", new OtFormBean());
	}

	@PostMapping("/myuploadForm")
	public String uploadForm(@ModelAttribute("otFormBean") OtFormBean otBean, HttpSession session, ModelMap model,@RequestParam("button") String button,
			RedirectAttributes redirectAtt, @RequestParam("file") MultipartFile multipartFile) throws IOException {

		if (session.getAttribute("sessionUser") == null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		
		if(session.getAttribute("sessionUser") ==null) {
					redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return "redirect:/login";
				}
		
		TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");
		String sentToName = otBean.getSentTo();
//		
		String filename=otBean.getFilename();
//		
//		if(!sentToName.equals("null") && filename.equals("")) {
//			filename="";
//		}else if(sentToName.equals("null") && !filename.equals("")) {
//			sentToName="null";
//		}else {
//			OtFormDTO checkFormId = otFormService.checkFormId();
//			int idForm = checkFormId.getId()+1;
//			filename="File"+idForm;
//		}

		System.out.println("*************************************************");
		System.out.println(otBean.getStartHour());
		System.out.println(otBean.getStartHourActual());
		System.out.println(otBean.getFinishHour());
		System.out.println(otBean.getFinishHourActual());
		System.out.println(otBean.getOtDate());
		System.out.println(otBean.getOtDateActual());
		System.out.println("*************************************************");
		if (!otBean.getStartHour().equals(otBean.getStartHourActual())
				|| !otBean.getFinishHour().equals(otBean.getFinishHourActual())
				|| !otBean.getOtDate().equals(otBean.getOtDateActual())) {
			model.addAttribute("message", "Must be same Plan Hour and Actual Hour");
			List<TeamStructure> signatureList = teamExcelService.selectForSentToProjectId(team.getStaffId());
			model.addAttribute("signatureList", signatureList);
			return "OTF004";
		}

		String formId;
		OtFormDTO checkFormId = otFormService.checkFormId();
		if(checkFormId == null) {
			formId = "DAT_000001";
		}
		
		Integer tablePkId;
		try {
			tablePkId = checkFormId.getId();
		} catch (Exception e) {
			tablePkId = 0;
		}
		System.out.println(tablePkId);
		if (tablePkId >= 99999) {
			formId = "DAT_" + (tablePkId + 1);
		} else if (tablePkId >= 9999) {
			formId = "DAT_0" + (tablePkId + 1);
		} else if (tablePkId >= 999) {
			formId = "DAT_00" + (tablePkId + 1);
		} else if (tablePkId >= 99) {
			formId = "DAT_000" + (tablePkId + 1);
		} else if (tablePkId >= 9) {
			formId = "DAT_0000" + (tablePkId + 1);
		} else {
			formId = "DAT_00000" + (tablePkId + 1);
		}

		LocalDateTime localDateTime = LocalDateTime.now();
		OtFormDTO dto = new OtFormDTO();
		dto.setFormId(formId);
		dto.setOtDate(otBean.getOtDate());
		dto.setStartHour(otBean.getStartHour());
		dto.setFinishHour(otBean.getFinishHour());
		dto.setTotalHour(otBean.getTotalHour());
		dto.setDay(otBean.getDay());
		dto.setReason(otBean.getReason());
//		dto.setInboxStatus("Requested");
		dto.setCreatedTime(localDateTime);
		dto.setUpdatedTime(localDateTime);
		dto.setOtTeam(otBean.getOtTeam());
		dto.setSentTo(sentToName);
//		dto.setFilename(filename);
		dto.setOtDateActual(otBean.getOtDateActual());
		dto.setStartHourActual(otBean.getStartHourActual());
		dto.setFinishHourActual(otBean.getFinishHourActual());
		
		System.out.println(button);
		System.out.println(filename);
		System.out.println(sentToName);
		
		
		if(button.equals("save")) {
			if(filename.equals("")) {
				int idForm = checkFormId.getId() + 1;
				filename = "File" + idForm;
			}
			
			dto.setFilename(filename);
			dto.setInboxStatus("");
			redirectAtt.addFlashAttribute("message", "OT Form is saved.");
			
		}else if(button.equals("apply")) {
			if(sentToName.equals("none")) {
				int idForm = checkFormId.getId() + 1;
				filename = "File" + idForm;
				dto.setFilename(filename);
				dto.setInboxStatus("");
				redirectAtt.addFlashAttribute("message", "OT Form is saved.");
			}else {
				dto.setFilename("");
				dto.setInboxStatus("Requested");
				redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
				StatusDTO sdto = new StatusDTO();
				sdto.setStatus("Requested");
				sdto.setUpdateTime(localDateTime);
				
				sdto.setResponse(loginController.getStaffId().getStaffId());
				sdto.setForm_id(formId);
				sdto.setPosition(loginController.getStaffId().getPosition());
				
				statusService.approveApplier(sdto);
			}
			
			
		}

		otFormService.saveOtForm(dto);

//		if (!filename.equals("")) {
//			redirectAtt.addFlashAttribute("message", "OT Form is saved.");
//		} else {
//			redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
//		}

		// signature upload updated
		if (!multipartFile.isEmpty()) {
			// signature upload
			String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			List<TeamStructure> sign = new ArrayList<TeamStructure>();
			sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
			for (TeamStructure s : sign) {
				s.setSignature(signatureName);

				TeamStructure saveSignature = teamExcelService.saveSignature(s, s.getStructId());

				String uploadDir = "./staff-signature/" + saveSignature.getStructId();
				Path uploadPath = Paths.get(uploadDir);

				if (!Files.exists(uploadPath)) {
					Files.createDirectories(uploadPath);
				}

				try (InputStream inputStream = multipartFile.getInputStream()) {
					Path filePath = uploadPath.resolve(signatureName);
					Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException ioe) {
					throw new IOException("Could not save signature file: " + signatureName, ioe);
				}
			}

		}

		return "redirect:/myotform";
	}

	@PostMapping("/mysaveFileSetup")
	public ModelAndView saveFile(@ModelAttribute("otFormBean") OtFormBean bean, ModelMap model,HttpSession session, RedirectAttributes reatt) throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
					reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return new ModelAndView("LGN001", "loginBean", new LoginBean());
				}
		
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		
		if (bean.getFilename().equals("None")) {
			return new ModelAndView("OTF004", "otFormBean", new OtFormBean());
		}

		List<TeamStructure> signatureList = teamExcelService
				.selectForSentToProjectId(loginController.getStaffId().getStaffId());
		model.addAttribute("signatureList", signatureList);
		OtFormDTO file = otFormService.selectFile(bean.getFilename());
		return new ModelAndView("OTF005", "otFormBeanDto", file);
	}

	@PostMapping("/myupdateSaveFile")
	public String updateSaveFile(@ModelAttribute("otFormBeanDto") OtFormBean otBean, ModelMap model,@RequestParam("button") String button,
			RedirectAttributes redirectAtt,HttpSession session, @RequestParam("file") MultipartFile multipartFile) throws IOException {

		if(session.getAttribute("sessionUser") ==null) {
					redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
					return "redirect:/login";
				}
		
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		
		if (!otBean.getStartHour().equals(otBean.getStartHourActual())
				|| !otBean.getFinishHour().equals(otBean.getFinishHourActual())
				|| !otBean.getOtDate().equals(otBean.getOtDateActual())) {
			model.addAttribute("message", "Must be same Plan Hour and Actual Hour");
			List<TeamStructure> signatureList = teamExcelService
					.selectForSentToProjectId(loginController.getStaffId().getStaffId());
			model.addAttribute("signatureList", signatureList);
			model.addAttribute("otFormBean", new OtFormBean());
			return "OTF005";
		}

		String sentToName = otBean.getSentTo();
//		
		String filename=otBean.getFilename();
//		
//		if(!sentToName.equals("null") && filename.equals("")) {
//			filename="";
//		}else if(sentToName.equals("null") && !filename.equals("")) {
//			sentToName="null";
//		}else {
//			OtFormDTO checkFormId = otFormService.checkFormId();
//			int idForm = checkFormId.getId()+1;
//			filename="File"+idForm;
//		}

		
		try {
			

			LocalDateTime localDateTime = LocalDateTime.now();
			OtFormDTO dto = new OtFormDTO();
			dto.setId(otBean.getId());
			dto.setFormId(otBean.getFormId());
			dto.setOtDate(otBean.getOtDate());
			dto.setStartHour(otBean.getStartHour());
			dto.setFinishHour(otBean.getFinishHour());
			dto.setTotalHour(otBean.getTotalHour());
			dto.setDay(otBean.getDay());
			dto.setReason(otBean.getReason());
//			dto.setInboxStatus("Requested");
			dto.setCreatedTime(otBean.getCreatedTime());
			dto.setUpdatedTime(localDateTime);
			dto.setOtTeam(otBean.getOtTeam());
			dto.setSentTo(sentToName);
//			dto.setFilename(filename);
			dto.setOtDateActual(otBean.getOtDateActual());
			dto.setStartHourActual(otBean.getStartHourActual());
			dto.setFinishHourActual(otBean.getFinishHourActual());
			
			OtFormDTO checkFormId = otFormService.checkFormId();
			if(button.equals("save")) {
				if(filename.equals("")) {
					int idForm = checkFormId.getId() + 1;
					filename = "File" + idForm;
				}
				
				dto.setFilename(filename);
				dto.setInboxStatus("");
				redirectAtt.addFlashAttribute("message", "OT Form is saved.");
				
			}else if(button.equals("apply")) {
				if(sentToName.equals("none")) {
					int idForm = checkFormId.getId() + 1;
					filename = "File" + idForm;
					dto.setFilename(filename);
					dto.setInboxStatus("");
					redirectAtt.addFlashAttribute("message", "OT Form is saved.");
				}else {
					dto.setFilename("");
					dto.setInboxStatus("Requested");
					redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
				}
				
				
			}

			otFormService.updateOtForm(dto, otBean.getId());

//			if (!filename.equals("")) {
//				redirectAtt.addFlashAttribute("message", "OT Form is saved.");
//			} else {
//				redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
//			}
		} catch (Exception e) {
			return "redirect:/myotform";
		}

		// signature upload updated
		if (!multipartFile.isEmpty()) {
			// signature upload
			String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
			List<TeamStructure> sign = new ArrayList<TeamStructure>();
			sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
			for (TeamStructure s : sign) {
				s.setSignature(signatureName);

				TeamStructure saveSignature = teamExcelService.saveSignature(s, s.getStructId());

				String uploadDir = "./staff-signature/" + saveSignature.getStructId();
				Path uploadPath = Paths.get(uploadDir);

				if (!Files.exists(uploadPath)) {
					Files.createDirectories(uploadPath);
				}

				try (InputStream inputStream = multipartFile.getInputStream()) {
					Path filePath = uploadPath.resolve(signatureName);
					Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
				} catch (IOException ioe) {
					throw new IOException("Could not save signature file: " + signatureName, ioe);
				}
			}

		}
		return "redirect:/myotform";
	}
	
	// For revise update
		@GetMapping("/memberRevised")
		public ModelAndView revised(ModelMap model, HttpSession session, RedirectAttributes reatt,
				@RequestParam("project") String project) {

			if (session.getAttribute("sessionUser") == null) {
				reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
				return new ModelAndView("LGN001", "loginBean", new LoginBean());
			}

			// for user profile
			TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
			List<String> projectlist = teamExcelService.selectAllProject(staffData.getStaffId());

			model.addAttribute("project", projectlist);
			model.addAttribute("staff", staffData);

			OtFormDTO revisedForm = otFormService.revisedForm(project);
			List<TeamStructure> signatureList = teamExcelService
					.selectForSentToProjectId(loginController.getStaffId().getStaffId());
			model.addAttribute("signatureList", signatureList);
			return new ModelAndView("OTF007", "otFormBean", revisedForm);

		}

		@PostMapping("/memberupdateRevisedFile")
		public String updateRevisedFile(@ModelAttribute("otFormBean") OtFormBean otBean, ModelMap model,@RequestParam("button") String button,
				RedirectAttributes redirectAtt, HttpSession session, @RequestParam("file") MultipartFile multipartFile)
				throws IOException {

			if (session.getAttribute("sessionUser") == null) {
				redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
				return "redirect:/login";
			}
			
//			for user profile
			TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
			List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

			model.addAttribute("project", project);
			model.addAttribute("staff", staffData);

			if (!otBean.getStartHour().equals(otBean.getStartHourActual())
					|| !otBean.getFinishHour().equals(otBean.getFinishHourActual())
					|| !otBean.getOtDate().equals(otBean.getOtDateActual())) {
				model.addAttribute("message", "Must be same Plan Hour and Actual Hour");
				List<TeamStructure> signatureList = teamExcelService
						.selectForSentToProjectId(loginController.getStaffId().getStaffId());
				model.addAttribute("signatureList", signatureList);
				model.addAttribute("otFormBean", new OtFormBean());
				return "OTF007";
			}

			String sentToName = otBean.getSentTo();
//			
			String filename = otBean.getFilename();
//			
//			if (!sentToName.equals("null") && filename.equals("")) {
//				filename = "";
//			} else if (sentToName.equals("null") && !filename.equals("")) {
//				sentToName = "null";
//			} else {
//				OtFormDTO checkFormId = otFormService.checkFormId();
//				int idForm = checkFormId.getId() + 1;
//				filename = "File" + idForm;
//			}

			System.out.println(otBean.getId());
			System.out.println("project - " + otBean.getOtTeam());
			System.out.println(otBean.getReason());
			System.out.println(otBean.getOtDate());
			System.out.println(otBean.getStartHour());
			System.out.println(otBean.getFinishHour());
			System.out.println(otBean.getDay());
			System.out.println(otBean.getTotalHour());
			System.out.println(sentToName);
			System.out.println(filename);
			System.out.println(otBean.getOtDateActual());
			System.out.println(otBean.getStartHourActual());
			System.out.println(otBean.getFinishHourActual());

			try {
				LocalDateTime localDateTime = LocalDateTime.now();
				OtFormDTO dto = new OtFormDTO();
				dto.setId(otBean.getId());
				dto.setFormId(otBean.getFormId());
				dto.setOtDate(otBean.getOtDate());
				dto.setStartHour(otBean.getStartHour());
				dto.setFinishHour(otBean.getFinishHour());
				dto.setTotalHour(otBean.getTotalHour());
				dto.setDay(otBean.getDay());
				dto.setReason(otBean.getReason());
//				dto.setInboxStatus("requested");
				dto.setCreatedTime(otBean.getCreatedTime());
				dto.setUpdatedTime(localDateTime);
				dto.setOtTeam(otBean.getOtTeam());
				dto.setSentTo(sentToName);
//				dto.setFilename(filename);
				dto.setOtDateActual(otBean.getOtDateActual());
				dto.setStartHourActual(otBean.getStartHourActual());
				dto.setFinishHourActual(otBean.getFinishHourActual());
				
				OtFormDTO checkFormId = otFormService.checkFormId();
				if(button.equals("save")) {
					if(filename.equals("")) {
						int idForm = checkFormId.getId() + 1;
						filename = "File" + idForm;
					}
					
					dto.setFilename(filename);
					dto.setInboxStatus("");
					redirectAtt.addFlashAttribute("message", "OT Form is saved.");
					
				}else if(button.equals("apply")) {
					if(sentToName.equals("none")) {
						int idForm = checkFormId.getId() + 1;
						filename = "File" + idForm;
						dto.setFilename(filename);
						dto.setInboxStatus("");
						redirectAtt.addFlashAttribute("message", "OT Form is saved.");
					}else {
						dto.setFilename("");
						dto.setInboxStatus("Requested");
						redirectAtt.addFlashAttribute("message", "OT Form applied successfully.");
					}
					
					
				}
				otFormService.updateOtForm(dto, otBean.getId());

//				if (!filename.equals("")) {
//					redirectAtt.addFlashAttribute("message", "OT Form is saved.");
//				} else {
//					redirectAtt.addFlashAttribute("message",
//							"OT Form applied successfully, cannot save because this is revised file.");
//				}
			} catch (Exception e) {
				return "redirect:/myotform";
			}

			// signature upload updated
			if (!multipartFile.isEmpty()) {
				// signature upload
				String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
				List<TeamStructure> sign = new ArrayList<TeamStructure>();
				sign = teamExcelService.selectForSignature(loginController.getStaffId().getStaffId());
				for (TeamStructure s : sign) {
					s.setSignature(signatureName);

					TeamStructure saveSignature = teamExcelService.saveSignature(s, s.getStructId());

					String uploadDir = "./staff-signature/" + saveSignature.getStructId();
					Path uploadPath = Paths.get(uploadDir);

					if (!Files.exists(uploadPath)) {
						Files.createDirectories(uploadPath);
					}

					try (InputStream inputStream = multipartFile.getInputStream()) {
						Path filePath = uploadPath.resolve(signatureName);
						Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
					} catch (IOException ioe) {
						throw new IOException("Could not save signature file: " + signatureName, ioe);
					}
				}

			}

			// this will be going to redirect inbox
			return "redirect:/myotform";
		}


}
