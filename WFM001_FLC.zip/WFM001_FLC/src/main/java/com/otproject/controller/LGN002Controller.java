package com.otproject.controller;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.dto.TeamStructure;
import com.otproject.service.TeamExcelService;

@Controller
public class LGN002Controller {
	
	@Autowired
	TeamExcelService teamExcelService;
	
	@GetMapping(value = "/signature")
	public ModelAndView loginPage(HttpSession session, RedirectAttributes reatt) {
		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}
		return new ModelAndView("LGN002", "teamBean", new TeamStructure());
	}
	
	@PostMapping("/signature")
	public String Login(
			ModelMap model, RedirectAttributes redirectAtt, HttpSession session, @RequestParam("file") MultipartFile multipartFile) throws IOException {
		
		TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");
		String signature = team.getSignature();
//		for(TeamStructure pid:list) {
//		pidSignature = pid.getProject();
//		System.out.println("project id for signature "+pid.getProject());
//		}
		 if(signature == null) {	
			 if (!multipartFile.isEmpty()) {
					// signature upload
					String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
					List<TeamStructure> sign = new ArrayList<TeamStructure>();
					sign = teamExcelService.selectForSignature(team.getStaffId());
					for (TeamStructure s : sign) {
						s.setSignature(signatureName);

						TeamStructure saveSignature = teamExcelService.saveSignature(s, s.getStructId());

						String uploadDir = "./staff-signature/" + saveSignature.getStructId();
						Path uploadPath = Paths.get(uploadDir);

						if (!Files.exists(uploadPath)) {
							Files.createDirectories(uploadPath);
						}

						try (InputStream inputStream = multipartFile.getInputStream()) {
							Path filePath = uploadPath.resolve(signatureName);
							Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
						} catch (IOException ioe) {
							throw new IOException("Could not save signature file: " + signatureName, ioe);
						}
					}

				}
		 }
		 
		    redirectAtt.addAttribute("message", "Signature successfully uploaded!!");
		if(team.getTeam().equals("HR")) {
			return "redirect:/hrinbox";
		}
		else {
			if(team.getPosition().equals("Division Head")) {
				return "redirect:/inbox";
			}
			else if(team.getPosition().equals("Dept Head")) {
				return "redirect:/inbox";
			}
			else if(team.getPosition().equals("Project Manager")) {
				return "redirect:/inbox";
			}
			else {
				return "redirect:/myotform";
			}
		}
	}
	
	@GetMapping(value="/signatureUpdate")
	public ModelAndView signatureUpdate(HttpSession session, RedirectAttributes reatt) {
		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}
		return new ModelAndView("LGN003", "teamBean", new TeamStructure());
	}
	
	@PostMapping("/signatureUpdate")
	public String signatureUpdatePage(
			ModelMap model, RedirectAttributes redirectAtt, HttpSession session, @RequestParam("file") MultipartFile multipartFile) throws IOException {
		
		TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");
		
//		for(TeamStructure pid:list) {
//		pidSignature = pid.getProject();
//		System.out.println("project id for signature "+pid.getProject());
//		}	
			 if (!multipartFile.isEmpty()) {
					// signature upload
					String signatureName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
					List<TeamStructure> sign = new ArrayList<TeamStructure>();
					sign = teamExcelService.selectForSignature(team.getStaffId());
					for (TeamStructure s : sign) {
						s.setSignature(signatureName);

						TeamStructure saveSignature = teamExcelService.saveSignature(s, s.getStructId());

						String uploadDir = "./staff-signature/" + saveSignature.getStructId();
						Path uploadPath = Paths.get(uploadDir);

						if (!Files.exists(uploadPath)) {
							Files.createDirectories(uploadPath);
						}

						try (InputStream inputStream = multipartFile.getInputStream()) {
							Path filePath = uploadPath.resolve(signatureName);
							Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
						} catch (IOException ioe) {
							throw new IOException("Could not save signature file: " + signatureName, ioe);
						}
					}

				
		 }
		 
		 redirectAtt.addAttribute("message", "Signature successfully uploaded!!");
		if(team.getTeam().equals("HR")) {
			return "redirect:/hrinbox";
		}
		else {
			if(team.getPosition().equals("Division Head")) {
				return "redirect:/inbox";
			}
			else if(team.getPosition().equals("Dept Head")) {
				return "redirect:/inbox";
			}
			else if(team.getPosition().equals("Project Manager")) {
				return "redirect:/inbox";
			}
			else {
				return "redirect:/myotform";
			}
		}
	}
	
	@GetMapping(value = "/skip")
	public String skipPage(HttpSession session,ModelMap model) {
		TeamStructure team = (TeamStructure) session.getAttribute("sessionUser");
		 model.addAttribute("message", "You skip signature upload process!!");
			if(team.getTeam().equals("HR")) {
				return "redirect:/hrinbox";
			}
			else {
				if(team.getPosition().equals("Division Head")) {
					return "redirect:/inbox";
				}
				else if(team.getPosition().equals("Dept Head")) {
					return "redirect:/inbox";
				}
				else if(team.getPosition().equals("Project Manager")) {
					return "redirect:/inbox";
				}
				else {
					return "redirect:/myotform";
				}
			}
	}

}
