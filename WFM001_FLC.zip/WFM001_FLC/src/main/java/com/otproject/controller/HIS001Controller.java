package com.otproject.controller;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.dto.JoinDTO;
import com.otproject.dto.OtFormDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.OtFormRepository;
import com.otproject.service.TeamExcelService;

@Controller
public class HIS001Controller {

	@Autowired
	LGN001Controller login;

	@Autowired
	private OtFormRepository otRepo;
	
	@Autowired
	TeamExcelService teamExcelService;


	@GetMapping("/history")
	public ModelAndView history(ModelMap model, HttpSession session, RedirectAttributes reatt, @RequestParam(defaultValue = "0") int page) {
		//Pageable pageable = PageRequest.of(page, 10);
		
		if(session.getAttribute("sessionUser") ==null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}
		
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(login.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(login.getStaffId().getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);
		
		//OtFormDTO history = otRepo.forHistory(login.getStaffId().getStaffId());
		
		


		List<JoinDTO> alldata = new ArrayList<>();
		List<Object> list = otRepo.findApprovedForHistory(login.getStaffId().getStaffId());
		System.out.println(list.size());
		if (list.size() == 0) {
			model.addAttribute("message", "No Approved Form.");
			model.addAttribute("ApprovedCount", list.size());

		} else {
			for (Object ot : list) {
				Object[] x = (Object[]) ot;
				JoinDTO joindata = new JoinDTO();

				joindata.setOtId((int) x[0]);
				// joindata.setCreatedTime((String) x[1]);
				joindata.setDay((String) x[2]);
				joindata.setFilename((String) x[3]);
				joindata.setFinishHour((String) x[4]);
				joindata.setFinishHourActual((String) x[5]);
				joindata.setFormId((String) x[6]);
				joindata.setInboxStatus((String) x[7]);
				joindata.setOtDate((Date) x[8]);
				joindata.setOtDateActual((Date) x[9]);
				joindata.setReason((String) x[10]);
				joindata.setSalary((BigDecimal) x[11]);
				joindata.setSentTo((String) x[12]);
				joindata.setStartHour((String) x[13]);
				joindata.setStartHourActual((String) x[14]);
				joindata.setTotalHour((String) x[15]);
				// joindata.setUpdatedTime((String) x[16]);
				joindata.setStructId((Integer) x[17]);
				joindata.setCheckDelete((Integer) x[18]);
				joindata.setName((String) x[21]);
				joindata.setPosition((String) x[22]);
				joindata.setProject((String) x[23]);
				joindata.setSignature((String) x[24]);
				joindata.setStaffId((String) x[25]);
				joindata.setTeam((String) x[26]);
				System.out.println(x.length);

				alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());

				System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
						+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + ">>>  " + x[10]
						+ ">>>  " + x[11] + "<br>" + x[12] + ">>>  " + x[13] + ">>>  " + x[14] + ">>>  " + x[15]
						+ ">>>  " + x[16] + ">>>  " + x[17] + "<br>" + x[18] + ">>>  " + x[19] + ">>>  " + x[20]
						+ ">>>  " + x[21] + ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24]);
			}

			model.addAttribute("ApprovedCount", list.size());
			model.addAttribute("AllData", alldata);
			model.addAttribute("currentPage", page);
		}

		List<JoinDTO> alldata1 = new ArrayList<>();
		List<Object> list1 = otRepo.findRejectedForHistory(login.getStaffId().getStaffId());
		System.out.println(list1.size());
		if (list1.size() == 0) {
			model.addAttribute("message", "No Approved Form.");
			model.addAttribute("RejectedCount", list1.size());

		} else {
			for (Object ot : list1) {
				Object[] x = (Object[]) ot;
				JoinDTO joindata = new JoinDTO();

				joindata.setOtId((int) x[0]);
				// joindata.setCreatedTime((String) x[1]);
				joindata.setDay((String) x[2]);
				joindata.setFilename((String) x[3]);
				joindata.setFinishHour((String) x[4]);
				joindata.setFinishHourActual((String) x[5]);
				joindata.setFormId((String) x[6]);
				joindata.setInboxStatus((String) x[7]);
				joindata.setOtDate((Date) x[8]);
				joindata.setOtDateActual((Date) x[9]);
				joindata.setReason((String) x[10]);
				joindata.setSalary((BigDecimal) x[11]);
				joindata.setSentTo((String) x[12]);
				joindata.setStartHour((String) x[13]);
				joindata.setStartHourActual((String) x[14]);
				joindata.setTotalHour((String) x[15]);
				// joindata.setUpdatedTime((String) x[16]);
				joindata.setStructId((Integer) x[17]);
				joindata.setCheckDelete((Integer) x[18]);
				joindata.setName((String) x[21]);
				joindata.setPosition((String) x[22]);
				joindata.setProject((String) x[23]);
				joindata.setSignature((String) x[24]);
				joindata.setStaffId((String) x[25]);
				joindata.setTeam((String) x[26]);
				System.out.println(x.length);

				alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());

				System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
						+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + ">>>  " + x[10]
						+ ">>>  " + x[11] + "<br>" + x[12] + ">>>  " + x[13] + ">>>  " + x[14] + ">>>  " + x[15]
						+ ">>>  " + x[16] + ">>>  " + x[17] + "<br>" + x[18] + ">>>  " + x[19] + ">>>  " + x[20]
						+ ">>>  " + x[21] + ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24]);
			}
			model.addAttribute("RejectedCount", list1.size());
			model.addAttribute("AllData1", alldata1);
		}

		return new ModelAndView("HIS001", "AllDataBean", new JoinDTO());

	}
	
	@GetMapping("/myhistory")
	public ModelAndView memberhistory(ModelMap model, HttpSession session, RedirectAttributes reatt, @RequestParam(defaultValue = "0") int page) {
		//Pageable pageable = PageRequest.of(page, 10);
		
		if(session.getAttribute("sessionUser") ==null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}
		
//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(login.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);

		List<JoinDTO> alldata = new ArrayList<>();
		List<Object> list = otRepo.findApprovedForHistory(login.getStaffId().getStaffId());
		System.out.println(list.size());
		if (list.size() == 0) {
			model.addAttribute("message", "No Approved Form.");
			model.addAttribute("ApprovedCount", list.size());

		} else {
			for (Object ot : list) {
				Object[] x = (Object[]) ot;
				JoinDTO joindata = new JoinDTO();

				joindata.setOtId((int) x[0]);
				// joindata.setCreatedTime((String) x[1]);
				joindata.setDay((String) x[2]);
				joindata.setFilename((String) x[3]);
				joindata.setFinishHour((String) x[4]);
				joindata.setFinishHourActual((String) x[5]);
				joindata.setFormId((String) x[6]);
				joindata.setInboxStatus((String) x[7]);
				joindata.setOtDate((Date) x[8]);
				joindata.setOtDateActual((Date) x[9]);
				joindata.setReason((String) x[10]);
				joindata.setSalary((BigDecimal) x[11]);
				joindata.setSentTo((String) x[12]);
				joindata.setStartHour((String) x[13]);
				joindata.setStartHourActual((String) x[14]);
				joindata.setTotalHour((String) x[15]);
				// joindata.setUpdatedTime((String) x[16]);
				joindata.setStructId((Integer) x[17]);
				joindata.setCheckDelete((Integer) x[18]);
				joindata.setName((String) x[21]);
				joindata.setPosition((String) x[22]);
				joindata.setProject((String) x[23]);
				joindata.setSignature((String) x[24]);
				joindata.setStaffId((String) x[25]);
				joindata.setTeam((String) x[26]);
				System.out.println(x.length);

				alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());

				System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
						+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + ">>>  " + x[10]
						+ ">>>  " + x[11] + "<br>" + x[12] + ">>>  " + x[13] + ">>>  " + x[14] + ">>>  " + x[15]
						+ ">>>  " + x[16] + ">>>  " + x[17] + "<br>" + x[18] + ">>>  " + x[19] + ">>>  " + x[20]
						+ ">>>  " + x[21] + ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24]);
			}

			model.addAttribute("ApprovedCount", list.size());
			model.addAttribute("AllData", alldata);
			model.addAttribute("currentPage", page);
		}

		List<JoinDTO> alldata1 = new ArrayList<>();
		List<Object> list1 = otRepo.findRejectedForHistory(login.getStaffId().getStaffId());
		System.out.println(list1.size());
		if (list1.size() == 0) {
			model.addAttribute("message", "No Approved Form.");
			model.addAttribute("RejectedCount", list1.size());

		} else {
			for (Object ot : list1) {
				Object[] x = (Object[]) ot;
				JoinDTO joindata = new JoinDTO();

				joindata.setOtId((int) x[0]);
				// joindata.setCreatedTime((String) x[1]);
				joindata.setDay((String) x[2]);
				joindata.setFilename((String) x[3]);
				joindata.setFinishHour((String) x[4]);
				joindata.setFinishHourActual((String) x[5]);
				joindata.setFormId((String) x[6]);
				joindata.setInboxStatus((String) x[7]);
				joindata.setOtDate((Date) x[8]);
				joindata.setOtDateActual((Date) x[9]);
				joindata.setReason((String) x[10]);
				joindata.setSalary((BigDecimal) x[11]);
				joindata.setSentTo((String) x[12]);
				joindata.setStartHour((String) x[13]);
				joindata.setStartHourActual((String) x[14]);
				joindata.setTotalHour((String) x[15]);
				// joindata.setUpdatedTime((String) x[16]);
				joindata.setStructId((Integer) x[17]);
				joindata.setCheckDelete((Integer) x[18]);
				joindata.setName((String) x[21]);
				joindata.setPosition((String) x[22]);
				joindata.setProject((String) x[23]);
				joindata.setSignature((String) x[24]);
				joindata.setStaffId((String) x[25]);
				joindata.setTeam((String) x[26]);
				System.out.println(x.length);

				alldata.add(joindata);
//			lis.add(joindata.getStaffId());
//			lis.add(joindata.getName());
//			lis.add(joindata.getInboxStatus());

				System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
						+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + ">>>  " + x[10]
						+ ">>>  " + x[11] + "<br>" + x[12] + ">>>  " + x[13] + ">>>  " + x[14] + ">>>  " + x[15]
						+ ">>>  " + x[16] + ">>>  " + x[17] + "<br>" + x[18] + ">>>  " + x[19] + ">>>  " + x[20]
						+ ">>>  " + x[21] + ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24]);
			}
			model.addAttribute("RejectedCount", list1.size());
			model.addAttribute("AllData1", alldata1);
		}

		return new ModelAndView("HIS005", "AllDataBean", new JoinDTO());

	}

}
