package com.otproject.controller;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.bean.TeamStructureBean;
import com.otproject.dto.TeamStructure;
import com.otproject.service.TeamExcelService;

@Controller
public class LGN001Controller {

	@Autowired
	TeamExcelService teamExcelService;

	@GetMapping(value = "/login")
	public ModelAndView loginPage() {
		return new ModelAndView("LGN001", "loginBean", new LoginBean());
	}

	private HttpSession session;

	@PostMapping("/login")
	public String Login(@ModelAttribute("loginBean") @Validated LoginBean loginBean, BindingResult result,
			ModelMap model, RedirectAttributes redirectAtt, HttpServletRequest request) throws IOException {

		if (result.hasErrors()) {
			model.addAttribute("message", "Failed!");
			return "LGN001";
		}
		System.out.println(loginBean.getStaffId());
		System.out.println(loginBean.getPassword());
		String id = loginBean.getStaffId();
		TeamStructureBean teamBean = new TeamStructureBean();
		teamBean.setStaffId(id);

		TeamStructure checkStaffId = teamExcelService.selectStaffId(loginBean.getStaffId());

		session = request.getSession();
		if (loginBean.getStaffId().equals("11-00000") && loginBean.getPassword().equals("admin")) {
//			session.setAttribute("username", teamBean.getStaffId());
			TeamStructure dto = new TeamStructure();
			dto.setStaffId("11-00000");
			session.setAttribute("sessionUser", dto);
			System.out.println(dto.getStaffId());
			System.out.println(dto);
			return "redirect:/adminDashboard";
		} else {
			if (checkStaffId == null) {
				model.addAttribute("error", "Staff id does not exit");
				return "LGN001";
			} else {

				if (checkStaffId.getTeam().equals("HR") && loginBean.getPassword().equals("hrmanage")) {
					session.setAttribute("sessionUser", checkStaffId);
					return "redirect:/signature";

				} else {
					if (checkStaffId.getPosition().equals("Division Head")
							&& loginBean.getPassword().equals("divhead")) {
						session.setAttribute("sessionUser", checkStaffId);
						if(checkStaffId.getSignature()==null) {
							return "redirect:/signature";
						}
						else {
							return "redirect:/inbox";
						}
						

					} else if (checkStaffId.getPosition().equals("Dept Head")
							&& loginBean.getPassword().equals("dephead")) {
						session.setAttribute("sessionUser", checkStaffId);
						if(checkStaffId.getSignature()==null) {
							return "redirect:/signature";
						}
						else {
							return "redirect:/inbox";
						}
						

					} else if (checkStaffId.getPosition().equals("Project Manager")
							&& loginBean.getPassword().equals("projman")) {
						session.setAttribute("sessionUser", checkStaffId);
						if(checkStaffId.getSignature()==null) {
							return "redirect:/signature";
						}
						else {
							return "redirect:/inbox";
						}
						

					} else if (loginBean.getPassword().equals("member")) {
						session.setAttribute("sessionUser", checkStaffId);
						if(checkStaffId.getSignature()==null) {
							return "redirect:/signature";
						}
						else {
							return "redirect:/myotform";
						}
					

					} else {
						model.addAttribute("error", "Staff id and password does not match");
						return "LGN001";
					}
				}

			}
		}

	}

	public TeamStructure getStaffId() {
		return (TeamStructure) session.getAttribute("sessionUser");
	}

	@RequestMapping(value = "/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		return "redirect:/login";
	}

}
