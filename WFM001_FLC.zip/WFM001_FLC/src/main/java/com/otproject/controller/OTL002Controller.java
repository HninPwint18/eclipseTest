package com.otproject.controller;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.otproject.bean.LoginBean;
import com.otproject.dto.JoinDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.OtFormRepository;
import com.otproject.service.TeamExcelService;

@Controller
public class OTL002Controller {

	@Autowired
	LGN001Controller login;

	@Autowired
	private OtFormRepository otRepo;

	@Autowired
	TeamExcelService teamExcelService;

	@Autowired
	LGN001Controller loginController;

	@GetMapping(value = "/myotpreview")
	public ModelAndView MyOTpreview(@RequestParam("id") String formId, HttpSession session, RedirectAttributes reatt,
			ModelMap model) {

		if (session.getAttribute("sessionUser") == null) {
			reatt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return new ModelAndView("LGN001", "loginBean", new LoginBean());
		}

//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(login.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);

		System.out.println("Mapping Run........");
		List<Object> sign = otRepo.forAllSignatureApproved(formId);
		System.out.println(sign.size());
		// List<JoinDTO> alldata1 = new ArrayList<>();

		List<JoinDTO> pm = new ArrayList<>();
		List<JoinDTO> dep = new ArrayList<>();
		List<JoinDTO> div = new ArrayList<>();
		List<JoinDTO> hr = new ArrayList<>();

		for (Object ot : sign) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();

			if (x[3].toString().equals("Project Manager")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				pm.add(joindata);
			} else if (x[3].toString().equals("Dept Head")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				dep.add(joindata);
			} else if (x[3].toString().equals("Division Head")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				div.add(joindata);
			} else {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				hr.add(joindata);
			}

		}

		model.addAttribute("PM", pm);
		model.addAttribute("Dep", dep);
		model.addAttribute("Div", div);
		model.addAttribute("HR", hr);

//		for (Object ot : sign) {
//			Object[] x = (Object[]) ot;
//			JoinDTO joindata = new JoinDTO();
//			
//			joindata.setName((String) x[0]);
//			joindata.setSignature((String) x[1]);
//			joindata.setStatus((String) x[2]);
//			joindata.setPosition((String) x[3]);
//			joindata.setUpdatedTime(x[4].toString());
//			alldata.add(joindata);
//			
//			for (int i = 0; i < x.length; i++) {
//				System.out.println("$$$  " + i + " $$$" + x[i]);
//			}
//
//		}
//			model.addAttribute("Sign", alldata);
//			
//		
//		System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + alldata);

		List<Object> list1 = otRepo.findAllData(formId);
		List<JoinDTO> alldata1 = new ArrayList<>();

		for (Object ot : list1) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();

			joindata.setOtId((int) x[0]);
			joindata.setCreatedTime(x[1].toString());
			joindata.setDay((String) x[2]);
			joindata.setFilename((String) x[3]);
			joindata.setFinishHour((String) x[4]);
			joindata.setFinishHourActual((String) x[5]);
			joindata.setFormId((String) x[6]);
			joindata.setInboxStatus((String) x[7]);
			joindata.setOtDate((Date) x[8]);
			joindata.setOtDateActual((Date) x[9]);
			joindata.setReason((String) x[10]);
			joindata.setSalary((BigDecimal) x[11]);
			joindata.setSentTo((String) x[12]);
			joindata.setStartHour((String) x[13]);
			joindata.setStartHourActual((String) x[14]);
			joindata.setTotalHour((String) x[15]);
			joindata.setUpdatedTime(x[16].toString());
			joindata.setStructId((Integer) x[17]);
			joindata.setCheckDelete((Integer) x[18]);
			joindata.setName((String) x[21]);
			joindata.setPosition((String) x[22]);
			joindata.setProject((String) x[23]);
			joindata.setSignature((String) x[24]);
			joindata.setStaffId((String) x[25]);
			joindata.setTeam((String) x[26]);
			System.out.println("++++++++++++++++" + joindata.getSignature());

			for (int i = 0; i < x.length; i++) {
				System.out.println("$$$  " + i + " $$$    " + x[i]);
			}

			alldata1.add(joindata);

		}
		model.addAttribute("AllData", alldata1);
//	model.addAttribute("currentPage", page);

		System.out.println(alldata1);
		return new ModelAndView("OTL002", "AllDataBean", new JoinDTO());
	}

	@PostMapping("/otlistsearch")
	public String myOTSearch(@ModelAttribute("AllDataBean") @Validated JoinDTO bean, BindingResult result,HttpSession session,
			RedirectAttributes redirectAtt, ModelMap model, @RequestParam(defaultValue = "0") int page) {

		if (session.getAttribute("sessionUser") == null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}

//for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(login.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);

		if (bean.getName().equals("")) {
			return "redirect:/myOtList";
		}

		Pageable pageable = PageRequest.of(page, 9999);
		List<JoinDTO> alldata = new ArrayList<>();
		List<Object> teamList = otRepo.findByNameMyOTList(bean.getName(), login.getStaffId().getStaffId(), pageable);

		if (teamList.isEmpty()) {
			model.addAttribute("message", "Search name ' " + bean.getName() + " ' not Found.");
			model.addAttribute("AllData", alldata);
			return "IBX001";
		} else {
			for (Object ot : teamList) {
				Object[] x = (Object[]) ot;
				JoinDTO joindata = new JoinDTO();

				joindata.setStructId((Integer) x[0]);
				joindata.setCheckDelete((Integer) x[1]);
				joindata.setName((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setProject((String) x[4]);
				joindata.setSignature((String) x[5]);
				joindata.setStaffId((String) x[6]);
				joindata.setTeam((String) x[7]);
				joindata.setOtId((int) x[8]);
				joindata.setCreatedTime(x[9].toString());
				joindata.setDay((String) x[10]);
				joindata.setFilename((String) x[11]);
				joindata.setFinishHour((String) x[12]);
				joindata.setFinishHourActual((String) x[13]);
				joindata.setFormId((String) x[14]);
				joindata.setInboxStatus((String) x[15]);
				joindata.setOtDate((Date) x[16]);
				joindata.setOtDateActual((Date) x[17]);
				joindata.setReason((String) x[18]);
				joindata.setSalary((BigDecimal) x[19]);
				joindata.setSentTo((String) x[20]);
				joindata.setStartHour((String) x[21]);
				joindata.setStartHourActual((String) x[22]);
				joindata.setTotalHour((String) x[23]);

				System.out.println(x.length);

				joindata.setFilename((String) x[3]);
				// joindata.setUpdatedTime((String) x[16]);

				System.out.println(joindata);

				alldata.add(joindata);
				System.out.println("======================================");
				System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
						+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + "****  " + x[10]
						+ "---  " + x[11] + "---" + x[12] + "---  " + x[13] + "---  " + x[14] + "---  " + x[15]
						+ "---  " + x[16] + "--- " + x[17] + "---" + x[18] + "---  " + x[19] + "****  " + x[20]
						+ ">>>  " + x[21] + ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24] + "*****" + x[25]
						+ ">>>  " + x[26]);
			}
			model.addAttribute("AllData", alldata);
			model.addAttribute("message", "You search by ' " + bean.getName() + " '.");
			return "OTL001";
		}

	}

	@GetMapping(value = "/membermyotpreview")
	public ModelAndView MemberMyOTpreview(@RequestParam("id") String formId, ModelMap model) {
		System.out.println("Mapping Run........");
		List<Object> sign = otRepo.forAllSignatureApproved(formId);
		System.out.println(sign.size());
		// List<JoinDTO> alldata1 = new ArrayList<>();

		List<JoinDTO> pm = new ArrayList<>();
		List<JoinDTO> dep = new ArrayList<>();
		List<JoinDTO> div = new ArrayList<>();
		List<JoinDTO> hr = new ArrayList<>();

		for (Object ot : sign) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();

			if (x[3].toString().equals("Project Manager")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				pm.add(joindata);
			} else if (x[3].toString().equals("Dept Head")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				dep.add(joindata);
			} else if (x[3].toString().equals("Division Head")) {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				div.add(joindata);
			} else {
				joindata.setName((String) x[0]);
				joindata.setSignature((String) x[1]);
				joindata.setStatus((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setUpdatedTime(x[4].toString());
				hr.add(joindata);
			}

		}

		model.addAttribute("PM", pm);
		model.addAttribute("Dep", dep);
		model.addAttribute("Div", div);
		model.addAttribute("HR", hr);

//		for (Object ot : sign) {
//			Object[] x = (Object[]) ot;
//			JoinDTO joindata = new JoinDTO();
//			
//			joindata.setName((String) x[0]);
//			joindata.setSignature((String) x[1]);
//			joindata.setStatus((String) x[2]);
//			joindata.setPosition((String) x[3]);
//			joindata.setUpdatedTime(x[4].toString());
//			alldata.add(joindata);
//			
//			for (int i = 0; i < x.length; i++) {
//				System.out.println("$$$  " + i + " $$$" + x[i]);
//			}
//
//		}
//			model.addAttribute("Sign", alldata);
//			
//		
//		System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + alldata);

		List<Object> list1 = otRepo.findAllData(formId);
		List<JoinDTO> alldata1 = new ArrayList<>();

		for (Object ot : list1) {
			Object[] x = (Object[]) ot;
			JoinDTO joindata = new JoinDTO();

			joindata.setOtId((int) x[0]);
			joindata.setCreatedTime(x[1].toString());
			joindata.setDay((String) x[2]);
			joindata.setFilename((String) x[3]);
			joindata.setFinishHour((String) x[4]);
			joindata.setFinishHourActual((String) x[5]);
			joindata.setFormId((String) x[6]);
			joindata.setInboxStatus((String) x[7]);
			joindata.setOtDate((Date) x[8]);
			joindata.setOtDateActual((Date) x[9]);
			joindata.setReason((String) x[10]);
			joindata.setSalary((BigDecimal) x[11]);
			joindata.setSentTo((String) x[12]);
			joindata.setStartHour((String) x[13]);
			joindata.setStartHourActual((String) x[14]);
			joindata.setTotalHour((String) x[15]);
			joindata.setUpdatedTime(x[16].toString());
			joindata.setStructId((Integer) x[17]);
			joindata.setCheckDelete((Integer) x[18]);
			joindata.setName((String) x[21]);
			joindata.setPosition((String) x[22]);
			joindata.setProject((String) x[23]);
			joindata.setSignature((String) x[24]);
			joindata.setStaffId((String) x[25]);
			joindata.setTeam((String) x[26]);
			System.out.println("++++++++++++++++" + joindata.getSignature());

			for (int i = 0; i < x.length; i++) {
				System.out.println("$$$  " + i + " $$$    " + x[i]);
			}

			alldata1.add(joindata);

		}
		model.addAttribute("AllData", alldata1);
//	model.addAttribute("currentPage", page);

		System.out.println(alldata1);
		return new ModelAndView("OTL005", "AllDataBean", new JoinDTO());
	}

	@PostMapping("/memberotlistsearch")
	public String MembermyOTSearch(@ModelAttribute("AllDataBean") @Validated JoinDTO bean, HttpSession session,
			BindingResult result, RedirectAttributes redirectAtt, ModelMap model,
			@RequestParam(defaultValue = "0") int page) {

		if (session.getAttribute("sessionUser") == null) {
			redirectAtt.addFlashAttribute("error", "! ! !  Please Login first ! ! !");
			return "redirect:/login";
		}

//		for user profile
		TeamStructure staffData = teamExcelService.selectStaffId(loginController.getStaffId().getStaffId());
		List<String> project = teamExcelService.selectAllProject(staffData.getStaffId());

		model.addAttribute("project", project);
		model.addAttribute("staff", staffData);

		if (bean.getName().equals("")) {
			return "redirect:/myotlist";
		}

		Pageable pageable = PageRequest.of(page, 9999);
		List<JoinDTO> alldata = new ArrayList<>();
		List<Object> teamList = otRepo.findByNameMyOTList(bean.getName(), login.getStaffId().getStaffId(), pageable);

		if (teamList.isEmpty()) {
			model.addAttribute("message", "Search name ' " + bean.getName() + " ' not Found.");
			model.addAttribute("AllData", alldata);
			return "OTL004";
		} else {
			for (Object ot : teamList) {
				Object[] x = (Object[]) ot;
				JoinDTO joindata = new JoinDTO();

				joindata.setStructId((Integer) x[0]);
				joindata.setCheckDelete((Integer) x[1]);
				joindata.setName((String) x[2]);
				joindata.setPosition((String) x[3]);
				joindata.setProject((String) x[4]);
				joindata.setSignature((String) x[5]);
				joindata.setStaffId((String) x[6]);
				joindata.setTeam((String) x[7]);
				joindata.setOtId((int) x[8]);
				joindata.setCreatedTime(x[9].toString());
				joindata.setDay((String) x[10]);
				joindata.setFilename((String) x[11]);
				joindata.setFinishHour((String) x[12]);
				joindata.setFinishHourActual((String) x[13]);
				joindata.setFormId((String) x[14]);
				joindata.setInboxStatus((String) x[15]);
				joindata.setOtDate((Date) x[16]);
				joindata.setOtDateActual((Date) x[17]);
				joindata.setReason((String) x[18]);
				joindata.setSalary((BigDecimal) x[19]);
				joindata.setSentTo((String) x[20]);
				joindata.setStartHour((String) x[21]);
				joindata.setStartHourActual((String) x[22]);
				joindata.setTotalHour((String) x[23]);

				System.out.println(x.length);

				joindata.setFilename((String) x[3]);
				// joindata.setUpdatedTime((String) x[16]);

				System.out.println(joindata);

				alldata.add(joindata);
				System.out.println("======================================");
				System.out.println(x[0] + ">>>   " + x[1] + ">>>  " + x[2] + ">>>  " + x[3] + ">>>  " + x[4] + ">>>  "
						+ x[5] + ">>>  " + x[6] + ">>>  " + x[7] + ">>>  " + x[8] + ">>>  " + x[9] + "****  " + x[10]
						+ "---  " + x[11] + "---" + x[12] + "---  " + x[13] + "---  " + x[14] + "---  " + x[15]
						+ "---  " + x[16] + "--- " + x[17] + "---" + x[18] + "---  " + x[19] + "****  " + x[20]
						+ ">>>  " + x[21] + ">>>  " + x[22] + ">>>  " + x[23] + ">>>  " + x[24] + "*****" + x[25]
						+ ">>>  " + x[26]);
			}
			model.addAttribute("AllData", alldata);
			model.addAttribute("message", "You search by ' " + bean.getName() + " '.");
			return "OTL004";
		}

	}

}
