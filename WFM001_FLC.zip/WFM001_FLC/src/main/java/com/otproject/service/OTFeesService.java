package com.otproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.otproject.dto.OTFees;
import com.otproject.repository.OTFeesRepository;

@Service
public class OTFeesService {

	@Autowired
	private OTFeesRepository otfeesRepo;

	public void saveOTFees(OTFees dto) {
		otfeesRepo.save(dto);
	}

}
