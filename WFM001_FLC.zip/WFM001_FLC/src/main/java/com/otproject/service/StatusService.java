package com.otproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.otproject.dto.StatusDTO;
import com.otproject.repository.StatusRepository;

@Service
public class StatusService {
	@Autowired
	private StatusRepository statusRepo;	
	
	public void approveApplier(StatusDTO dto) {
		statusRepo.save(dto);
	}
	
	
}
