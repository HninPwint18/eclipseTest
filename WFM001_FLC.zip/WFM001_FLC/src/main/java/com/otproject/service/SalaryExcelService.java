package com.otproject.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.otproject.dto.Position;
import com.otproject.helper.SalaryExcelHelper;
import com.otproject.repository.SalaryRepository;

@Service
public class SalaryExcelService {
	@Autowired
	private SalaryRepository salaryRepo;
	
	public void save(MultipartFile file) {
	    try {
	      List<Position> salaryList = SalaryExcelHelper.excelToSalary(file.getInputStream());
	      salaryRepo.saveAll(salaryList);
	    } catch (IOException e) {
	      throw new RuntimeException("fail to store salary excel data: " + e.getMessage());
	    }
	  }
	  public List<Position> getAllPosition() {
	    return (List<Position>) salaryRepo.findAll();
	  }
	  
	  public List<Position> getByPosition(String name) {
		  return salaryRepo.findByPositionName(name);
	  }
	  
	  public Map<String,String> selectAllPosition(){
			Map<String,String> map = new HashMap<String, String>();
			List<Position> list = (List<Position>) salaryRepo.findAll();
			for(Position poid:list) {
				map.put(poid.getPositionName(), poid.getPositionName());
			}
			return map;
		}
}
