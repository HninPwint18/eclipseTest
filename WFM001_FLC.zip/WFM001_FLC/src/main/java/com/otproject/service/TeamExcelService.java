package com.otproject.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.otproject.dto.TeamStructure;
import com.otproject.helper.ExcelHelper;
import com.otproject.repository.TeamStructureRepository;

@Service
public class TeamExcelService {
	@Autowired
	private TeamStructureRepository teamRepo;

	public void save(MultipartFile file) {
		try {
			List<TeamStructure> teamList = ExcelHelper.excelToTutorials(file.getInputStream());
			teamRepo.saveAll(teamList);
		} catch (IOException e) {
			throw new RuntimeException("fail to store excel data: " + e.getMessage());
		}
	}

	public Map<String, String> selectAllProjectId() {
		Map<String, String> map = new HashMap<String, String>();
		List<TeamStructure> list = (List<TeamStructure>) teamRepo.findAll();
		for (TeamStructure pid : list) {
			map.put(pid.getProject(), pid.getProject());
		}

		return map;
	}

	public Map<String, String> selectAllTeam() {
		Map<String, String> map = new HashMap<String, String>();
		List<TeamStructure> list = (List<TeamStructure>) teamRepo.findAll();
		for (TeamStructure tid : list) {
			map.put(tid.getTeam(), tid.getTeam());
		}
		return map;
	}

	public void updateTeam(TeamStructure dto, Integer id) {
		teamRepo.save(dto);
	}

	public void saveEmployeeData(TeamStructure team) {
		teamRepo.save(team);
	}

	public TeamStructure selectEmpId(String empId) {
		return teamRepo.findByStaffId(empId);
	}

	// For login
	public TeamStructure selectStaffId(String empId) {
		return teamRepo.findStaffIdByStaffId(empId);
	}

	public Map<Integer, String> selectAllProjectIdForOt(String staffId) {
		Map<Integer, String> map = new HashMap<Integer, String>();
		List<TeamStructure> list = (List<TeamStructure>) teamRepo.findByStaffIdOt(staffId);
		for (TeamStructure pid : list) {
			map.put(pid.getStructId(), pid.getProject());
		}

		return map;
	}

	public List<TeamStructure> selectForSentToProjectId(String staffId) {
		List<TeamStructure> list = teamRepo.findByStaffIdOt(staffId);
		return list;
	}

	public List<TeamStructure> selectForSentToCheckName(String project, String staffId) {
		List<TeamStructure> list = teamRepo.findBySentToName(project, staffId);
		return list;
	}

	// for signature

	public TeamStructure saveSignature(TeamStructure team, Integer id) {
		return teamRepo.save(team);
	}

	public List<TeamStructure> selectForSignature(String staffId) {
		return teamRepo.findByStaffIdSignature(staffId);
	}

	// for project list
	public List<String> selectAllProject(String empId) {
		List<String> list = teamRepo.findProjectByStaffId(empId);
		return list;
	}

	// for Staff Id list for project ot form
//	public List<String> selectAllStaffId(String project) {
//		List<String> list = teamRepo.findStaffByProject(project);
//		return list;
//	}

	// for Staff Id list for project ot form with teamStructure type
	public List<TeamStructure> retrieveAllStaffId(String project) {
		List<TeamStructure> list = teamRepo.findAllStaffByProject(project);
		return list;
	}

//		retrieve team strucure by staff name
	public List<TeamStructure> findByStaffName(String name, String projectId) {
		return teamRepo.findByStaffName(name, projectId);
	}

	// for signature upload
	public Integer selectStructId(String empId) {
		Integer list = teamRepo.findStructId(empId);
		return list;
	}

	// for sent to position
	public String selectPosition(String senttoname) {
		String list = teamRepo.findPosition(senttoname);
		return list;
	}

	// for jasper

	public TeamStructure jasperParameter(String project, String staffId) {
		TeamStructure team = teamRepo.findByJasper(project, staffId);
		return team;
	}

	public TeamStructure jasperParameterHR(String staffId) {
		TeamStructure team = teamRepo.findByJasperHR(staffId);
		return team;
	}

}
