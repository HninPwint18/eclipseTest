package com.otproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.otproject.dto.OtFormDTO;
import com.otproject.repository.OtFormRepository;

@Service
public class OtFormService {
	@Autowired
	private OtFormRepository otFormRepo;
	
	public OtFormDTO checkFormId() {
		return otFormRepo.selectLastId();
	}
	
	public void saveOtForm(OtFormDTO dto) {
		otFormRepo.save(dto);
	}
	
	public List<OtFormDTO> saveFiles(Integer structId){
		List<OtFormDTO> list = otFormRepo.findBySavedFile(structId);
		return list;
	}
	
	public OtFormDTO selectFile(String filename) {
		OtFormDTO saveFile = otFormRepo.findBySaveFileName(filename);
		return saveFile;
	}
	
	public List<OtFormDTO> selectFileForOT(String filename) {
		List<OtFormDTO> saveFile = otFormRepo.findBySaveFileNameOT(filename);
		return saveFile;
	}
	
	
	
	public void updateOtForm(OtFormDTO dto,Integer id) {
		otFormRepo.save(dto);
	}
	
	// all Project names
		public String[] getProjectsForCount() {
			String result[] = otFormRepo.getProjectforCount();
			return result;
		}
		
		// ot count of project
		public  int getCountOfProject(String s) {
			int result =otFormRepo.getCountOfProject(s);
			return result ;
		}
		
		// ot count of project with date
		public  int getCountOfProjectWithDate(String s , String sd , String ed) {
			int result =otFormRepo.getCountOfProjectWithDate(s,sd,ed);
			return result ;
		}
		
		// ot cost of project
		public double [] getCostOfProject(String pj) {
		double result []= otFormRepo.getCostOfProject(pj);
		return result;
		}
		
//		ot cost of project with date
		public double[] getCostOfProjectWithDate(String pj, String sd, String ed) {
			double result[] = otFormRepo.getCostOfProjectWithDate(pj,sd,ed);
			return result;
		}
		public OtFormDTO updateSendTo(Integer id) {
			return otFormRepo.findByOtId(id);
			
		}
		
		// jasper
		public List<Object> jasperData(String formId) {
			List<Object> jasper = otFormRepo.findDataForJasper(formId);
			return jasper;
		}
		
		// revised
		public OtFormDTO revisedForm(String formId) {
			OtFormDTO revise = otFormRepo.findByReviseFile(formId);
			return revise;
		}

}
