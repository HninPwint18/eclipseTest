package com.otproject.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.otproject.dto.JasperDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.OtFormRepository;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
public class ReportService {

	@Autowired
	TeamExcelService teamService;
	
	@Autowired
	private OtFormRepository otFormRepo;
	
	@Autowired 
	OtFormService otService;
	
	public ResponseEntity<byte[]> generateOtFormPdf(String formId) throws FileNotFoundException, JRException {

		// create collection:List
		List<Object> jasper = otFormRepo.findDataForJasper(formId); 

		
		// Parameters for report
	 	// Adding the additional parameters to the pdf.
	 	Map<String,Object> parameters = new HashMap<String,Object>();
		parameters.put("ReportTitle", "TeamStructure List");
		parameters.put("formId", formId);
	 	
	 	List<JasperDTO> jasperDtoList = new ArrayList<JasperDTO>();
	 	
	 	for(Object jdata:jasper) {
			JasperDTO dto = new JasperDTO();
			Object[] name=(Object[]) jdata;
			dto.setDay((String) name[0]);
			dto.setFinishHour((String) name[1]);
			dto.setFinishHourActual((String) name[2]);
			dto.setFormId((String) name[3]);
			dto.setOtDate((Date) name[4]);
			dto.setOtDateActual((Date) name[5]);
			dto.setReason((String) name[6]);
			dto.setSalary((BigDecimal) name[20]);
			dto.setStartHour((String) name[8]);
			dto.setStartHourActual((String) name[9]);
			dto.setTotalHour((String) name[10]);
			dto.setName((String) name[11]);
			dto.setPosition((String) name[12]);
			dto.setProject((String) name[13]);
			dto.setSignature((String) name[14]);
			dto.setStaffId((String) name[15]);
			dto.setApprovedBy((String) name[17]);
			
			String jrName = (String) name[11];
			if(jrName==null) jrName="...............";
			parameters.put("name", jrName);
			String jrDate = name[5].toString();
			if(jrDate==null) jrDate="...............";
			parameters.put("date", jrDate);
			String jrSignature = (String) name[14];
//			if(jrSignature==null) jrSignature="...............";
			parameters.put("signature", "staff-signature/"+name[19].toString()+"/"+jrSignature);
			parameters.put("status", "Requested");
			
			System.out.println("project Id"+(String)name[13]);
			TeamStructure team =teamService.jasperParameter((String)name[13], (String)name[17]);
			
			String jname = team.getName();
//			String jname= "Kyaw";
			if(jname==null) jname="...............";
			parameters.put(team.getPosition()+" name", jname);
			String jsignature = team.getSignature();
//			if(jsignature==null) jsignature="...............";
			parameters.put(team.getPosition()+" signature","staff-signature/"+team.getStructId().toString()+"/"+ jsignature);
			
			String jdate = name[18].toString();
			if(jdate==null) jdate="...............";
			parameters.put(team.getPosition()+" date", jdate);
			String jstatus = (String) name[16];
			if(jstatus==null) jstatus="...............";
			parameters.put(team.getPosition()+" status",jstatus);
			
			TeamStructure hr = teamService.jasperParameterHR((String)name[17]);
			
			if(hr!=null) {
				String hrdate = name[18].toString();
				if(hrdate==null) hrdate="...............";
				parameters.put(hr.getTeam()+" date", hrdate);
				System.out.println("hr team"+hr.getTeam());
				System.out.println("hr date"+hrdate);
				String hrstatus = (String) name[16];
				if(hrstatus==null) hrstatus="...............";
				parameters.put(hr.getTeam()+" status",hrstatus);
				
				System.out.println("hr status"+hrstatus);
			}else {
				parameters.put("HR date", "...............");
	        	parameters.put("HR status", "...............");
			}
			
			
			parameters.put("projectId",name[13]);
			
			jasperDtoList.add(dto);
		}
		
	 	Iterator<Map.Entry<String, Object>> itr = parameters.entrySet().iterator();
        int pm =0;
        int dept=0;
        int div=0;
        while(itr.hasNext())
        {
             Map.Entry<String, Object> entry = itr.next();
             System.out.println("Key = " + entry.getKey() + 
                                 ", Value = " + entry.getValue());
             if(entry.getKey().equals("Project Manager name")) {
            	 pm++;
             }else if(entry.getKey().equals("Division Head name")) {
            	 div++;
             }else if(entry.getKey().equals("Dept Head name")) {
            	 dept++;
             }
        }
        
        
        if(pm==0) {
			parameters.put("Project Manager name", "...............");
			parameters.put("Project Manager date", "...............");
			parameters.put("Project Manager status","...............");
        }else if(dept==0) {
        	parameters.put("Dept Head name", "...............");
			parameters.put("Dept Head date", "...............");
			parameters.put("Dept Head status","...............");
        }else if(div==0) {
        	parameters.put("Division Head name", "...............");
			parameters.put("Division Head date", "...............");
			parameters.put("Division Head status","...............");
        }
		
		// load the file
		File file = ResourceUtils.getFile("classpath:Test2.jrxml");

		// complie jrxml template file
		JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());

		// create datasource
		JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(jasperDtoList);

		// fill the compiled report to be converted into JasperPrint:Object
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);

		byte[] data = JasperExportManager.exportReportToPdf(jasperPrint);

		HttpHeaders headers = new HttpHeaders();
		headers.set(HttpHeaders.CONTENT_DISPOSITION, "inline;filename=OtFormReport.pdf");
		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF).body(data);
	}
	
}
