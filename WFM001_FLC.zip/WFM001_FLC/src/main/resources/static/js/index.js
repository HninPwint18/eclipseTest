// Scroll Effect

$(document).ready(function () {
    $("a.smooth-scroll").click(function (event) {
      event.preventDefault(); // close button event default
      var select_id = $(this).attr("href");
      $("html,body").animate(
        {
          scrollTop: $(select_id).offset().top - 64,
        },
        1300,
        "easeInOutExpo"
      );
    });
  });

// pre loader
$(window).on("load", function () {
  $("#status").fadeOut(2000);
  $("#preloader").delay(1100).fadeOut(1100);
});

$(window).on("load", function () {
  $("#status2").fadeOut(1000);
  $("#preloader2").delay(100).fadeOut(300);
});


// modal 
			 
// Team Member Modal
$(document).ready(function() {
	$("a.edit").click(function(event) {
		event.preventDefault();
		
		var href= $(this).attr('href');
		$.get(href,function(team,status){
			$('.myForm #structId').val(team.structId);
			$('.myForm #name').val(team.name);
			$('.myForm #staffId').val(team.staffId);
			$('.myForm #project').val(team.project);
			$('.myForm #team').val(team.team);
			$('.myForm #position').val(team.position);
			$('.myForm #checkDelete').val(0);
		})
		
		
		jQuery.noConflict();	// its happened with jquery version(using multiple version) conflicts.
		$('#updateform').modal();

	});
	
	$("a.delete").click(function(event){
		event.preventDefault();
		var href= $(this).attr('href');
		
		$.get(href,function(team,status){
			$('#deleteform #structId').val(team.structId);
			$('#deleteform #name').val(team.name);
			$('#deleteform #staffId').val(team.staffId);
			$('#deleteform #project').val(team.project);
			$('#deleteform #team').val(team.team);
			$('#deleteform #position').val(team.position);
			$('#deleteform #checkDelete').val(1);
		})
		
		//$('#deleteform #delModal').attr('href',href);
		
		jQuery.noConflict();
		$('#deleteform').modal();
	});
});


// Management Modal

$(document).ready(function() {
	$("a.editManage").click(function(event) {
		event.preventDefault();
		
		var href= $(this).attr('href');
		$.get(href,function(manage,status){
			$('.myFormManage #structId').val(manage.structId);
			$('.myFormManage #name').val(manage.name);
			$('.myFormManage #staffId').val(manage.staffId);
			$('.myFormManage #project').val(manage.project);
			$('.myFormManage #team').val(manage.team);
			$('.myFormManage #position').val(manage.position);
			$('.myFormManage #checkDelete').val(0);
		})
		
		
		jQuery.noConflict();	// its happened with jquery version(using multiple version) conflicts.
		$('#updateformManage').modal();

	});
	
	$("a.deleteManage").click(function(event){
		event.preventDefault();
		var href= $(this).attr('href');
		
		$.get(href,function(manage,status){
			$('#deleteformManage #structId').val(manage.structId);
			$('#deleteformManage #name').val(manage.name);
			$('#deleteformManage #staffId').val(manage.staffId);
			$('#deleteformManage #project').val(manage.project);
			$('#deleteformManage #team').val(manage.team);
			$('#deleteformManage #position').val(manage.position);
			$('#deleteformManage #checkDelete').val(1);
		})
		
		//$('#deleteformManage #delModal').attr('href',href);
		
		jQuery.noConflict();
		$('#deleteformManage').modal();
	});
});