package com.otproject.test.controllerTest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.otproject.repository.TeamStructureRepository;
import com.otproject.service.TeamExcelService;

@SpringBootTest
@AutoConfigureMockMvc
public class TestUPL001Controller {
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	TeamExcelService teamExcelService;
	
	@MockBean
	TeamStructureRepository teamRepo;
	
	@Test
	public void systemAdminUploadData() throws Exception{
		this.mockMvc.perform(get("/uploadData"))
		.andExpect(status().isOk())
		.andExpect(view().name("UPL001"));
	}
	
	
}
