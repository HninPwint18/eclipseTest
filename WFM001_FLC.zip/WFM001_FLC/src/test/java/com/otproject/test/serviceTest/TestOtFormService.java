package com.otproject.test.serviceTest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.otproject.dto.OtFormDTO;
import com.otproject.repository.OtFormRepository;
import com.otproject.service.OtFormService;

@SpringBootTest
public class TestOtFormService {
	@Mock
	private OtFormRepository otFormRepo;
	
	@InjectMocks
	private OtFormService otFormService;
	
	@Test
	public void checkFormIdTest() {
		OtFormDTO dto = new OtFormDTO();
		dto.setId(1);
		dto.setDay("weekday");
		dto.setFilename("myfile");
		dto.setFormId("DAT_0001");
		
		when(otFormRepo.selectLastId()).thenReturn(dto);
		OtFormDTO form = otFormService.checkFormId();
		assertEquals("weekday",form.getDay());
		assertEquals("myfile", form.getFilename());
		assertEquals("DAT_0001", form.getFormId());
	}
	
	@Test
	public void saveOtFormTest() {
		OtFormDTO dto = new OtFormDTO();
		dto.setId(1);
		dto.setDay("weekday");
		dto.setFilename("myfile");
		dto.setFormId("DAT_0001");
		
		otFormService.saveOtForm(dto);
		verify(otFormRepo,times(1)).save(dto);
	}
	
	@Test
	public void saveFilesTest() {
		List<OtFormDTO> list = new ArrayList<OtFormDTO>();
		OtFormDTO dto = new OtFormDTO();
		dto.setId(1);
		dto.setDay("weekday");
		dto.setFilename("myfile");
		dto.setFormId("DAT_0001");
		
		OtFormDTO dto2 = new OtFormDTO();
		dto2.setId(1);
		dto2.setDay("weekday");
		dto2.setFilename("myfile");
		dto2.setFormId("DAT_0001");
		
		list.add(dto);
		list.add(dto2);
		
		when(otFormRepo.findBySavedFile(1)).thenReturn(list);
		List<OtFormDTO> formList = otFormService.saveFiles(1);
		assertEquals(2, formList.size());
		assertEquals("weekday", formList.get(1).getDay());
	}
	
	@Test
	public void selectFileTest() {
		OtFormDTO dto = new OtFormDTO();
		dto.setId(1);
		dto.setDay("weekday");
		dto.setFilename("myfile");
		dto.setFormId("DAT_0001");
		
		when(otFormRepo.findBySaveFileName("myfile")).thenReturn(dto);
		OtFormDTO form = otFormService.selectFile("myfile");
		assertEquals("weekday",form.getDay());
		assertEquals("myfile", form.getFilename());
		assertEquals("DAT_0001", form.getFormId());
	}
	
	@Test
	public void updateOtFormTest() {
		OtFormDTO dto = new OtFormDTO();
		dto.setId(1);
		dto.setDay("weekday");
		dto.setFilename("myfile");
		dto.setFormId("DAT_0001");
		
		otFormService.updateOtForm(dto, 1);
		verify(otFormRepo,times(1)).save(dto);
	}
	
}
