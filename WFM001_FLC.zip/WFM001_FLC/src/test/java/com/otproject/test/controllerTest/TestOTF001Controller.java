package com.otproject.test.controllerTest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.otproject.dto.OtFormDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.OtFormRepository;
import com.otproject.service.OtFormService;

@SpringBootTest
@AutoConfigureMockMvc
public class TestOTF001Controller {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	OtFormRepository otFormRepo;
	
	@MockBean
	OtFormService otFormService;
	
	@Test
	public void otFormUploadPageTest() throws Exception{
		this.mockMvc.perform(get("/otForm"))
		.andExpect(status().isOk())
		.andExpect(view().name("OTF001"))
		.andExpect(model().attributeExists("otFormBean"));
	}
	
//	@Test
//	public void uploadFormTest() throws Exception{
//		TeamStructure t = new TeamStructure();
//		t.setName("kyaw");
//		
//		OtFormBean dto = new OtFormBean();
//		dto.setFormId("DAT_002");
//		dto.setOtDate(Date.valueOf(LocalDate.now()));
//		dto.setStartHour("20:00");
//		dto.setFinishHour("21:00");
//		dto.setTotalHour("4");
//		dto.setDay("weekday");
//		dto.setReason("reason");
//		dto.setInboxStatus("requested");
//		dto.setOtTeam(Set.of(t));
//		dto.setSentTo("kyaw");
//		dto.setFilename("myfile");
//		dto.setOtDateActual(Date.valueOf(LocalDate.now()));
//		dto.setStartHourActual("15:00");
//		dto.setFinishHourActual("18:00");
//		
//		this.mockMvc.perform(post("/uploadForm").flashAttr("otBean", dto))
//		.andExpect(status().isOk())
//		.andExpect(view().name("OTF001"));
//	}
	
	@Test
	public void saveFileTest() throws Exception{
		
		TeamStructure t = new TeamStructure();
		t.setName("kyaw");
		
		OtFormDTO dto = new OtFormDTO();
		dto.setFormId("DAT_002");
		dto.setOtDate(Date.valueOf(LocalDate.now()));
		dto.setStartHour("20:00");
		dto.setFinishHour("21:00");
		dto.setTotalHour("4");
		dto.setDay("weekday");
		dto.setReason("reason");
		dto.setInboxStatus("requested");
		dto.setOtTeam(Set.of(t));
		dto.setSentTo("kyaw");
		dto.setFilename("None");
		dto.setOtDateActual(Date.valueOf(LocalDate.now()));
		dto.setStartHourActual("15:00");
		dto.setFinishHourActual("18:00");
		this.mockMvc.perform(post("/saveFileSetup").flashAttr("bean", dto))
		.andExpect(status().isOk())
		.andExpect(view().name("OTF001-01"));
	}
	
	@Test
	public void updateSaveFile() throws Exception{
		
		TeamStructure t = new TeamStructure();
		t.setName("kyaw");
		
		OtFormDTO dto = new OtFormDTO();
		dto.setFormId("DAT_002");
		dto.setOtDate(Date.valueOf(LocalDate.now()));
		dto.setStartHour("20:00");
		dto.setFinishHour("21:00");
		dto.setTotalHour("4");
		dto.setDay("weekday");
		dto.setReason("reason");
		dto.setInboxStatus("requested");
		dto.setOtTeam(Set.of(t));
		dto.setSentTo("kyaw");
		dto.setFilename("None");
		dto.setOtDateActual(Date.valueOf(LocalDate.now()));
		dto.setStartHourActual("15:00");
		dto.setFinishHourActual("18:00");
		
		this.mockMvc.perform(post("/updateSaveFile").flashAttr("otBean", dto))
		.andExpect(status().is(302))
		.andExpect(redirectedUrl("/otForm"));
	}
}
