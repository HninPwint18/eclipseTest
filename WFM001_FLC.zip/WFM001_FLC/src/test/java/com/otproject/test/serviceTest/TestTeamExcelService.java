package com.otproject.test.serviceTest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.otproject.dto.OtFormDTO;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.TeamStructureRepository;
import com.otproject.service.TeamExcelService;

@SpringBootTest
public class TestTeamExcelService {
	@Mock
	private TeamStructureRepository teamStructureRepo;
	
	@InjectMocks
	private TeamExcelService teamExcelService;
	
	@Test
	public void selectAllProjectIdTest() {
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		when(teamStructureRepo.findAll()).thenReturn(Arrays.asList(dto));
		Map<String,String> teamMap = teamExcelService.selectAllProjectId();
		assertEquals(1,teamMap.size());
		verify(teamStructureRepo, times(1)).findAll();
	}
	
	@Test
	public void selectAllTeamTest() {
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		when(teamStructureRepo.findAll()).thenReturn(Arrays.asList(dto));
		Map<String,String> teamMap = teamExcelService.selectAllTeam();
		assertEquals(1,teamMap.size());
		verify(teamStructureRepo, times(1)).findAll();
	}
	
	@Test
	public void updateTeamTest() {
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		teamExcelService.updateTeam(dto, 1);
		verify(teamStructureRepo,times(1)).save(dto);
	}
	
	@Test
	public void saveEmployeeDataTest() {
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		teamExcelService.saveEmployeeData(dto);
		verify(teamStructureRepo,times(1)).save(dto);
	}
	
	@Test
	public void selectEmpIdTest() {
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		when(teamStructureRepo.findByStaffId("25-001")).thenReturn(dto);
		TeamStructure team = teamExcelService.selectEmpId("25-001");
		assertEquals("Kyaw",team.getName());
		assertEquals("programmer", team.getPosition());
		assertEquals("DAT_01", team.getProject());
		assertEquals("signature", team.getSignature());
	}
	
	@Test
	public void selectAllProjectIdForOtTest() {
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		when(teamStructureRepo.findByStaffIdOt("25-001")).thenReturn(Arrays.asList(dto));
		Map<Integer,String> teamMap = teamExcelService.selectAllProjectIdForOt("25-001");
		assertEquals(1,teamMap.size());
		verify(teamStructureRepo, times(1)).findByStaffIdOt("25-001");
	}
	
	@Test
	public void selectForSentToProjectIdTest() {
		List<TeamStructure> list = new ArrayList<TeamStructure>();
		
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		OtFormDTO dto3 = new OtFormDTO();
		dto3.setFilename("myfile");
		Set<OtFormDTO> form2 = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto2 = new TeamStructure();
		dto2.setCheckDelete(0);
		dto2.setName("Kyaw");
		dto2.setPosition("programmer");
		dto2.setProject("DAT_01");
		dto2.setSignature("signature");
		dto2.setStaffId("25-001");
		dto2.setStructId(1);
		dto2.setTeam("System");
		dto2.setOtTeam(form2);
		
		list.add(dto);
		list.add(dto2);
		
		when(teamStructureRepo.findByStaffIdOt("25-001")).thenReturn(list);
		List<TeamStructure> teamList = teamExcelService.selectForSentToProjectId("25-001");
		assertEquals(2, teamList.size());
		assertEquals("Kyaw", teamList.get(1).getName());
	}
	
	@Test
	public void selectForSentToCheckNameTest() {
		List<TeamStructure> list = new ArrayList<TeamStructure>();
		
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		OtFormDTO dto3 = new OtFormDTO();
		dto3.setFilename("myfile");
		Set<OtFormDTO> form2 = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto2 = new TeamStructure();
		dto2.setCheckDelete(0);
		dto2.setName("Kyaw");
		dto2.setPosition("programmer");
		dto2.setProject("DAT_01");
		dto2.setSignature("signature");
		dto2.setStaffId("25-001");
		dto2.setStructId(1);
		dto2.setTeam("System");
		dto2.setOtTeam(form2);
		
		list.add(dto);
		list.add(dto2);
		
		when(teamStructureRepo.findBySentToName("DAT_01","25-001")).thenReturn(list);
		List<TeamStructure> teamList = teamExcelService.selectForSentToCheckName("DAT_01","25-001");
		assertEquals(2, teamList.size());
		assertEquals("Kyaw", teamList.get(1).getName());
	}
	
	@Test
	public void saveSignatureTest() {
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		teamExcelService.saveSignature(dto,1);
		verify(teamStructureRepo,times(1)).save(dto);
	}
	
	@Test
	public void selectForSignatureTest() {
		List<TeamStructure> list = new ArrayList<TeamStructure>();
		OtFormDTO dto1 = new OtFormDTO();
		dto1.setFilename("myfile");
		Set<OtFormDTO> form = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto = new TeamStructure();
		dto.setCheckDelete(0);
		dto.setName("Kyaw");
		dto.setPosition("programmer");
		dto.setProject("DAT_01");
		dto.setSignature("signature");
		dto.setStaffId("25-001");
		dto.setStructId(1);
		dto.setTeam("System");
		dto.setOtTeam(form);
		
		OtFormDTO dto3 = new OtFormDTO();
		dto3.setFilename("myfile");
		Set<OtFormDTO> form2 = new HashSet<OtFormDTO>();
		form.add(null);
		TeamStructure dto2 = new TeamStructure();
		dto2.setCheckDelete(0);
		dto2.setName("Kyaw");
		dto2.setPosition("programmer");
		dto2.setProject("DAT_01");
		dto2.setSignature("signature");
		dto2.setStaffId("25-001");
		dto2.setStructId(1);
		dto2.setTeam("System");
		dto2.setOtTeam(form2);
		
		list.add(dto2);
		list.add(dto);
		
		when(teamStructureRepo.findByStaffIdSignature("25-001")).thenReturn(list);
		List<TeamStructure> team = teamExcelService.selectForSignature("25-001");
		assertEquals(2, team.size());
		assertEquals("Kyaw", team.get(1).getName());
	}
}
