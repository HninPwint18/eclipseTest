package com.otproject.test.controllerTest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.otproject.bean.TeamStructureBean;
import com.otproject.dto.TeamStructure;
import com.otproject.repository.TeamStructureRepository;
import com.otproject.service.TeamExcelService;

@SpringBootTest
@AutoConfigureMockMvc
public class TestSTF001Controller {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	TeamExcelService teamService;
	
	@MockBean
	TeamStructureRepository teamRepo;
	
	@Test
	public void deleteTeam() throws Exception{
		TeamStructure dto = new TeamStructure();
		  dto.setStructId(1);
		  dto.setName("kyaw");
		  dto.setStaffId("25-001");
		  dto.setProject("DAT_01");
		  dto.setTeam("System");
		  dto.setPosition("project manager");
		  dto.setCheckDelete(0);
		  
		this.mockMvc.perform(post("/delete").flashAttr("dto", dto))
		.andExpect(status().is(302))
		.andExpect(redirectedUrl("/teamStructure"));
	}
	
	@Test
	public void updateValidateTest() throws Exception{
		this.mockMvc.perform(post("/update"))
		.andExpect(status().is(302))
		.andExpect(redirectedUrl("/teamStructure"));
	}
	
	@Test
	public void updateTest() throws Exception{
		TeamStructureBean bean = new TeamStructureBean();
		bean.setStructId(1);
		bean.setName("kyaw");
		bean.setStaffId("25-001");
		bean.setProject("DAT_01");
		bean.setTeam("System");
		bean.setPosition("project manager");
		bean.setCheckDelete(0);
		this.mockMvc.perform(post("/update").flashAttr("bean", bean))
		.andExpect(status().is(302))
		.andExpect(redirectedUrl("/teamStructure"));
	}
	
	@Test
	public void searchTest() throws Exception{
		  
		this.mockMvc.perform(post("/search"))
		.andExpect(status().is(302))
		.andExpect(redirectedUrl("/teamStructure"));
	}
	
	@Test
	public void search() throws Exception{
		TeamStructureBean bean = new TeamStructureBean();
		bean.setStructId(1);
		bean.setName("kyaw");
		bean.setStaffId("25-001");
		bean.setProject("DAT_01");
		bean.setTeam("System");
		bean.setPosition("project manager");
		bean.setCheckDelete(0);
		this.mockMvc.perform(post("/search").flashAttr("bean", bean))
		.andExpect(status().is(302))
		.andExpect(redirectedUrl("/teamStructure"));
	}
}
