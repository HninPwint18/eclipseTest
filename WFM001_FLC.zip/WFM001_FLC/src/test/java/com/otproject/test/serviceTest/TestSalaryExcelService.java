package com.otproject.test.serviceTest;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.otproject.dto.Position;
import com.otproject.repository.SalaryRepository;
import com.otproject.service.SalaryExcelService;

@SpringBootTest
public class TestSalaryExcelService {
	@Mock
	private SalaryRepository salaryRepository;
	
	@InjectMocks
	private SalaryExcelService salaryExcelService;
	
	@Test
	public void getAllPositionTest() {
		Position dto = new Position();
		dto.setPositionId(1);
		dto.setPositionName("Project Manager");
		dto.setSalary(400000);
		
		when(salaryRepository.findAll()).thenReturn(Arrays.asList(dto));
		List<Position> salaryList = salaryExcelService.getAllPosition();
		assertEquals(1,salaryList.size());
		verify(salaryRepository, times(1)).findAll();
	}
	
	@Test
	public void getByPositionTest() {
		Position dto = new Position();
		dto.setPositionId(1);
		dto.setPositionName("Project Manager");
		dto.setSalary(400000);
		
		when(salaryRepository.findByPositionName("Project Manager")).thenReturn(Arrays.asList(dto));
		List<Position> salaryList = salaryExcelService.getByPosition("Project Manager");
		assertEquals(1,salaryList.size());
		verify(salaryRepository, times(1)).findByPositionName("Project Manager");
	}
	
	@Test
	public void selectAllPositionTest() {
		Position dto = new Position();
		dto.setPositionId(1);
		dto.setPositionName("Project Manager");
		dto.setSalary(400000);
		
		when(salaryRepository.findAll()).thenReturn(Arrays.asList(dto));
		Map<String, String> salaryMap = salaryExcelService.selectAllPosition();
		assertEquals(1,salaryMap.size());
		verify(salaryRepository, times(1)).findAll();
	}
}
