package com.otproject;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wfm001FlcApplicationTests {

	@Test
	void contextLoads() {
	}

}
