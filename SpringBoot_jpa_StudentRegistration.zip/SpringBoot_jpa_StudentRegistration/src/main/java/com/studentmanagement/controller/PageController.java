package com.studentmanagement.controller;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.studentmanagement.dao.UserService;
import com.studentmanagement.dto.UserDTO;
import com.studentmanagement.model.LoginBean;

@Controller
public class PageController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView loginPage() {
		return new ModelAndView("LGN001", "lb", new LoginBean());
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String welcomePage() {
		return "M00001";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String Login(@ModelAttribute("lb") @Validated LoginBean lb, BindingResult bindingResult, ModelMap model,
			HttpSession session, HttpServletRequest request) {

		if (bindingResult.hasErrors()) {
			return "LGN001";
		}

		UserDTO dto = new UserDTO();
		dto.setId(lb.getId());

		Optional<UserDTO> checkUser = userService.getUserById(dto.getId());

		if (checkUser.isPresent()) {
			if (lb.getPassword().equals(checkUser.get().getPassword())) {
				session.setAttribute("sesUser", checkUser.get());
				return "redirect:/welcome";
			} else {
				model.addAttribute("error", "Password is incorrect!");
				return "LGN001";
			}
		} else {
			model.addAttribute("error", "User not found!");
			return "LGN001";
		}

	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		session.invalidate();
		return "redirect:/";
	}

}
