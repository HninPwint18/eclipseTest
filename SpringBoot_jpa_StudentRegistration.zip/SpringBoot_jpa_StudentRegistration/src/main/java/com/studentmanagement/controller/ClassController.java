package com.studentmanagement.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.studentmanagement.dao.ClassService;
import com.studentmanagement.dto.ClassDTO;
import com.studentmanagement.model.StudentClass;

@Controller
public class ClassController {

	@Autowired
	ClassService classService;

	@RequestMapping(value = "/class/add", method = RequestMethod.GET)
	public ModelAndView classAddPage(@ModelAttribute("message") String message, ModelMap model) {
		model.addAttribute("message", message);
		return new ModelAndView("BUD003", "stuClass", new StudentClass());
	}

	@RequestMapping(value = "/class/add", method = RequestMethod.POST)
	public String classAdd(@ModelAttribute("stuClass") @Validated StudentClass stuClass, BindingResult bindingResult,
			ModelMap model, RedirectAttributes ra) {

		if (bindingResult.hasErrors()) {
			return "BUD003";
		}

		ClassDTO dto = new ClassDTO();
		dto.setId(stuClass.getId());
		dto.setName(stuClass.getName());

		Optional<ClassDTO> checkClass = classService.getClassById(dto.getId());

		if (checkClass.isPresent()) {
			model.addAttribute("message", "Class Id has been already exist!");
			return "BUD003";
		} else {
			ClassDTO result = classService.save(dto);

			if (result == null) {
				ra.addAttribute("message", "Add Class fail");
			} else {
				ra.addAttribute("message", "Add Class Success");
			}
			return "redirect:/class/add";
		}

	}

}
