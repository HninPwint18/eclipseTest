package com.studentmanagement.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.studentmanagement.dao.ClassService;
import com.studentmanagement.dao.StudentService;
import com.studentmanagement.dto.ClassDTO;
import com.studentmanagement.dto.StudentDTO;
import com.studentmanagement.model.Student;
import com.studentmanagement.model.StudentSearchBean;

@Controller
public class StudentController {

	@Autowired
	ClassService classService;

	@Autowired
	StudentService studentService;

	@ModelAttribute("classList")
	public List<ClassDTO> classList() {
		List<ClassDTO> clist = classService.getAllClass();
		return clist;
	}

	@RequestMapping(value = "/student/search", method = RequestMethod.GET)
	public ModelAndView studentSearchPage(@ModelAttribute("message") String message, ModelMap model) {
		model.addAttribute("message", message);
		return new ModelAndView("BUD001", "student", new StudentSearchBean());
	}

	@RequestMapping(value = "/student/search", method = RequestMethod.POST)
	public String studentSearch(@ModelAttribute("student") StudentSearchBean student, ModelMap model) {

		StudentDTO dto = new StudentDTO(student.getId(), student.getName(), student.getClassName());

		List<StudentDTO> list = new ArrayList<StudentDTO>();

		if (dto.getStudentId().equals("") && dto.getStudentName().equals("") && dto.getClassName().equals("")) {
			list = studentService.selectAll();
		} else {
			list = studentService.selectOne(dto);
		}

		if (list.size() == 0) {
			model.addAttribute("message", "Student not found!");
		} else {
			model.addAttribute("stulist", list);
		}
		return "BUD001";
	}

	@RequestMapping(value = "/student/add", method = RequestMethod.GET)
	public ModelAndView addStudentPage(@ModelAttribute("message") String message, ModelMap model) {
		model.addAttribute("message", message);
		return new ModelAndView("BUD002", "student", new Student());
	}

	@RequestMapping(value = "/student/add", method = RequestMethod.POST)
	public String addStudent(@ModelAttribute("student") @Validated Student student, BindingResult bindingResult,
			ModelMap model, RedirectAttributes ra) {

		if (student.getYear().equals("Year") || student.getMonth().equals("Month") || student.getDay().equals("Day")) {
			model.addAttribute("message", "Register Date can't be blank!");
			if (bindingResult.hasErrors()) {
				return "BUD002";
			}
		} else {
			if (bindingResult.hasErrors()) {
				return "BUD002";
			}
		}

		StudentDTO dto = new StudentDTO();
		dto.setStudentId(student.getId());
		dto.setStudentName(student.getName());
		dto.setClassName(student.getClassName());
		dto.setRegisterDate(student.getYear() + "-" + student.getMonth() + "-" + student.getDay());
		dto.setStatus(student.getStatus());

		Optional<StudentDTO> checkStu = studentService.getStudentById(dto.getStudentId());

		if (checkStu.isPresent()) {
			model.addAttribute("message", "Student Id has been already exist!");
			return "BUD002";
		} else {
			StudentDTO result = studentService.save(dto);

			if (result == null) {
				ra.addAttribute("message", "Add Student fail");
			} else {
				ra.addAttribute("message", "Add Student Success");

			}
			return "redirect:/student/add";
		}
	}

	@RequestMapping(value = "/student/update", method = RequestMethod.GET)
	public ModelAndView updateStudentPage(ModelMap model, @RequestParam("id") String id) {

		Optional<StudentDTO> dto = studentService.getStudentById(id);

		Student student = new Student();

		student.setId(dto.get().getStudentId());
		student.setName(dto.get().getStudentName());
		student.setClassName(dto.get().getClassName());
		student.setStatus(dto.get().getStatus());
		String[] dt = dto.get().getRegisterDate().split(" ");
		String d = dt[0];
		String[] dateParts = d.split("-");
		student.setYear(dateParts[0]);
		student.setMonth(dateParts[1]);
		student.setDay(dateParts[2]);

		return new ModelAndView("BUD002-01", "student", student);
	}

	@RequestMapping(value = "/student/update", method = RequestMethod.POST)
	public String updateStudent(@ModelAttribute("student") @Validated Student student, BindingResult bindingResult,
			ModelMap model, RedirectAttributes ra) {

		if (student.getYear().equals("Year") || student.getMonth().equals("Month") || student.getDay().equals("Day")) {
			model.addAttribute("message", "Register Date can't be blank!");
			if (bindingResult.hasErrors()) {
				return "BUD002-01";
			}
		} else {
			if (bindingResult.hasErrors()) {
				return "BUD002-01";
			}
		}

		StudentDTO dto = new StudentDTO();
		dto.setStudentId(student.getId());
		dto.setStudentName(student.getName());
		dto.setStatus(student.getStatus());
		dto.setClassName(student.getClassName());
		dto.setRegisterDate(student.getYear() + "-" + student.getMonth() + "-" + student.getDay());

		StudentDTO result = studentService.update(dto, student.getId());
		if (result == null) {
			ra.addAttribute("message", "Update Student Fail");
		} else {
			ra.addAttribute("message", "Update Student Success");
		}
		return "redirect:/student/search";
	}
	
	@RequestMapping(value = "/student/delete", method = RequestMethod.GET)
	public String deleteStudent(ModelMap model, @RequestParam("id") String id, RedirectAttributes ra) {

		studentService.delete(id);

		ra.addAttribute("message", "Student Delete Success!");

		return "redirect:/student/search";
	}

}
