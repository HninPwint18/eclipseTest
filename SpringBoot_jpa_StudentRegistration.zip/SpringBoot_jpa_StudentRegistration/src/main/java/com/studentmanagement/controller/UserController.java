package com.studentmanagement.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.studentmanagement.dao.UserService;
import com.studentmanagement.dto.UserDTO;
import com.studentmanagement.model.User;
import com.studentmanagement.model.UserSearchBean;

@Controller
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "/user/search", method = RequestMethod.GET)
	public ModelAndView userSearchPage(@ModelAttribute("message") String message, ModelMap model) {
		model.addAttribute("message", message);
		return new ModelAndView("USR001", "user", new UserSearchBean());
	}

	@RequestMapping(value = "/user/search", method = RequestMethod.POST)
	public String Login(@ModelAttribute("user") UserSearchBean user, ModelMap model) {

		UserDTO dto = new UserDTO();
		dto.setId(user.getId());
		dto.setName(user.getName());
		List<UserDTO> list = new ArrayList<UserDTO>();

		if (dto.getId().equals("") && dto.getName().equals("")) {
			list = userService.selectAll();
		} else {
			list = userService.selectOne(dto);
		}

		if (list.size() == 0) {
			model.addAttribute("message", "User not found!");
		} else {
			model.addAttribute("userlist", list);
		}
		return "USR001";
	}

	@RequestMapping(value = "/user/add", method = RequestMethod.GET)
	public ModelAndView addUserPage() {
		return new ModelAndView("USR002", "user", new User());
	}

	@RequestMapping(value = "/user/add", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("user") @Validated User user, BindingResult bindingResult, ModelMap model,
			RedirectAttributes ra) {

		if (bindingResult.hasErrors()) {
			return "USR002";
		}

		if (!user.getPassword().equals(user.getConfirm())) {
			model.addAttribute("message", "Password and Confirm must be same!");
			return "USR002";
		} else {
			UserDTO dto = new UserDTO(user.getId(), user.getName(), user.getPassword());

			Optional<UserDTO> checkUser = userService.getUserById(dto.getId());

			if (checkUser.isPresent()) {
				model.addAttribute("message", "User Id has been already exist!");
				return "USR002";
			} else {
				UserDTO result = userService.save(dto);

				if (result == null) {
					ra.addAttribute("message", "Add User fail");
				} else {
					ra.addAttribute("message", "Add User Success");
					
				}
				return "redirect:/user/search";
			}
		}
	}

	@RequestMapping(value = "/user/update", method = RequestMethod.GET)
	public ModelAndView updateUserPage(ModelMap model, @RequestParam("id") String id) {

		Optional<UserDTO> dto = userService.getUserById(id);
		User user = new User();
		user.setId(dto.get().getId());
		user.setName(dto.get().getName());
		return new ModelAndView("USR002-01", "user", user);
	}

	@RequestMapping(value = "/user/update", method = RequestMethod.POST)
	public String updateBook(@ModelAttribute("user") @Validated User user, BindingResult bindingResult, ModelMap model,
			RedirectAttributes ra) {

		if (bindingResult.hasErrors()) {
			return "USR002-01";
		}

		if (!user.getPassword().equals(user.getConfirm())) {
			model.addAttribute("message", "Password and Confirm must be same!");
			return "USR002-01";
		} else {
			UserDTO dto = new UserDTO(user.getId(), user.getName(), user.getPassword());
			UserDTO result = userService.update(dto, dto.getId());

			if (result == null) {
				ra.addAttribute("message", "Update User Fail");
			} else {
				ra.addAttribute("message", "Update User Success");
			}
			return "redirect:/user/search";
		}
	}

	@RequestMapping(value = "/user/delete", method = RequestMethod.GET)
	public String deleteUser(ModelMap model, @RequestParam("id") String id, RedirectAttributes ra) {

		userService.delete(id);

		ra.addAttribute("message", "User Delete Success!");

		return "redirect:/user/search";
	}

}
