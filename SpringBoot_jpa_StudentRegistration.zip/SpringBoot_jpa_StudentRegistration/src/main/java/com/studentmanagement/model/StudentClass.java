package com.studentmanagement.model;

import javax.validation.constraints.NotEmpty;

public class StudentClass {
	
	@NotEmpty(message = "Class Id can't be blank")
	private String id;
	@NotEmpty(message = "Class name can't be blank")
	private String name;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
