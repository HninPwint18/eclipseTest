package com.studentmanagement.model;

import javax.validation.constraints.NotEmpty;

public class Student {

	@NotEmpty(message = "Student Id can't be blank")
	private String id;
	@NotEmpty(message = "Student Name can't be blank")
	private String name;
	@NotEmpty(message = "Class Name can't be blank")
	private String className;
	private String year;
	private String month;
	private String day;
	@NotEmpty(message = "Status can't be blank")
	private String status;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
