package com.studentmanagement.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentmanagement.dto.UserDTO;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public Optional<UserDTO> getUserById(String id) {
		return userRepository.findById(id);
	}

	public UserDTO save(UserDTO user) {
		return userRepository.save(user);
	}

	public List<UserDTO> selectAll() {
		List<UserDTO> list = (List<UserDTO>) userRepository.findAll();
		return list;
	}

	//Custom Query
	public List<UserDTO> selectOne(UserDTO dto) {
		List<UserDTO> list = userRepository.selectOne(dto.getId(), dto.getName());
		return list;
	}
	
	public UserDTO update(UserDTO user, String id) {
		return userRepository.save(user);
	}
	
	public void delete(String id) {
		userRepository.deleteById(id);
	}
}
