package com.studentmanagement.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.studentmanagement.dto.StudentDTO;

@Repository
public interface StudentRepository extends CrudRepository<StudentDTO, String> {

	@Transactional
	@Modifying
	@Query(value = "select * from student where student_id=?1 or student_name=?2 or class_name=?3", nativeQuery = true)
	List<StudentDTO> selectOne(String id,String name,String cName);
}
