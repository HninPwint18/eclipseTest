package com.studentmanagement.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentmanagement.dto.StudentDTO;

@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepository;

	public Optional<StudentDTO> getStudentById(String id) {
		return studentRepository.findById(id);
	}

	public StudentDTO save(StudentDTO student) {
		return studentRepository.save(student);
	}

	public List<StudentDTO> selectAll() {
		List<StudentDTO> list = (List<StudentDTO>) studentRepository.findAll();
		return list;
	}

	// Custom Query
	public List<StudentDTO> selectOne(StudentDTO dto) {
		List<StudentDTO> list = studentRepository.selectOne(dto.getStudentId(), dto.getStudentName(),
				dto.getClassName());
		return list;
	}
	
	public StudentDTO update(StudentDTO student, String id) {
		return studentRepository.save(student);
	}
	
	public void delete(String id) {
		studentRepository.deleteById(id);
	}
}
