package com.studentmanagement.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.studentmanagement.dto.UserDTO;

@Repository
public interface UserRepository extends CrudRepository<UserDTO, String> {

	@Transactional
	@Modifying
	@Query(value = "select * from user where id=?1 or name=?2", nativeQuery = true)
	List<UserDTO> selectOne(String id,String name);
}
