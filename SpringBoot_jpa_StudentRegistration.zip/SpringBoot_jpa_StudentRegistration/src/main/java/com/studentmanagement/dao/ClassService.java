package com.studentmanagement.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentmanagement.dto.ClassDTO;

@Service
public class ClassService {

	@Autowired
	ClassRepository classRepository;

	public ClassDTO save(ClassDTO stuClass) {
		return classRepository.save(stuClass);
	}

	public Optional<ClassDTO> getClassById(String id) {
		return classRepository.findById(id);
	}

	public List<ClassDTO> getAllClass() {
		List<ClassDTO> list = (List<ClassDTO>) classRepository.findAll();
		return list;
	}

}
