package com.exercise.dao;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.exercise.dto.Book;

//defining the business logic  
@Service
public class BookService {
	@Autowired
	BookRepository booksRepository;

//getting all books record by using the method findaAll() of CrudRepository  
	public List<Book> getAllBooks() {
		List<Book> list = (List<Book>) booksRepository.findAll();
		return list;
	}

//getting a specific record by using the method findById() of CrudRepository  
	public Book getBooksByBookCode(String code) {
		 return booksRepository.findByBookCode(code);
	}

//saving a specific record by using the method save() of CrudRepository  
	public Book save(Book books) {
		 return booksRepository.save(books);
	}

//deleting a specific record by using the method deleteById() of CrudRepository  
	public void delete(String code) {
		  booksRepository.deleteById(code);
	}

//updating a record  
	public void update(Book books) {
		 booksRepository.save(books);
	}
}